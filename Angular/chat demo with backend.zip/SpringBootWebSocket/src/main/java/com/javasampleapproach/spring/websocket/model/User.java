package com.javasampleapproach.spring.websocket.model;

public class User {
	private String name;

	public User() {
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}
}
