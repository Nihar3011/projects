const express = require('express');
const router = express.Router();

const user = require('../controllers/user.controller');

router.get('/designation',user.getUserDepartmentName);
router.get('/reviewer-of-reviewee/:id',user.getReviewerIdForReviewee);
router.post('/dashboard', user.getRevieweeMappingList);
router.post('/my-reviews', user.getReviewerMappingList);

module.exports = router;
