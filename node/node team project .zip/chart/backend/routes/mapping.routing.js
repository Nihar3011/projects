const express = require('express');
const router = express.Router();


const sessionTemplateMapping = require('../controllers/sessionTemplateMapping.controller');
const user = require('../controllers/user.controller');
const template = require('../controllers/template.controller');


router.get('/users', user.getUsersFullNameAndType);
router.get('/templates',template.getTemplatesName);
router.post('/mapping/:id',sessionTemplateMapping.postMappingArray);
module.exports = router;