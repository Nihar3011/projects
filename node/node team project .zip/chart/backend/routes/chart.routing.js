const express = require('express');
const router = express.Router();

const chart = require('../controllers/chart.controller');

router.get('/get-chart',chart.getCharts);
router.get('/get-chart-list',chart.getChartList);
router.post('/add-chart',chart.chartInsert);
router.put('/update-chart',chart.updateChartById);
router.delete('/delete-chart',chart.deleteChartById);
router.put('/reorder-chart',chart.reorderCharts);

module.exports = router;