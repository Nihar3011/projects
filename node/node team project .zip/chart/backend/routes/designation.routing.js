const express = require('express');
const router = express.Router();

const designation = require('../controllers/designation.controller');
const user = require('../controllers/user.controller');

router.get('/designation-names/', designation.getDesignationNames);
router.get('/users/',user.getUserByDesignation);

module.exports = router;