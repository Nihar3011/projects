const express = require('express');
const router = express.Router();

const reportAnalysis = require('../controllers/reportAnalysis.controller');

router.get('/getversions/:id',reportAnalysis.getSessionVersionsLog);
router.post('/analysisDashboard',reportAnalysis.dashboardAnalysis);

module.exports = router;