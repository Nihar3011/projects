const express = require('express');
const router = express.Router();

const template = require('../controllers/template.controller');

router.get("/template-details/:id", template.getTemplateById);
router.post("/template-list", template.getTemplateList);
router.post('/', template.templateInsertUpdate);
router.delete("/", template.deleteTemplateById);

module.exports = router;
