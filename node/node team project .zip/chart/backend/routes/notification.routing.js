const express = require('express');
const router = express.Router();

const notification = require('../controllers/notification.controller')

router.get("/list", notification.getNotificationList);
router.get('/read', notification.readNotification);
router.get('/readall', notification.readAllNotifications);
router.get("/delete", notification.deleteNotification);

module.exports = router;