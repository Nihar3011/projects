const express = require('express');
const router = express.Router();

const sessionTemplateMapping = require('../controllers/sessionTemplateMapping.controller');
const session = require('../controllers/session.controller');
const sessionMapping = require('./mapping.routing');


router.post('/mapping-list', sessionTemplateMapping.getMappingList);
router.post('/create', session.createSession);
router.put('/updateById/:id', session.updateSession);
router.get('/session-name', session.getSessionsNames);
router.get('/session-details/:id', session.getSessionById);
router.post('/session-mapping-details/:id', sessionTemplateMapping.sessionTemplateMappingDetails);
router.post('/session-list', session.getSessionList);
router.delete('/session-delete', session.deleteSession);
router.use('/session-mapping', sessionMapping);
router.post('/mapping-report', sessionTemplateMapping.getSessionMappingReport);
router.delete('/delete', sessionTemplateMapping.deleteMapping);

module.exports = router;