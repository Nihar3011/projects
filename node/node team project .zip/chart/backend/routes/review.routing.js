const express = require('express');
const router = express.Router();

const review = require('../controllers/review.controller');
const comment = require('../controllers/comment.controller');
const sessionTemplateMapping = require('../controllers/sessionTemplateMapping.controller');

router.get('/response-data', review.getResponseDataByMappingId);
router.get('/review-data/:id', sessionTemplateMapping.getMappingData);
router.get('/comments-list/:id', comment.getComments);
router.post('/add-comment', comment.storeComment);
router.post('/review-response', review.storeResponseData);
router.post('/update-review/:id', review.updateResponse);
router.put('/publish-review', review.publishReview);
router.put('/update-comment', comment.updateComment);
router.put('/reevaluation', review.ReEvaluationRequest);
router.put('/reevaluation-conformation', review.ReEvaluationConformation);
router.get('/:id', review.getReviewScore);


module.exports = router;