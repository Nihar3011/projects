const Sequelize = require('sequelize');

const {
    chartModel,
    userDetailsModel
} = require('../sequelizeModels/index');

const createChart = async (chartData) => {
    let result = await chartModel.create(chartData);
    return result;
}

const getChartByChartId = async (chartId) => {
    let result = await chartModel.findOne({
        where: {
            c_id: chartId
        }
    });
}

const getCharts = async () => {
    let result = await chartModel.findAll({
        attributes: ['c_type', 'c_title', 'c_x_title', 'c_x_field', 'c_y_field', 'c_data', 'c_view_toggle'],
        order: [
            ['created_at', 'desc']
        ]
    });
    return result;
}

const reorderCharts = async (order,id) => {
    // let result = await chartModel.bulkCreate(chartData, {
    //     fields: ['c_id', 'c_order'],
    //     updateOnDuplicate: ['c_order']
    // })
    let result = await chartModel.update({
        c_order: order
    }, {

        where: {
            'c_id': id
        }
    });
    return result;
}

const getChartsList = async () => {
    let result = await chartModel.findAll({
        include: [{
            model: userDetailsModel,
            as: 'charts',
            attributes: [
                [Sequelize.literal("first_name || ' ' || last_name"), 'name']
            ]
        }],
        where: {
            c_is_deleted: false
        },
        order: [
            ['created_at', 'desc']
        ]
    });
    return result;
}

const updateChart = async (updateData, chartId) => {
    let result = await chartModel.update(updateData, {
        where: {
            c_id: chartId
        }
    });
    return result;
}
module.exports = {
    createChart,
    getCharts,
    getChartsList,
    updateChart,
    getChartByChartId,
    reorderCharts
}