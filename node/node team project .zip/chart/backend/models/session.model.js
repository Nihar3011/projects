const {
    sessionModel
} = require('../sequelizeModels/index');
"use strict";

const getFrequency = (cycle) => {
    switch (cycle) {
        case 0:
            {
                return 'Never';
            }
        case 1:
            {
                return 'Every month';
            }
        case 2:
            {
                return 'Every 2 months';
            }
        case 3:
            {
                return 'Every 3 months';
            }
        case 4:
            {
                return 'Every 4 months';
            }
        case 6:
            {
                return 'Half-Yearly';
            }
        case 12:
            {
                return 'Yearly';
            }
        default:
            {
                return 'Never';
            }
    }
};

const createSession = async (sessionData) => {
    const result = await sessionModel.create(sessionData);
    return result;
};

const updateSession = async (sessionData, sessionId) => {

    const result = await sessionModel.update(sessionData, {
        where: {
            's_id': {
                $in: sessionId
            }
        }
    });
    return result;
};

const getSessionsName = async () => {
    const result = await sessionModel.findAll({
        attributes: ['s_id', 's_name']
    });
    return result;
};

const getSessionsById = async (sessionId) => {
    const result = await sessionModel.findOne({
        where: {
            's_id': sessionId
        }
    });
    return result;
};

const getSessionList = async (status, sortField, sortOrder, searchString) => {

    const sort = {
        "session_name": ["s_name"],
        "review_cycle_frequency": ["s_frequency"],
        "session_description": ["s_description"],
        "session_status": ["s_status"],
        "session_starting_date": ["s_starting_date"],
        "session_ending_date": ["s_ending_date"],
        "session_created_at": ["created_at"]
    };
    const orderArray = {
        "-1": 'desc',
        "1": "asc"
    };
    const sortData = !sortField ? ['created_at', 'desc'] : (sortField === "session_status") ? ['s_status', orderArray[sortOrder]] : [sort[sortField][0], orderArray[sortOrder]];
    let where = {
        's_status': {
            $ne: 3
        }
    };

    const search = `%${searchString || ''}%`;

    if (!!search && !status)
        where = {
            's_status': {
                $ne: 3
            },
            's_name': {
                $ilike: `%${search}%`
            }
        };

    if (!search && !!status) {
        where = {
            ...(status == 0 ? {
                s_status : {
                    $lt :3
                }
            }:{
                s_status: status
            })
        };
    }

    if (!!search && !!status) {
        where = {
            's_name': {
                $ilike: `%${search}%`
            },
            ...(status == 0 ? {
                s_status : {
                    $lt :3
                }
            }:{
                s_status: status
            })
        };
    }

    const result = await sessionModel.findAll({
        where: where,
        order: [sortData, ['s_status', 'asc']]
    });
    return result;
};

const softDeleteSession = async (sessionId, userId, date) => {
    const result = await sessionModel.update({
        's_status': 3,
        's_frequency': 0,
        'modified_by': userId,
        'modified_at': date.toISOString()
    }, {
            where: {
                's_id': sessionId
            }
        });
    return result;
};

const sessionNameValidation = async (sessionName, sessionId) => {
    const result = sessionModel.count({
        where: {
            's_name': {
                $eq: sessionName
            },
            's_id': {
                $ne: sessionId
            },
            's_status': {
                $ne: 3
            }
        }
    });
    return result;
};

const getSessionStartingToday = async () => {
    const fromDate = new Date();
    const toDate = new Date();
    toDate.setDate(toDate.getDate()+1);
    const result = await sessionModel.findAll({
        where: {
            's_starting_date': {
                $lt: toDate,
                $gt: fromDate
            },
            's_status': 2
        }
    });
    return result;
};

const getSessionEndingBeforeNthDay = async (n) => {
    const fromDate = new Date();
    const toDate = new Date();
    toDate.setDate(toDate.getDate()-(n-1));
    fromDate.setDate(toDate.getDate()-n);
    const result = await sessionModel.findAll({
        attributes: ['s_id', 's_ending_date'],
        where: {
            's_ending_date': {
                $lt: toDate,
                $gt: fromDate
            },
            's_status': 1
        }
    });
    return result;
};

module.exports = {
    createSession,
    updateSession,
    getSessionsName,
    getSessionsById,
    getSessionList,
    softDeleteSession,
    getFrequency,
    sessionNameValidation,
    getSessionStartingToday,
    getSessionEndingBeforeNthDay
};