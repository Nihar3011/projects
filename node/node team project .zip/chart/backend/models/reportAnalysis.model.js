const {
    sequelize,
    stmModel,
    userDetailsModel,
    designationModel,
    sessionModel,
    templateModel,
    reviewModel
} = require('../sequelizeModels/index');

"use strict";

const sessionVersionLogs = async(sessionId) => {
    const result = await sequelize.query('select * from sessionversions(?)', { replacements: [sessionId], type: sequelize.QueryTypes.SELECT });
    return result;
};

const analysisDashboard = async(body,sortField) => {
    
    const conditions = await getConditions(body);
    
    const result = await stmModel.findAll({
        attributes: ['stm_id', 'stm_reviewee_id'],
        where: conditions,
        include: [{
                model: userDetailsModel,
                as: 'reviewee',
                include: [{
                    model: designationModel,
                    as: 'designation',
                    attributes: ['des_id', 'des_name'],
                }],
                attributes: [
                    [userDetailsModel.sequelize.literal("reviewee.first_name || ' ' || reviewee.last_name"), 'reviewee_name'],
                ],
            },
            {
                model: userDetailsModel,
                as: 'reviewer',
                attributes: [
                    [userDetailsModel.sequelize.literal("reviewer.first_name || ' ' || reviewer.last_name"), 'reviewer_name'],
                ],
            },
            {
                model: sessionModel,
                as: 'sessions',
                attributes: [
                    [sessionModel.sequelize.literal("sessions.s_name || ' - V' || session_template_mapping.stm_version || '.0' "), 'sessionName']
                ]
            },
            {
                model: templateModel,
                as: 'templates',
                attributes: ['t_name', 't_score']
            },
            {
                model: reviewModel,
                attributes: ['r_score','created_at']
            }
        ],
        group: ['s_id', 'stm_reviewee_id', 'stm_id', 'reviewee.user_id', 'reviewer.user_id', 'templates.t_id', 'reviews.r_id', 'reviewee->designation.des_id'],
        order: [sortField]
        
    });

    return result;
};

const getConditions = async(body) => {
    const conditions = { 'stmModel': [{ 'stm_status': 2 }] };
    let filter = {};
    if (!body.filter) {
        return conditions['stmModel'];
    } else {
        if (body.session.length != 0) {
            filter['$in'] = body.session;
            conditions['stmModel'].push({ 'stm_session_id': filter });
            filter = {};
        }
        if (body.user.length != 0) {
            filter['$in'] = body.user;
            conditions['stmModel'].push({ 'stm_reviewee_id': filter });
            filter = {};
        }
        if (body.reviewer != null && body.reviewer.length != 0) {
            filter['$in'] = body.reviewer;
            conditions['stmModel'].push({ 'stm_reviewer_id': filter });
            filter = {};
        }
        if (body.dateRange.length != 0) {
            conditions['stmModel'].push({ '$reviews.created_at$': { '$between': [new Date(body.dateRange[0]), new Date(body.dateRange[1])] } });
        }
        if (body.designation.length != 0) {
            filter['$in'] = body.designation;
            conditions['stmModel'].push({ '$reviewee.designation.des_id$': filter });
            filter = {};
        }
        if (body.template.length != 0) {
            filter['$in'] = body.template;
            conditions['stmModel'].push({ '$templates.t_id$': filter });
            filter = {};
        }
        if (body.joiningYear.length != 0) {
            const joinDate = new Date(body.joiningYear);
            const d = new Date(joinDate.getFullYear(), joinDate.getMonth(), 1).toISOString();
            conditions['stmModel'].push({ '$reviewee.join_date$': { '$gt': d } });
        }
    }
    return conditions['stmModel'].length == 1 ? conditions['stmModel'] : { '$and': conditions['stmModel'] };
};

module.exports = { sessionVersionLogs, analysisDashboard };