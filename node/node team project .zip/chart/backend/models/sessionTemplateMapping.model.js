const {
    stmModel,
    userDetailsModel,
    sessionModel,
    templateModel,
    secondaryReviewerModel,
    reviewModel,
    designationModel
} = require('../sequelizeModels/index');
const Sequelize = require("sequelize");
"use strict";

const mappingIdValidation = async (mappingId) => {
    let result = await stmModel.findOne({
        where: {
            'stm_id': mappingId
        }
    })
    return result;
}

const updateMapping = async (status, userId, mappingId, reevalution=false) => {
    let result = await stmModel.update(
        { 
            modified_by: userId, 
            modified_at: new Date(),
            ...(reevalution ? {
                stm_reevaluation_status: false
            } : {
                stm_status: status,
                ...(status == 2 ? {
                    published_by: userId, 
                    published_at: new Date(),
                } : {})
            })
        }, 
        {
            where: {
                'stm_id': mappingId
            }
        }
    );
    return result;
}

const getMappingById = async (mappingId) => {
    let result = await stmModel.findOne({
        attributes: [
            ['stm_status', 'status'], 'stm_reviewee_id', 'stm_reviewer_id', 'stm_template_id', 'stm_reevaluation_status'
        ],
        include: [{
            model: userDetailsModel,
            as: 'reviewee',
            attributes: [
                ['first_name', 'reviewee_name']
            ]
        },
        {
            model: userDetailsModel,
            as: 'reviewer',
            attributes: [
                ['first_name', 'reviewer_name']
            ]
        },
        {
            model: templateModel,
            as: 'templates',
            attributes: [
                ['t_name', 'template_name'],
            ],
        },
        {
            model: sessionModel,
            as: 'sessions',
            attributes: [
                ['s_name', 'session_name'],
                ['s_ending_date', 'session_ending_date'],
            ],
        }
        ],
        where: {
            'stm_id': mappingId
        }
    })
    return result;
}

const getMappingList = async (status, sortField, sortOrder, searchString, sessionStatus) => {
    let sort = { "session": ["sessions", "s_name"], "reviewee": ["reviewee", "first_name"], "reviewer": ["reviewer", "first_name"] };
    let order = { "-1": 'desc', "1": "asc" }
    let sortData = !sortField ? ['stm_id'] : sortField === "status" ? ['stm_status', order[sortOrder]] : [sort[sortField][0], sort[sortField][1], order[sortOrder]];
    searchString = `%${searchString || ''}%`;
    sessionStatus = sessionStatus || 1;

    let result = await stmModel.findAll({
        attributes: ['stm_id', 'stm_status'],
        include: [{
            model: userDetailsModel,
            as: 'reviewee',
            attributes: [
                [userDetailsModel.sequelize.literal("reviewee.first_name || ' ' || reviewee.last_name"), 'reviewee_name']
            ]
        },
        {
            model: userDetailsModel,
            as: 'reviewer',
            attributes: [
                [userDetailsModel.sequelize.literal("reviewer.first_name || ' ' || reviewer.last_name"), 'reviewer_name']
            ]
        },
        {
            model: sessionModel,
            as: 'sessions',
            attributes: [
                ['s_name', 'session_name']
            ],
        }
        ],
        where: {
            ...(status == 0 ? {
                stm_status: { $lt: 4 }
            } : {
                    stm_status: status
                }
            ),
            '$sessions.s_status$': sessionStatus,
            $or: [
                { '$sessions.s_name$': { $ilike: searchString } },
                { '$reviewee.first_name$': { $ilike: searchString } },
                { '$reviewee.last_name$': { $ilike: searchString } },
                { '$reviewer.first_name$': { $ilike: searchString } },
                { '$reviewer.last_name$': { $ilike: searchString } }
            ]
        },
        order: [
            sortData
        ],
    });
    return result;
}

const getNoOfMappingBySessionId = async (sessionId) => {
    let result = await stmModel.count({
        where: {
            stm_session_id: sessionId
        }
    });

    return result[0];
}

const getRevieweeMappingList = async (status, sortField, sortOrder, searchString, userId) => {
    searchString = `%${searchString || ''}%`
    let sort = {
        "session_name": ["sessions", "s_name"],
        "name": ["reviewee", "first_name"],
        "template_name": ["templates", "t_name"],
        "deadline": ["sessions", "s_ending_date"]
    };
    let order = { "-1": "desc", "1": "asc" };
    let sortData = !sortField ? ['sessions', 's_ending_date', "desc"] :
        sortField === "status" ? ['stm_status', order[sortOrder]] : [sort[sortField][0], sort[sortField][1], order[sortOrder]];

    let result = stmModel.findAll({
        include: [{
            model: secondaryReviewerModel,
            as: 'secondaryReviewers',
            required: false,
        },
        {
            model: templateModel,
            as: 'templates'
        },
        {
            model: userDetailsModel,
            as: 'reviewee',
            attributes: [
                [userDetailsModel.sequelize.literal("reviewee.first_name || ' ' || reviewee.last_name"), 'reviewee_name']
            ]
        },
        {
            model: sessionModel,
            as: 'sessions',
            where: {
                's_status': 1
            }
        }
        ],
        where: {
            $and: [{
                $or: [
                    { stm_reviewer_id: userId },
                    { '$secondaryReviewers.sr_reviewer_id$': userId },
                ]
            },
            {
                $or: [
                    { '$sessions.s_name$': { $ilike: searchString } },
                    { '$reviewee.first_name$': { $ilike: searchString } },
                    { '$reviewee.last_name$': { $ilike: searchString } },
                    { '$templates.t_name$': { $ilike: searchString } }
                ]
            }
            ],
            ...(status == 0 ? {
                stm_status: {
                    $lt: 4
                }
            } : {
                    stm_status: status
                }
            ),
        },
        order: [sortData]
    });
    return result;
}

const getReviewerMappingList = async (status, sortField, sortOrder, searchString, userId) => {
    searchString = `%${searchString || ''}%`
    let sort = {
        "session_name": ["sessions", "s_name"],
        "name": ["reviewer", "first_name"],
        "template_name": ["templates", "t_name"],
        "deadline": ["sessions", "s_ending_date"]
    };
    let order = { "-1": "desc", "1": "asc" };
    let sortData = !sortField ? ['sessions', 's_ending_date', "desc"] :
        sortField === "status" ? ['stm_status', order[sortOrder]] : [sort[sortField][0], sort[sortField][1], order[sortOrder]];

    let result = stmModel.findAll({
        include: [{
            model: templateModel,
            as: 'templates'
        },
        {
            model: userDetailsModel,
            as: 'reviewer',
            attributes: [
                [userDetailsModel.sequelize.literal("reviewer.first_name || ' ' || reviewer.last_name"), 'reviewer_name']
            ]
        },
        {
            model: sessionModel,
            as: 'sessions',
            where: {
                's_status': { $lt: 3 }
            }
        }
        ],
        where: {
            stm_reviewee_id: userId,
            ...(status == 0 ? {
                stm_status: {
                    $lt: 4
                }
            } : {
                    stm_status: status
                }
            ),
            $or: [
                { '$sessions.s_name$': { $ilike: searchString } },
                { '$reviewer.first_name$': { $ilike: searchString } },
                { '$reviewer.last_name$': { $ilike: searchString } },
                { '$templates.t_name$': { $ilike: searchString } }
            ]
        },
        order: [sortData],
    });
    return result
}

const addToStm = async (stmData) => {

    let result = await stmModel.create({
        stm_session_id: stmData.stm_session_id,
        stm_template_id: stmData.stm_template_id,
        stm_reviewer_id: stmData.stm_reviewer_id,
        stm_reviewee_id: stmData.stm_reviewee_id,
        stm_status: stmData.stm_status,
        created_by: stmData.created_by,
        created_at: stmData.created_at,
        stm_version: stmData.stm_version
    });

    return result.dataValues.stm_id;
}

const getStmIdByMappingData = async (stmData) => {
    let result = await stmModel.findOne({
        where: stmData
    });
    return result.dataValues.stm_id;
}

const getPendingReviewList = async (sessionIds) => {
    let result = await stmModel.findAll({
        attributes: ['stm_id', 'stm_session_id', 'stm_reviewer_id'],
        where: {
            stm_status: 1,
            stm_session_id: {
                $in: sessionIds
            }
        },
        include: [{
            model: userDetailsModel,
            as: 'reviewer',
            attributes: [
                [userDetailsModel.sequelize.literal("reviewer.first_name || ' ' || reviewer.last_name"), 'reviewer_name'],
                ['email_address', 'reviewer_mail']
            ]
        },
        {
            model: userDetailsModel,
            as: 'reviewee',
            attributes: [
                [userDetailsModel.sequelize.literal("reviewee.first_name || ' ' || reviewee.last_name"), 'reviewee_name']
            ]
        },
        {
            model: sessionModel,
            as: 'sessions',
            attributes: [
                ['s_name', 'session_name'],
                ['s_ending_date', 'deadline'],
            ]
        }
        ],
        group: ['stm_id', 'stm_session_id', 'stm_reviewer_id', 'stm_reviewee_id', 'sessions.s_id', 'reviewer.user_id', 'reviewee.user_id']
    });
    return result;
}

const getMappingBySessionId = async (sessionId) => {
    let result = await stmModel.findAll({
        attributes: ['stm_id', 'stm_status'],
        where: {
            stm_session_id: sessionId,
            stm_version: { $col: 'sessions.s_version' }
        },
        include: [{
            model: userDetailsModel,
            as: 'reviewer',
            attributes: [
                [userDetailsModel.sequelize.literal("reviewer.first_name || ' ' || reviewer.last_name"), 'full_name']
            ]
        },
        {
            model: userDetailsModel,
            as: 'reviewee',
            attributes: [
                [userDetailsModel.sequelize.literal("reviewee.first_name || ' ' || reviewee.last_name"), 'full_name']
            ]
        },
        {
            model: templateModel,
            as: 'templates',
            attributes: ['t_name']
        },
        {
            model: sessionModel,
            as: 'sessions',
            attributes: ['s_version']
        }]
    })
    return result;
}

const getUserReviewScore = async (userId) => {

    let result = await stmModel.findAll({
        attributes: [],
        include: [{
            model: reviewModel,
            attributes: [
                ['r_score', 'reviewScore']
            ]
        },
        {
            model: templateModel,
            as: 'templates',
            attributes: [
                ['t_score', 'templateScore']
            ]
        }
        ],
        where: {
            stm_status: 2,
            stm_reviewee_id: userId,
            '$templates.t_scorable$': true
        },
        order: [
            ['reviews', 'created_at', 'desc']
        ]
    });
    return result;
}

const getRevieweeMappingAnalysisBySessionId = async (sortField, sortOrder, searchString, sessionId, users, designations) => {
    let designationData = designations || [];
    searchString = `%${searchString || ''}%`
    let order = { "-1": "desc", "1": "asc" };
    let sortData = !sortField || sortField == 'mappingCount' ? ['first_name', "desc"] :
        sortField == 'employeeName' ? ['first_name', order[sortOrder]] : ['designation', 'des_name', order[sortOrder]];
    const result = await userDetailsModel.findAll({
        attributes: [
            [Sequelize.literal("first_name || ' ' || last_name"), 'fullname']
        ],
        include: [{
            model: stmModel,
            as: 'reviewee',
            where: { stm_session_id: sessionId },
            required: false,
            include: [{
                model: templateModel,
                as: 'templates',
                attributes: [
                    ['t_name', 'template']
                ]
            }]
        },
        {
            model: designationModel,
            as: 'designation',
            attributes: [
                ['des_name', 'designation']
            ],
            where: {
                ...(designationData.length != 0 ?
                    {
                        des_id: {
                            $in: designationData
                        }
                    } : {}
                )
            }
        }
        ],
        where: {
            $or: [
                { '$designation.des_name$': { $ilike: searchString } },
                { '$reviewee.templates.t_name$': { $ilike: searchString } },
                { 'first_name': { $ilike: searchString } },
            ],
            is_active: 'true',
            ...(users.length != 0 ? {
                user_id: {
                    $in: users
                }
            } : {})
        },
        order: [sortData]
    });
    return result;
}

const deleteMapping = async (stmId) => {
    const resultSecondary = await secondaryReviewerModel.destroy({
        where: { 'sr_stm_id': stmId }
    });
    const result = await stmModel.destroy(
        {
            where: { 'stm_id': stmId }
        });
    return { result, resultSecondary };
};

const getMappingIdBySessionId = async (sessionId) => {
    let result = await stmModel.findAll({
        where: {
            stm_session_id: sessionId
        }
    })
    return result;
}

module.exports = {
    mappingIdValidation,
    updateMapping,
    getMappingById,
    getMappingList,
    getReviewerMappingList,
    getRevieweeMappingList,
    getNoOfMappingBySessionId,
    addToStm,
    getStmIdByMappingData,
    getPendingReviewList,
    getMappingBySessionId,
    getUserReviewScore,
    getRevieweeMappingAnalysisBySessionId,
    deleteMapping,
    getMappingIdBySessionId
};