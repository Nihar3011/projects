const {
    secondaryReviewerModel,
    userDetailsModel
} = require('../sequelizeModels/index');

"use strict";

const getSecondaryReviewersIdList = async (mappingId) => {
    let result = await secondaryReviewerModel.findAll({
        include: [{
            model: userDetailsModel,
            as: 'secondary',
            attributes: [
                [userDetailsModel.sequelize.literal("first_name || ' ' || last_name"), 'full_name']
            ]
        }],
        where: {
            sr_stm_id: mappingId
        }
    })
    result = result.map(row => {
        return row.dataValues.secondary.dataValues.full_name;
    });
    return result.sort();
}

const getObjects = async (result) => {
    let respo = []
    if (result.length == 0) {
        return respo;
    }
    result = await Promise.all(result.map(async (value) => {
        let secondaryreviewers = await getSecondaryReviewersIdList(value.dataValues.stm_id);
        return {
            secondaryReviewers: secondaryreviewers,
            reviewer_name: value.reviewer.dataValues.full_name,
            template_name: value.templates.t_name,
            reviewee: {
                reviewee_name: value.reviewee.dataValues.full_name,
                status: value.dataValues.stm_status,
                stmId: value.dataValues.stm_id
            } 
        }
    }));
    return result
}

const getSecondaryReviewersList = async (mappingId) => {
    let result = await secondaryReviewerModel.findAll({
        where: {
            sr_stm_id: mappingId
        }
    });
    result = result.map(row => {
        return row.dataValues.sr_reviewer_id
    });
    return result;
}

const insertIntoSecondaryReviewerList = async (secondaryReviewerData) => {
    let result = await secondaryReviewerModel.bulkCreate(secondaryReviewerData);
    return result;
}

module.exports = {
    getSecondaryReviewersList,
    insertIntoSecondaryReviewerList,
    getSecondaryReviewersIdList,
    getObjects
}