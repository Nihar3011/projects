const {
    commentModel,
    userDetailsModel
} = require('../sequelizeModels/index');

"use strict";

const getCommentsList = async (mappingId) => {
    let result = await commentModel.findAll({
        attributes: ['c_id', 'c_data', 'c_visible', 'created_at', 'c_parent', 'c_system_generated'],
        include: [{
            model: userDetailsModel,
            as: 'createdBy',
            attributes: [
                ['first_name', 'user'],
                ['user_id', 'userId']
            ]
        }],
        where: {
            'c_stm_id': mappingId
        },
        order: ['c_parent', 'c_id']
    })
    return result;
}

const storeComment = async (commentData) => {
    let result = await commentModel.create({
        c_data: commentData.comment,
        c_stm_id: commentData.mappingId,
        c_parent: commentData.parentId,
        created_by: commentData.userId,
        c_visible:  commentData.commentVisibility,
        c_system_generated: commentData.systemGenerated,
        created_at: new Date()
    })
    return result;
}

const updateComment = async (updateData, commentIdList) => {
    let result = await commentModel.update(updateData, {
        where: {
            $or:[
                {'c_id': commentIdList},
                {'c_parent': commentIdList}
            ]
        }
    })
    return result;
}

module.exports = {
    getCommentsList,
    storeComment,
    updateComment
}