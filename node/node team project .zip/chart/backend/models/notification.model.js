const {
    notificationDetailModel
} = require('../sequelizeModels/index');

"use strict";

const readNotification = async (notificationId) => {
    const result = await notificationDetailModel.update(
        { 'nd_is_seen': true },
        { where: { 'nd_id': notificationId } }
    );
    return result; 
};

const readAllNotifications = async (userId) => {
    const result = await notificationDetailModel.update(
        { 'nd_is_seen': true },
        { where: { $and: [{ 'nd_for': userId }, { 'nd_is_seen': false }] } }
    );
    return result;
};

const deleteNotification = async (notificationId) => {
    const result = notificationDetailModel.update(	
        { 'nd_is_deleted': true },
        { where: { 'nd_id': notificationId } }
    );
    return result;
};

const getAllNotifications = async (userId,scrollSize) => {
    const result = notificationDetailModel.findAll({
        where: { 'nd_for': userId, 'nd_is_deleted': false   },
        order: [['nd_id', 'desc']],
        offset: 0,
        limit: scrollSize
    });
    return result;
};

const getNotificationCount = async (userId, countFlag) => {
    const where = (countFlag === 'unread') ? { 'nd_for': userId, 'nd_is_seen': false, 'nd_is_deleted': false } : { 'nd_for': userId, 'nd_is_deleted': false };
    const result = await notificationDetailModel.count({
        where: where,
        group: ['nd_for']
    });
    return Number(result.length > 0 ? result[0].count : 0);
};

const storeNotificationData = (notificationListData) => {
    notificationDetailModel.bulkCreate(notificationListData);
};

module.exports = {
    readNotification,
    readAllNotifications,
    deleteNotification,
    getAllNotifications,
    getNotificationCount,
    storeNotificationData
};
