const {
    templateModel
} = require('../sequelizeModels/index');
"use strict";
const getTemplateById = async (templateId) => {
    let result = await templateModel.findOne({
        attributes: [
            ['t_id', 'templateId'],
            ['t_status', 'templateStatus'],
            ['t_description', 'templateDescription'],
            ['t_name', 'templateName'],
            ['t_structure', 'templateStructure'],
            ['t_scorable', 'isScorable'],
            ['canInterview', 'canInterview'],
            ['t_score', 'templateScore']
        ],
        where: {
            t_status: {
                $ne: 3
            },
            t_id: templateId
        }
    });
    return result;
}

const deleteTemplateById = async (templateId, userId) => {
    let result = await templateModel.update({
        t_status: 3,
        modified_by: userId,
        modified_at: new Date()
    }, {
            where: {
                t_status: {
                    $ne: 2
                },
                t_id: templateId
            }
        });
    return result;
}

const createTemplate = async (templateData) => {
    let result = await templateModel.create(templateData);
    return result;
}

const updateTemplate = async (templateData, templateId) => {
    let result = await templateModel.update(templateData, {
        where: {
            t_id: {
                $in: templateId
            }
        }
    });
    return result;
}

const getTemplateList = async (status, sortField, sortOrder, searchString, userId) => {
    let search = `%${searchString || ''}%`;
    let order = {
        "-1": 'desc',
        "1": "asc"
    };
    let sort = {
        "template_name": "t_name",
        "creation_date": "created_at",
        "template_description": "t_description"
    };
    let sortString = !!sortField ? [sort[sortField], order[sortOrder]] : ['created_at', 'desc'];
    let where = {
        t_status: {
            $in: [3, 4]
        }
    }

    if (!!search && !!status) {
        templateStatus = (status == 2) ? 4 : ((status === 1) ? [1, 2] : ((status === 0) ? [1, 2, 4] : {
            $lt: 5
        }));
        where = {
            t_name: {
                $ilike: `${search}`
            },
            t_status: templateStatus
        };
    }
    if (status == 2) {
        where["created_by"] = userId;
    } else if (status == 0) {
        where = {
            t_name: {
                $ilike: `${search}`
            },
            $or: [{
                t_status: [1, 2]
            }, {
                t_status: 4,
                created_by: userId
            }]
        }
    }

    let result = await templateModel.findAll({
        attributes: [
            ['t_id', 'template_id'],
            ['t_name', 'template_name'],
            ['created_at', 'creation_date'],
            ['t_description', 'template_description'],
            ['t_status', 'template_status']
        ],
        where: where,
        order: [sortString]
    });
    return result;
}

const getTemplatesName = async () => {
    let result = await templateModel.findAll({
        attributes: [
            ['t_id', 'value'],
            ['t_name', 'label']
        ],
        where: {
            t_status: {
                $lt: 3
            }
        }
    })
    return result;
}


const templateNameValidator = async (templateName, templateId) => {
    let result = templateModel.count({
        where: {
            t_name: {
                $eq: templateName
            },
            t_id: {
                $ne: templateId
            },
            t_status: {
                $ne: 3
            }
        }
    })
    return result;
}
module.exports = {
    getTemplateById,
    deleteTemplateById,
    createTemplate,
    updateTemplate,
    getTemplateList,
    getTemplatesName,
    templateNameValidator
};
