const {
    userDetailsModel,
    designationModel,
    stmModel
} = require('../sequelizeModels/index');
const Sequelize = require("sequelize");
"use strict";

const getUserByEmail = async (email) => {
    let result = await userDetailsModel.findOne({
        attributes: ['user_id', [Sequelize.literal("first_name || ' ' || last_name"), 'fullname'], 'dep_id', 'type', 'is_active'],
        include: [{
            model: designationModel,
            as: 'designation',
            required: true,
            attributes: ['des_name']
        }],
        where: {
            email_address: email,
            is_active: 'true'
        }
    });
    return result;
}

const getUserById = async (userId) => {
    let result = await userDetailsModel.findAll({
        where: { 'user_id': { $in: userId } }
    });
    return result;
}
const getAdminList = async (userId) => {
    let result = await userDetailsModel.findAll({
        where: {
            'user_id': { $ne: userId },
            $or: [
                { 'dep_id': 1 }
            ]
        }
    });
    result = result.map(row => Number(row.dataValues.user_id));
    return result;
}

const getAdminMailList = async () => {
    let result = await userDetailsModel.findAll({
        where: {
            $or: [
                { 'dep_id': 1 }
            ]
        }
    });
    result = result.map(row => {
        return {
            "name": `${row.dataValues.first_name} ${row.dataValues.last_name}`,
            "email": row.dataValues.email_address
        };
    });
    return result;
}

const getUsersFullNameAndType = async () => {

    let result = await userDetailsModel.findAll({
        attributes: ['user_id', [Sequelize.literal("first_name || ' ' || last_name"), 'fullname'], 'type'],
        where:{
            is_active: 'true'
        }
    })
    return result;
}

const getUserDepartmentName = async (userId) => {
    const result = await userDetailsModel.findAll({
        attributes: [
            ['desg_id', 'value'],
        ],
        include: [{
            model: designationModel,
            as: 'designation',
            required: true
        }],
        where: { 'user_id': { $in: userId } }
    });
 
    let designationArray = [];
    result.map(item => {
        designationArray.push({ 'value': item.dataValues.value, 'label': item.dataValues.designation.dataValues.des_name });
    });
 
    designationArray = Array.from(new Set(designationArray.map(s => s.value))).map(value => {
        return {
            value: value,
            label: designationArray.find(s => s.value === value).label
        };
    });
 
    return designationArray;
 };

const getUserByDesignation = async (designationId) => {
    const result = await userDetailsModel.findAll({
        attributes: [
            ['user_id', 'value'],
            [Sequelize.literal("first_name || ' ' || last_name"), 'label']
        ],
        where: { 'desg_id': { $in: designationId } }
    });
    return result;
};

const getReviewerIdforReviewee = async (revieweeId) => {

    const result = await stmModel.findAll({
        attributes: ['stm_reviewer_id'],
        include: [{
            model: userDetailsModel,
            as: 'reviewer',
            distinct:true,
            attributes: [
                [userDetailsModel.sequelize.literal("reviewer.first_name || ' ' || reviewer.last_name"), 'reviewer_name']
            ]
        }],
        where: { 'stm_reviewee_id': revieweeId },
    });
    return result;

};

module.exports = {
    getUserByEmail,
    getUserById,
    getAdminList,
    getAdminMailList,
    getUsersFullNameAndType,
    getUserByDesignation,
    getUserDepartmentName,
    getReviewerIdforReviewee
};
