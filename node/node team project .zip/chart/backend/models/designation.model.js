const {
    designationModel
} = require('../sequelizeModels/index');

"use strict";


const getAllDesignationNames = async () => {
    const result = await designationModel.findAll({
        attributes: [
            ['des_id', 'value'],
            ['des_name', 'label']
        ],
        where: {'is_active': true}
    });
    return result;
};

module.exports = {
    getAllDesignationNames
};