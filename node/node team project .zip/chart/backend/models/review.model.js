const {
    reviewModel
} = require('../sequelizeModels/index');

"use strict";

const getResponseData = async(mappingId) => {
    let result = await reviewModel.findOne({
        attributes: [
            ['r_ans_data', 'response'],
            ['r_score', 'revieweeScore']
        ],
        where: {
            'r_stm_id': mappingId
        }
    });
    return result;
}

const setResponseData = async(responseData) => {
    let result = await reviewModel.create({
        r_stm_id: responseData.sessionTemplateMappingId,
        r_ans_data: responseData.answerResponse,
        r_score: responseData.revieweeScore,
        created_by: responseData.userId,
        created_at: new Date(),
    });
    return result;
}

const updateResponseData = async(responseData) => {
    let result = await reviewModel.update({
        r_ans_data: responseData.answerResponse,
        r_score: responseData.revieweeScore,
        modified_by: responseData.userId,
        modified_at: new Date()
    }, {
        where: { r_stm_id: responseData.sessionTemplateMappingId }
    });

    return result;
}

module.exports = {
    getResponseData,
    setResponseData,
    updateResponseData
}
