let jwt = require('jsonwebtoken');
const config = require('./config');
const CryptoJS = require('crypto-js')
let checkToken = (request, response, next) => {
    let token = request.header('authorization');
    let validation = request.header('Validation');
    let role, email;
    validation = CryptoJS.AES.decrypt(validation, process.env.KEY);
    
    if (validation.toString()) {
        validation = JSON.parse(validation.toString(CryptoJS.enc.Utf8));
        role = validation.split(' ')[0];
        email = validation.split(' ')[1];
    }
    if (token && token.startsWith('Bearer ')) {
        token = token.slice(7, token.length);
    }

    if (token) {
        jwt.verify(token, config.secret, (error, decoded) => {
            if (error) {
                error.code = 'JWTFALSE';
                next(error);
            } else {
                if (validation !== undefined && email == decoded.Email && (role === 'All' || role === decoded.Role)) {
                    request.decoded = decoded;
                    next();
                } else {
                    let excessError = new Error();
                    excessError.code = 'ECONNREFUSED';
                    next(excessError);
                }
            }
        });
    } else {
        let error = Error();
        error.code = 'TOKENFALSE';
        next(error);
    }
};

module.exports = {
    checkToken: checkToken
};