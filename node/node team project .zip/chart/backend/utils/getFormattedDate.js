const getFormattedDate = function (date) {
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    let fDate = `${findOrdinal(date.getDate())} ${months[date.getMonth()]} ${date.getFullYear()}`;
    return fDate;
};

function findOrdinal(day) {
    if (day > 3 && day < 21) {
        return `${day}th`;
    } else {
        switch (day % 10) {
            case 1: return `${day}st`;
            case 2: return `${day}nd`;
            case 3: return `${day}rd`;
            default: return `${day}th`;
        }
    }
}

module.exports = getFormattedDate;
