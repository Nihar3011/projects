module.exports = {
  secret: 'TheArgusOftDeveLopErNeSt'
};