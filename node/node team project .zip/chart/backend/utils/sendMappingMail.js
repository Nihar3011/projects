const {
    getSessionsById
} = require('../models/session.model');
const {
    getUserById
} = require('../models/userInfo.model');
const path = require('path');
const fs = require("fs");
const email = require('./email');
const getFormattedDate = require('./getFormattedDate');
const _ = require("lodash");

const getEmailData = async (mailObject) => {
    let revieweeName = '';
    let reviewerNames = '';
    let reviewerList = await getUserById(mailObject.reviewerId);
    reviewerList = reviewerList.map(row => {
        reviewerNames = `${reviewerNames}, ${row.dataValues.first_name} ${row.dataValues.last_name}`;
        return {
            email: row.dataValues.email_address,
            name: `${row.dataValues.first_name} ${row.dataValues.last_name}`,
            referenceLink: `${process.env.REDIRECT_PATH}/fillReview/${mailObject.stmId}`
        }
    });
    let revieweeList = await getUserById(mailObject.revieweeId);
    revieweeList = revieweeList.map(row => {
        revieweeName = `${row.dataValues.first_name} ${row.dataValues.last_name}`;
        return {
            email: row.dataValues.email_address,
            name: `${row.dataValues.first_name} ${row.dataValues.last_name}`,
            referenceLink: row.dataValues.dep_id == 1 ? `${process.env.REDIRECT_PATH}/givereview` : `${process.env.REDIRECT_PATH}/dashboard`
        }
    })

    reviewerNames = reviewerNames.substr(1);

    const filePath = path.join(__dirname, '../', 'templates', 'emailTemplate.html');
    const mappingHTML = fs.readFileSync(filePath, 'utf8').toString();

    let reviewerSubject, revieweeSubject, emailTagReviewee, emailTagReviewer, bodyTitleReviewer, bodyTitleReviewee, sessionData;

    if (mailObject.reEvaluation === true) {
        sessionData = {
            deadline: mailObject.sessionEndingDate,
            name: mailObject.sessionName
        };
        reviewerSubject = `[Review] Re-review has been assigned to you in ${sessionData.name} session!`;
        revieweeSubject = `[Review] Re-review request is accepted for ${sessionData.name} session!`;
        emailTagReviewer = `You have been assigned to Re-review ${revieweeName} !`;
        emailTagReviewee = 'Your Re-revaluation request has been approved!';
        bodyTitleReviewer = 'Re-review Assigned';
        bodyTitleReviewee = 'Re-review Request Approved';
    } else {
        sessionData = await getSessionsById(mailObject.sessionId);
        sessionData = {
            deadline: sessionData.dataValues.s_ending_date,
            name: sessionData.dataValues.s_name
        };
        reviewerSubject = `[Review] New review is assigned for you in ${sessionData.name} session!`;
        revieweeSubject = `[Review] New review is scheduled for you in ${sessionData.name} session!`;
        emailTagReviewer = 'You have been assigned as Reviewer !';
        emailTagReviewee = 'You have been assigned as Reviewee !';
        bodyTitleReviewer = 'Review Assigned';
        bodyTitleReviewee = 'Review scheduled';
    }

    let emailBody = `<table style='width:100%;'><tr><td style='width: 140px; vertical-align: top;'>Session Name :</td><td><span style='font-weight: 600;'>${sessionData.name}</span></td></tr><tr><td style='width: 140px; vertical-align: top;'>Deadline :</td><td><span style='font-weight: 600;'>${getFormattedDate(new Date(sessionData.deadline))}</span></td></tr><tr><td style='width: 140px; vertical-align: top;'>Reviewers :</td><td><span style='font-weight: 600;'>${reviewerNames}</span></td></tr><tr><td style='width: 140px; vertical-align: top;'>Reviewees :</td><td><span style='font-weight: 600;'>${revieweeName}</span></td></tr><tr><td style='width: 140px; vertical-align: top;'>Message :</td><td><span style='font-weight: 600;'>${mailObject.mappingMessage}</span></td></tr></table>`;
    let reviewerData = {
        emailTag: emailTagReviewer,
        bodyTitle: bodyTitleReviewer,
        emailBody: emailBody
    };
    let revieweeData = {
        emailTag: emailTagReviewee,
        bodyTitle: bodyTitleReviewee,
        emailBody: emailBody
    };

    revieweeEmailData = {
        data: revieweeData,
        recipients: revieweeList,
        subject: revieweeSubject,
        html: mappingHTML
    }
    reviewerEmailData = {
        data: reviewerData,
        recipients: reviewerList,
        subject: reviewerSubject,
        html: mappingHTML
    }

    email(revieweeEmailData);
    email(reviewerEmailData);
}

module.exports = getEmailData;
