const Joi = require('joi');

// Generic Schema Models.

const emailSchema = Joi.string().email();
const integerSchema = Joi.number().integer();
const nameSchema = Joi.string().regex(/^[\w\- ][\w\- ]*$/i);
const descriptionSchema = Joi.string().regex(/^[\w! \n@$%&*()+\-=\[\]{};':"\\,.<>\/?]*$/i);
const dateSchema = Joi.date();
const searchSchema = Joi.string();

// Particular Schema Models as required by the APIs.

const loginSchema = Joi.object().keys({
    email: emailSchema.max(200).required()
});

const idSchema = Joi.object().keys({
    id: integerSchema.required()
});

const listSchema = Joi.object().keys({
    pageSize: integerSchema.allow('').optional(),
    pageIndex: integerSchema.allow('').optional(),
    search: searchSchema.allow('').optional(),
    status: integerSchema.allow('').optional(),
    sort: nameSchema.allow('').optional(),
    order: integerSchema.allow('').optional(),
    userId: integerSchema.optional(),
    sessionStatus: integerSchema.allow('').optional(),
    id: integerSchema.optional(),
    employee: Joi.array().items().optional(),
    designation: Joi.array().items().optional()
});

const deleteSchema = Joi.object().keys({
    id: integerSchema.required(),
    userId: integerSchema.required(),
    message: searchSchema.optional()
});

const sessionCreateUpdateSchema = Joi.object().keys({
    session_name: nameSchema.max(50).required(),
    review_cycle_frequency: integerSchema.valid(0, 1, 2, 3, 4, 6, 12).required(),
    session_description: descriptionSchema.max(400).allow('').optional(),
    session_starting_date: dateSchema.required(),
    session_ending_date: dateSchema.required(),
    session_version: integerSchema.required(),
    session_no_of_days: integerSchema.required(),
    created_by: integerSchema.allow('').optional(),
    modified_by: integerSchema.allow('').optional()
});

const commentSchema = Joi.object().keys({
    mappingId: integerSchema.required(),
    parentId: integerSchema.required(),
    comment: Joi.string().required(),
    userId: integerSchema.required(),
    commentVisibility: Joi.boolean().required()
});

const reevaluationConformationSchema = Joi.object().keys({
    mappingId: integerSchema.required(),
    commentId: integerSchema.required(),
    userId: integerSchema.required(),
    approval: Joi.boolean().required()
});

const commentIdListschema = Joi.object().keys({
    commentId: integerSchema.required(),
    visibility: Joi.boolean().optional(),
    systemGenerated: integerSchema.optional()
});

const templateInsertUpdateSchema = Joi.object().keys({
    templateName: nameSchema.max(50).trim().required(),
    templateStructure: Joi.array().items().required(),
    templateDescription: descriptionSchema.max(400).trim().required(),
    userId: integerSchema.required(),
    saveAsDraft: Joi.boolean().required(),
    isScorable: Joi.boolean().required(),
    canInterview: Joi.boolean().required()
});

const reviewResponseSchema = Joi.object().keys({
    sessionTemplateMappingId: integerSchema.required(),
    answerResponse: Joi.array().items().required(),
    userId: integerSchema.allow('').optional(),
    modifiedBy: integerSchema.allow('').optional(),
    revieweeScore: integerSchema.optional()
});

const reviewResponseSchemaUpdate = Joi.object().keys({
    sessionTemplateMappingId: integerSchema.required(),
    answerResponse: Joi.array().items().required(),
    userId: integerSchema.allow('').optional(),
    modifiedBy: integerSchema.allow('').optional(),
    oldData: Joi.array().items().required(),
    questionResponse: Joi.array().items().required(),
    userName: nameSchema.max(50).trim().required(),
    revieweeScore: integerSchema.optional()
});

const notificationListSchema = Joi.object().keys({
    userId: integerSchema.required(),
    scrollSize: integerSchema.allow('').optional(),
    flag: nameSchema.required()
});

const sessionMappingdetailsSchema = Joi.array().items(Joi.object().keys({
    primaryReviewer: Joi.object().keys({
        reviewer_id: Joi.number().integer().required(),
        reviewer_name: Joi.string().optional()
    }),
    secondaryReviewers: Joi.array().items(Joi.object().keys({
        reviewer_id: Joi.number().integer().optional(),
        reviewer_name: Joi.string().optional()
    })),
    template: Joi.object().keys({
        template_id: Joi.number().integer().required(),
        template_name: Joi.string().optional()
    }),
    reviewees: Joi.array().items(Joi.object().keys({
        reviewee_id: Joi.number().integer().required(),
        reviewee_name: Joi.string().optional()
    })),
}));

const nameValidationSchema = {
    name: nameSchema.required(),
    modelName: nameSchema.required(),
    isUpdate: integerSchema.optional()
}

const chartInsertSchema = Joi.object().keys({
    chartType: nameSchema.max(50).trim().required(),
    chartTitle: nameSchema.max(50).trim().required(),
    xAxisTitle: nameSchema.max(50).trim().allow('').optional(),
    xAxisField: nameSchema.max(50).trim().allow('').optional(),
    yAxisField: nameSchema.max(50).trim().allow('').optional(),
    filterData: Joi.array().items().required(),
    viewToggle: Joi.boolean().required(),
    userId: integerSchema.required()
});
const chartReorderSchema = Joi.object().keys({
    rowPerPage: integerSchema.required(),
    charts: Joi.array().items().required(),
    pageIndex: integerSchema.required()
});

module.exports = {
    loginSchema,
    idSchema,
    listSchema,
    deleteSchema,
    sessionCreateUpdateSchema,
    commentIdListschema,
    templateInsertUpdateSchema,
    reviewResponseSchema,
    reviewResponseSchemaUpdate,
    notificationListSchema,
    sessionMappingdetailsSchema,
    commentSchema,
    nameValidationSchema,
    chartInsertSchema,
    reevaluationConformationSchema,
    chartReorderSchema
};