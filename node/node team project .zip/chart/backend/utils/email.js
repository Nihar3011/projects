const nodemailer = require("nodemailer");
const async = require("async");
const ejs = require('ejs');
const process = require('process');
require('dotenv').config();

let smtpTransport = nodemailer.createTransport({
    service: process.env.MAIL_SERVICE,
    host: process.env.MAIL_HOST,
    auth: {
        user: process.env.MAIL_USERNAME,
        pass: process.env.MAIL_PASSWORD
    }
});

function email(emailData) {
    let mailOptions;
    async.forEach(emailData.recipients, function (element) {
        emailData.data.recipient_name = element.name;
        emailData.data.referenceLink = element.referenceLink
        emailHTML = ejs.render(emailData.html, emailData.data);

        mailOptions = {
            to: element.email,
            subject: emailData.subject,
            html: emailHTML
        }
        smtpTransport.sendMail(mailOptions);
    });
}

module.exports = email;