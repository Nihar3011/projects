const sequalize = require('sequelize');
const path = require('path');
const fs = require("fs");
const email = require('./email');
const _ = require("lodash");

const getFormattedDate = require('../utils/getFormattedDate');
const sendSessionMail = require('./sendSessionMail');
const {
    updateSession,
    getSessionStartingToday,
    getSessionEndingBeforeNthDay
} = require('../models/session.model');
const {
    getPendingReviewList,
    getMappingIdBySessionId
} = require('../models/sessionTemplateMapping.model');
const SessionTemplateMapping = require('../controllers/sessionTemplateMapping.controller');
const { getSecondaryReviewersList } = require('../models/secondaryReviewer.model');

async function activateSession() {
    try {
        let result = await getSessionStartingToday();

        let updateIds = [];
        let sessionData = result;
        result.forEach((object) => {
            updateIds.push(object.dataValues.s_id);
        });
        if (updateIds.length != 0) {
            let updateResult = await updateSession({
                s_status: 1,
                s_version: sequalize.literal('s_version+1'),
                s_ending_date: sequalize.literal("s_starting_date + s_no_of_days * interval '1 day'")
            }, updateIds);
            _.map(sessionData, async function (object) {
                let mappings = await getMappingIdBySessionId(object.dataValues.s_id);
                let addResponse = await addMappings(mappings, object.dataValues);
                sendSessionMail({
                    subject: 'New session is created',
                    session: object.dataValues,
                    emailTag: 'New session has been created',
                    bodyTitle: 'Created session'
                });
            });
        }
    } catch (error) { }
}

async function addMappings(mappings, sessionData) {
    _.map(mappings, async function (object) {
        let secondaryReviewersList = await getSecondaryReviewersList(object.dataValues.stm_id);
        let primaryReviewer = { reviewer_id: object.dataValues.stm_reviewer_id };

        let secondaryReviewers = [];
        _.map(secondaryReviewersList, async function (object) {
            secondaryReviewers.push({ reviewer_id: object });
        })
        let reviewees = [{ reviewee_id: object.dataValues.stm_reviewee_id }];
        let template = { template_id: object.dataValues.stm_template_id };

        let objectIds = {
            primaryReviewer: primaryReviewer,
            secondaryReviewers: secondaryReviewers,
            reviewees: reviewees,
            template: template
        }
        let mapObject = {
            sessionId: sessionData.s_id,
            sessionVersion: sessionData.s_version + 1,
            mappingBody: [objectIds],
            userId: object.dataValues.created_by
        }
        let responseMessage = await SessionTemplateMapping.addMappingData(mapObject);
        return responseMessage;
    });
}

async function deactivateSession() {
    try {
        let result = await getSessionEndingBeforeNthDay(1);
        let updateIds = [];

        result.forEach((object) => {
            updateIds.push(object.dataValues.s_id);
        });
        if (updateIds.length != 0) {
            let updateResult = await updateSession({
                s_status: 2,
                s_starting_date: sequalize.literal("s_starting_date + s_frequency * interval '1 month'")
            }, updateIds);
        }
    } catch (error) { }
}

async function sendMailNotification() {
    try {
        let result = await getSessionEndingBeforeNthDay(5);
        let sessionIds = [];
        sessionIds = _.map(result, 's_id');

        if (sessionIds.length != 0) {
            let pandingReview = await getPendingReviewList(sessionIds);
            _.map(pandingReview, function (object) {
                sendMail({
                    sessionName: object.dataValues.sessions.dataValues.session_name,
                    sessionDeadline: object.dataValues.sessions.dataValues.deadline,
                    name: object.dataValues.reviewer.dataValues.reviewer_name,
                    email: object.dataValues.reviewer.dataValues.reviewer_mail,
                    revieweeName: object.dataValues.reviewee.dataValues.reviewee_name,
                    referenceLink: `${process.env.REDIRECT_PATH}/fillReview/${object.dataValues.stm_id}`
                });
            });
        }
    } catch (error) { }
}

async function sendMail(mailObject) {
    const filePath = path.join(__dirname, '../', 'templates', 'emailTemplate.html');
    const mappingHTML = await fs.readFileSync(filePath, 'utf8').toString();

    let reviewerSubject = `[Review] Review is pending to submit for ${mailObject.revieweeName}`;
    let emailBody = `<table style='width:100%;'><tr><td style='width: 140px; vertical-align: top;'>Session Name :</td><td><span style='font-weight: 600;'> ${mailObject.sessionName} </span></td></tr><tr><td style='width: 140px; vertical-align: top;'>Deadline :</td><td><span style='font-weight: 600;'> ${getFormattedDate(new Date(mailObject.sessionDeadline))} </span></td></tr><tr><td style='width: 140px; vertical-align: top;'>Reviewee Name :</td><td><span style='font-weight: 600;'> ${mailObject.revieweeName} </span></td></tr></table>`;

    let emailData = {
        emailTag: 'Review to be given by you are still pending !',
        bodyTitle: 'Review pending',
        emailBody: emailBody
    };

    reviewerEmailData = {
        data: emailData,
        recipients: [mailObject],
        subject: reviewerSubject,
        html: mappingHTML
    }

    return email(reviewerEmailData);
}

module.exports = {
    activateSession,
    deactivateSession,
    sendMailNotification
};