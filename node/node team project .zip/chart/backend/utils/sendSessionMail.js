const email = require('./email');
const { getAdminMailList } = require('../models/userInfo.model');
const { getFrequency } = require('../models/session.model');
const fs = require('fs');
const path = require('path');
const getFormattedDate = require('./getFormattedDate');

const sendSessionMail = async (mailObject) => {

    let recipients = await getAdminMailList();
    recipients = recipients.map(row => {
        row['referenceLink'] = `${process.env.REDIRECT_PATH}/list-sessions`;
        return row;
    })
    
    const filePath = path.join(__dirname, '../', 'templates', 'emailTemplate.html');
    const createHTML = fs.readFileSync(filePath, 'utf8').toString();
    const subject = `[Review] ${mailObject.subject} - ${mailObject.session.s_name}`;
    const emailBody = `<table style='width:100%;'><tr><td style='width: 140px; vertical-align: top;'>Session Name :</td><td><span style='font-weight: 600;'>${mailObject.session.s_name}</span></td></tr><tr><td style='width: 140px; vertical-align: top;'>Description :</td><td><span style='font-weight: 600;'>${mailObject.session.s_description}</span></td></tr><tr><td style='width: 140px; vertical-align: top;'>Frequency :</td><td><span style='font-weight: 600;'>${getFrequency(mailObject.session.s_frequency)}</span></td></tr><tr><td style='width: 140px; vertical-align: top;'>Starting date :</td><td><span style='font-weight: 600;'>${getFormattedDate(new Date(mailObject.session.s_starting_date))}</span></td></tr><tr><td style='width: 140px; vertical-align: top;'>Ending date :</td><td><span style='font-weight: 600;'>${getFormattedDate(new Date(mailObject.session.s_ending_date))}</span></td></tr></table>`;
    const data = {
        emailTag: mailObject.emailTag,
        bodyTitle: mailObject.bodyTitle,
        emailBody: emailBody
    };
    const emailData = {
        data: data,
        recipients: recipients,
        subject: subject,
        html: createHTML
    };
    email(emailData);
};

module.exports = sendSessionMail;