const bodyParser = require('body-parser');
const login = require('./routes/login.routing.js');
const review = require('./routes/review.routing');
const session = require('./routes/session.routing');
const template = require('./routes/template.routing');
const user = require('./routes/user.routing');
const reportAnalysis = require('./routes/reportAnalysis.routing');
const designation = require('./routes/designation.routing');
const notification = require('./routes/notification.routing');
const chart = require('./routes/chart.routing');

const errorHandle = require('./utils/errorHandle');
const app = require('express')();
const server = require('http').createServer(app);
const io = require('socket.io')(server, { path: `/review-api/socket.io/` });
const process = require('process');
io.on('connection', (socket) => {
    socket.on('new-message', (message) => {
        //waiting for 5 seconds if there are large number of notifications to be inserted
        setTimeout(() => io.emit('new-message', message), 5000);
    });
});

const middleware = require('./utils/middleware');
const cors = require('cors');
const schedulers = require('./utils/schedulers');
const cron = require('node-cron');
const nameValidation = require('./controllers/validation.controller');
require('dotenv').config();

app.disable('x-powered-by');
app.use(bodyParser.json());
app.use(
    bodyParser.urlencoded({
        extended: true,
    })
);
cron.schedule('1 0 0 * * *', function () {
    schedulers.activateSession.call(this);
    schedulers.deactivateSession.call(this);
    schedulers.sendMailNotification.call(this);
});

app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

app.options('*', cors());

app.use(`${process.env.CONTEXT_PATH}/login`, login);

app.use(`${process.env.CONTEXT_PATH}/*`, middleware.checkToken);
app.use(`${process.env.CONTEXT_PATH}/review`, review);
app.use(`${process.env.CONTEXT_PATH}/session`, session);
app.use(`${process.env.CONTEXT_PATH}/template`, template);
app.use(`${process.env.CONTEXT_PATH}/user`, user);
app.use(`${process.env.CONTEXT_PATH}/designation`, designation);
app.use(`${process.env.CONTEXT_PATH}/analysis`, reportAnalysis);
app.use(`${process.env.CONTEXT_PATH}/notification`, notification);
app.use(`${process.env.CONTEXT_PATH}/nameValidation`, nameValidation.nameValidator);
app.use(`${process.env.CONTEXT_PATH}/chart`, chart);

app.use(function (req, res) {
    res.status(404)
        .json({
            error: 'Oops!!! No routes found.',
            code: 404
        });
});

app.use(function (error, req, res, next) {
    res.status(error.status || 500)
        .json({
            error: errorHandle(error),
            code: error.code
        });
});

server.listen(process.env.SERVER_PORT);
