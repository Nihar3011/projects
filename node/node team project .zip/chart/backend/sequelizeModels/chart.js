module.exports = (sequelize, DataTypes) => {
    return sequelize.define('chart', {
        c_id: {
            type: DataTypes.INTEGER,
            primaryKey: true
        },
        c_type: {
            type: DataTypes.STRING,
            allowNull: false
        },
        c_title: {
            type: DataTypes.STRING,
            allowNull: false
        },
        c_x_title: {
            type: DataTypes.STRING,
            allowNull: true
        },
        c_x_field: {
            type: DataTypes.STRING,
            allowNull: false
        },
        c_y_field: {
            type: DataTypes.STRING,
            allowNull: false,
            defaultValue: 'score'
        },
        c_data: {
            type: DataTypes.JSON,
            allowNull: false
        },
        c_view_toggle: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: false
        },
        c_is_deleted: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: false
        },
        created_by: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        created_at: {
            type: DataTypes.DATE,
            allowNull: false
        },
        modified_by: {
            type: DataTypes.INTEGER,
            allowNull: true
        },
        c_order: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        modified_at: {
            type: DataTypes.DATE,
            allowNull: true
        }
    }, {
        tableName: 'chart',
        schema: process.env.ERS_SCHEMA_NAME
    });
};