module.exports = function (sequelize, DataTypes) {
	return sequelize.define('reviews', {
		r_id: {
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true,
			autoIncrement: true
		},
		r_stm_id: {
			type: DataTypes.INTEGER,
			allowNull: false
		},
		r_ans_data: {
			type: DataTypes.JSON,
			allowNull: false
		},
		r_score: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: 0
		},
		created_by: {
			type: DataTypes.INTEGER,
			allowNull: false
		},
		created_at: {
			type: DataTypes.DATE,
			allowNull: false
		},
		modified_by: {
			type: DataTypes.INTEGER,
			allowNull: true
		},
		modified_at: {
			type: DataTypes.DATE,
			allowNull: true
		}
	}, {
		tableName: 'reviews',
		schema: process.env.ERS_SCHEMA_NAME
	});
};
