const validator = require('../utils/validation');
const {
    nameValidationSchema
} = require('../utils/schemas');

const {
    sessionNameValidation
} = require('../models/session.model');
const {
    templateNameValidator
} = require('../models/template.model');

"use strict";

class Login {
    constructor() {}

    static nameValidator(request, response, next) {
        validator(request.query, nameValidationSchema, async function (error, value) {
            if (error) {
                next(error);
            } else {
                if (request.query.modelName === 'template') {
                    let result = await templateNameValidator(request.query.name, request.query.isUpdate)
                    response.status(200).json(result!=0)
                } else if (request.query.modelName === 'session') {
                    let result = await sessionNameValidation(request.query.name, request.query.isUpdate)
                    response.status(200).json(result!=0)
                } else {
                    let modelError = new Error();
                    modelError.code = '404'
                    next(modelError);
                }
            }
        });
    }
}

module.exports = Login;