const validator = require('../utils/validation');
const { listSchema } = require('../utils/schemas');

const {
  getReviewerMappingList,
  getRevieweeMappingList
} = require('../models/sessionTemplateMapping.model');
const {
  getUserById,
  getUsersFullNameAndType,
  getUserByDesignation,
  getUserDepartmentName,
  getReviewerIdforReviewee
} = require('../models/userInfo.model');
"use strict";

class User {
  constructor() { }

  static getRevieweeMappingList(request, response, next) {
    validator(request.body, listSchema, async function (error, value) {
      if (error) {
        next(error);
      } else {
        let { pageSize, pageIndex, search, status, sort, order, userId } = request.body;
        pageIndex = pageIndex || process.env.PAGE_INDEX;
        pageSize = pageSize || process.env.PAGE_SIZE;
        const offset = (pageIndex - 1) * pageSize;

        if ((search || '').includes("%")) {
          response.status(200).json(Object.assign({}, [0, []]));
        }
        else {
          try {
            let result = await getRevieweeMappingList(status, sort, order, search, userId);
            let length = result.length;
            let data = result.slice(offset, (pageIndex * pageSize));
            let newData = data.map(element => {
              return {
                "session_template_mapping_id": element.stm_id,
                "template_id": element.stm_template_id,
                "reviewee_id": element.stm_reviewee_id,
                "status": element.stm_status,
                "template_name": element.templates.dataValues.t_name,
                "name": element.reviewee.dataValues.reviewee_name,
                "session_name": element.sessions.dataValues.s_name,
                "deadline": element.sessions.dataValues.s_ending_date,
                "isPrimary": element.stm_reviewer_id != userId ? false : true
              };
            });
            response.status(200).json(Object.assign({}, [length, newData]));
          } catch (error) {
            next(error);
          }
        }
      }
    });
  }

  static getReviewerMappingList(request, response, next) {
    validator(request.body, listSchema, async function (error, value) {
      if (error) {
        next(error);
      } else {
        let { pageSize, pageIndex, search, status, sort, order, userId } = request.body;
        pageIndex = pageIndex || process.env.PAGE_INDEX;
        pageSize = pageSize || process.env.PAGE_SIZE;
        let offset = (pageIndex - 1) * pageSize;

        if ((search || '').includes("%")) {
          response.status(200).json(Object.assign({}, [0, []]));
        }
        else {
          try {
            let result = await getReviewerMappingList(status, sort, order, search, userId);
            let length = result.length;
            let data = result.slice(offset, (pageIndex * pageSize));
            let newData = data.map(element => {
              return {
                "session_template_mapping_id": element.stm_id,
                "template_id": element.stm_template_id,
                "reviewer_id": element.stm_reviewer_id,
                "status": element.stm_status,
                "template_name": element.templates.dataValues.t_name,
                "name": element.reviewer.dataValues.reviewer_name,
                "session_name": element.sessions.dataValues.s_name,
                "deadline": element.sessions.dataValues.s_ending_date
              };
            });
            response.status(200).json(Object.assign({}, [length, newData]));
          } catch (error) {
            next(error);
          }
        }
      }
    });
  }

  static async getUserRole(userId) {
    let result = await getUserById([userId]);
    return result[0].dataValues.dep_id == 1 ? 'ROLE_SADMIN' : 'ROLE_MEMBER';
  }

  static async getUserName(userId) {
    let result = await getUserById([userId]);
    return (`${result[0].dataValues.first_name} ${result[0].dataValues.last_name}`).trim();
  }

  static async getUserDetailsList(userIdList) {
    let result = await getUserById(userIdList);
    result = result.map(element => {
      return {
        name: (`${element.dataValues.first_name} ${element.dataValues.last_name}`).trim(),
        email: element.dataValues.email_address
      };
    });
    return result;
  }
  static async getUsersFullNameAndType(request, response, next) {
    if(request.decoded.Role == 'ROLE_SADMIN'){
      try {
        let result = await getUsersFullNameAndType();
        let members = [];
        result.forEach(element => {
          let member = {
            "user_id": element.dataValues.user_id,
            "fullname": element.dataValues.fullname,
            "type": element.dataValues.type
          };
          members.push(member);
        });
        response.status(200).json(Object.assign({}, { 'member': members }));
      }
      catch (error) {
        next(error);
      }
    } else {
        let error = new Error();
        error.code = 'UNAUTHORIZEDACCESS';
        next(error);    
    }
  }

  static async getUserDepartmentName(request, response, next) {
    if(request.decoded.Role == 'ROLE_SADMIN'){
      try {
        let result = await getUserDepartmentName(request.query.userId.split(','));
        response.status(200).json(result);
      } catch (error) {
        next(error);
      }
    } else {
        let error = new Error();
        error.code = 'UNAUTHORIZEDACCESS';
        next(error);    
    }
  }

  static async getReviewerIdForReviewee(request, response, next) {
    try {
      let result = await getReviewerIdforReviewee(request.params.id);
      result = result.map(data => {
        return {
          value: data.dataValues.stm_reviewer_id,
          label: data.dataValues.reviewer.dataValues.reviewer_name
        };
      });
      result = Array.from(new Set(result.map(s => s.value))).map(value => {
        return {
          value: value,
          label: result.find(s => s.value === value).label
        };
      });
      response.status(200).send(result);
    } catch (error) {
      next(error);
    }
  }

  static async getUserByDesignation(request, response, next) {
    if(request.decoded.Role == 'ROLE_SADMIN'){
      try {
        let result = await getUserByDesignation(request.query.designationId.split(','));
        response.status(200).json(result);
      } catch (error) {
        next(error);
      }
    } else {
        let error = new Error();
        error.code = 'UNAUTHORIZEDACCESS';
        next(error);    
    }
  }
}

module.exports = User;
