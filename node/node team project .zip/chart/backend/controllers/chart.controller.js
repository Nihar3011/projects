const validator = require('../utils/validation');
const {
  chartInsertSchema,
  listSchema,
  deleteSchema,
  chartReorderSchema
} = require('../utils/schemas');

const {
  createChart,
  getCharts,
  getChartsList,
  updateChart,
  getChartByChartId,
  reorderCharts
} = require('../models/chart.model');
"use strict";

class Chart {
  constructor() {}
  static chartInsert(request, response, next) {
    validator(request.body, chartInsertSchema, async function (error, value) {
      if (error) {
        next(error);
      } else {
        try {
          let {
            chartType,
            chartTitle,
            xAxisTitle,
            xAxisField,
            yAxisField,
            filterData,
            userId,
            viewToggle
          } =
          request.body;

          let responseMessage = "Chart created successfuly";
          let result = await createChart({
            c_type: chartType,
            c_title: chartTitle,
            c_x_title: xAxisTitle,
            c_x_field: xAxisField,
            c_y_field: yAxisField,
            c_data: filterData,
            c_view_toggle: viewToggle,
            created_by: userId,
            created_at: new Date()
          });
          if (result) {
            response.status(200).json(responseMessage);
          } else {
            let error = new Error();
            error.code = 'UNAUTHORIZEDACCESS';
            next(error);
          }
        } catch (error) {
          console.log(error);

          next(error);
        }
      }
    });
  }

  static async getCharts(request, response, next) {
    try {
      const userRole = request.decoded.Role;
      const validationFlag = (userRole == 'ROLE_SADMIN');
      let result;
      if (validationFlag) {
        result = await getCharts();
        if (!result) {
          let error = new Error();
          error.code = 'NORECORD';
          next(error);
        } else {
          let returnResponse = result.map(data => {
            return {
              chartType: data.dataValues.c_type,
              chartTitle: data.dataValues.c_title,
              xAxisTitle: data.dataValues.c_x_title,
              xAxisField: data.dataValues.c_x_field,
              yAxisField: data.dataValues.c_y_field,
              filterData: data.dataValues.c_data,
              viewToggle: data.dataValues.c_view_toggle
            }
          });
          response.status(200).json(returnResponse);
        }
      } else {
        let error = new Error();
        error.code = 'UNAUTHORIZEDACCESS';
        next(error);
      }
    } catch (error) {
      next(error);
    }
  }

  static getChartList(request, response, next) {
    validator(request.query, listSchema, async function (error, value) {
      if (error) {
        next(error);
      } else {
        if (request.decoded.Role == 'ROLE_SADMIN') {
          try {
            let {
              pageSize,
              pageIndex
            } = request.query;
            pageIndex = pageIndex || process.env.PAGE_INDEX;
            pageSize = pageSize || process.env.PAGE_SIZE;
            let offset = (pageIndex - 1) * pageSize;

            let result = await getChartsList();
            let returnResponse = result.slice(offset, (pageIndex * pageSize));
            returnResponse = returnResponse.map(data => {
              return {
                chartId: data.dataValues.c_id,
                chartType: data.dataValues.c_type,
                chartTitle: data.dataValues.c_title,
                xAxisTitle: data.dataValues.c_x_title,
                xAxisField: data.dataValues.c_x_field,
                yAxisField: data.dataValues.c_y_field,
                filterData: data.dataValues.c_data,
                viewToggle: data.dataValues.c_view_toggle,
                chartMaker: data.dataValues.charts.dataValues.name,
                creationTime: data.dataValues.created_at
              }
            });
            response.status(200).json(Object.assign({}, [result.length, returnResponse]));
          } catch (error) {
            next(error);
          }
        } else {
          let error = new Error();
          error.code = 'UNAUTHORIZEDACCESS';
          next(error);
        }
      }
    });
  }

  static deleteChartById(request, response, next) {
    validator(request.query, deleteSchema, async function (error, value) {
      if (error) {
        next(error);
      } else {
        if (request.decoded.Role == 'ROLE_SADMIN') {
          try {
            let {
              id,
              userId
            } = request.query;
            let result = await updateChart({
              c_is_deleted: true,
              modified_by: userId,
              modified_at: new Date()
            }, id);
            response.status(200).json({
              "message": "Chart deleted succesfully !!"
            });
          } catch (error) {
            next(error);
          }
        } else {
          let error = new Error();
          error.code = 'UNAUTHORIZEDACCESS';
          next(error);
        }
      }
    });
  }

  static updateChartById(request, response, next) {
    validator(request.body, chartInsertSchema, async function (error, value) {
      if (error) {
        next(error);
      } else {
        if (request.decoded.Role == 'ROLE_SADMIN') {
          try {
            let bodyData = request.body;
            let result = await updateChart({
              c_type: bodyData.chartType,
              c_title: bodyData.chartTitle,
              c_x_title: bodyData.xAxisTitle,
              c_x_field: bodyData.xAxisField,
              c_y_field: bodyData.yAxisField,
              c_data: bodyData.filterData,
              c_view_toggle: bodyData.viewToggle,
              modified_by: bodyData.userId,
              modified_at: new Date(),
            }, bodyData.chartId);
            response.status(200).json({
              "message": "Chart updated succesfully !!"
            });
          } catch (error) {
            console.log(error);
            
            next(error);
          }
        } else {
          let error = new Error();
          error.code = 'UNAUTHORIZEDACCESS';
          next(error);
        }
      }
    });
  }

  static async reorderCharts(request, response, next) {
    validator(request.body, chartReorderSchema, async function (error, value) {
      if (error) {
        next(error);
      } else {
        try {
          const userRole = request.decoded.Role;
          const validationFlag = (userRole == 'ROLE_SADMIN');
          let result;
          if (validationFlag) {
            let pageSize = request.body.pageSize;
            let pageIndex = request.body.pageIndex;
            let chartsData = request.body.charts.map(async (chart, index) => {
              // let data = {
              //   'c_id': chart.c_id,
              //   'c_order': (index + 1 + ((pageIndex - 1) * pageSize))
              // };
              result = await reorderCharts(chart.c_id, (index + 1 + ((pageIndex - 1) * pageSize)));

            });
            //result = await reorderCharts(request.body.charts);
            if (!result) {
              let error = new Error();
              error.code = 'NORECORD';
              next(error);
            } else {
              response.status(200).json("Reorder Successed");
            }
          } else {
            let error = new Error();
            error.code = 'UNAUTHORIZEDACCESS';
            next(error);
          }
        } catch (error) {
          console.log(error);

          next(error);
        }
      }
    });
  }
}

module.exports = Chart;