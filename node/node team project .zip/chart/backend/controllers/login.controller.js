let jwt = require('jsonwebtoken');
const config = require('../utils/config');
const validator = require('../utils/validation');
const { loginSchema } = require('../utils/schemas');

const {
  getUserByEmail
} = require('../models/userInfo.model');

const {
  getUserRole
} = require('../controllers/user.controller');

"use strict";

class Login {
  constructor() { }

  static userValidation(request, response, next) {
    validator(request.params, loginSchema, async function (error, value) {
      if (error) {
        next(error);
      } else {
        try {
            let result = await getUserByEmail(request.params.email);
            if (result !== null) {
              let userRole = await getUserRole(result.dataValues.user_id);
              let token = jwt.sign({
                Email: request.params.email,
                Role: userRole
              },
                config.secret, {
                  expiresIn: '15d'
                }
              );
              
              response.status(200).json({
                "user_id": result.user_id,
                "full_name": result.dataValues.fullname,
                "role": result.dep_id == 1 ? 'ROLE_SADMIN' : 'ROLE_MEMBER',
                "active_status": result.is_active,
                "designation": result.designation.des_name,
                "token": token
              });
            } else {
              let error = new Error();
              error.code = 'LOGINFALSE';
              next(error);
            }
          } catch (error) {
            next(error);
          }
        }
    });
  }
}

module.exports = Login;