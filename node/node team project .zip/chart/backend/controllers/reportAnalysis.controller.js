const {
  sessionVersionLogs,
  analysisDashboard
} = require('../models/reportAnalysis.model');
const {
  getSessionCountWithVersion,
} = require('../models/session.model');
"use strict";

class reportAnalysis {
  constructor() {}

  static async dashboardAnalysis(request, response, next) {
    if(request.decoded.Role == 'ROLE_SADMIN'){
      try {
        const monthNames = ["January", "February", "March", "April", "May", "June",
          "July", "August", "September", "October", "November", "December"
        ];
        const sortField = [{
            value: 'stm_id',
            label: 0
          }, {
            value: 'stm_template_id',
            label: 1
          }, {
            value: 'created_at',
            label: 2
          },
          {
            value: 'stm_reviewee_id',
            label: 3
          }
        ]
        let selectedSortField = (sortField[request.body.sortField].value === 4) ? 3 : sortField[request.body.sortField].value;
  
        
        const result = await analysisDashboard(request.body.data, selectedSortField);
        let sessionList = [];
        let templateList = [];
        let designationList = [];
        let monthYearList = [];
  
        let returnResponse = result.map(data => {
          const x = [data.dataValues.reviews[0].dataValues['r_score']];
          if (!sessionList.includes(data.dataValues.sessions.dataValues.sessionName)) {
            sessionList.push(data.dataValues.sessions.dataValues.sessionName);
          }
          if (!templateList.includes(data.dataValues.templates.dataValues.t_name)) {
            templateList.push(data.dataValues.templates.dataValues.t_name);
          }
          if (!designationList.includes(data.dataValues.reviewee.dataValues.designation.dataValues.des_name)) {
            designationList.push(data.dataValues.reviewee.dataValues.designation.dataValues.des_name);
          }
          if (!templateList.includes(data.dataValues.templates.dataValues.t_name)) {
            templateList.push(data.dataValues.templates.dataValues.t_name);
          }
          let monthYear = `${monthNames[data.dataValues.reviews[0].dataValues['created_at'].getMonth()]}-${data.dataValues.reviews[0].dataValues['created_at'].getFullYear()}`;
          if (!monthYearList.includes(monthYear)) {
            monthYearList.push(monthYear);
          }
          return {
            stmId: data.dataValues.stm_id,
            score: (data.dataValues.templates.dataValues.t_score != 0) ? ((x) / (data.dataValues.templates.dataValues.t_score) * 100).toFixed(4) : 0,
            username: data.dataValues.reviewee.dataValues.reviewee_name,
            reviewer: data.dataValues.reviewer.dataValues.reviewer_name,
            designation: data.dataValues.reviewee.dataValues.designation.dataValues.des_name,
            sessionName: data.dataValues.sessions.dataValues.sessionName,
            templateName: data.dataValues.templates.dataValues.t_name,
            month: monthYear
          };
        });
        if (request.body.data.filter == true && request.body.data.score.length != 0) {
          returnResponse = returnResponse.filter(data => {
            if (data.score >= request.body.data.score[0] && data.score <= request.body.data.score[1]) {
              return true;
            }
          });
        }
        response.status(200).json({
          "returnResponse": returnResponse,
          'sessionList': sessionList,
          'templateList': templateList,
          'monthYearList': monthYearList,
          'designationList': designationList
        });
      } catch (error) {
        next(error);
      }
    } else {
        let error = new Error();
        error.code = 'UNAUTHORIZEDACCESS';
        next(error);    
    }
  }
  static async getSessionVersionsLog(request, response, next) {
    try {
      const result = await sessionVersionLogs(Number(request.params.id));
      response.status(200).json(result);
    } catch (error) {
      next(error);
    }
  }
}

module.exports = reportAnalysis;