const {
    getAllDesignationNames
} = require('../models/designation.model');
"use strict";

class Designation {
    constructor() { }

    static async getDesignationNames(request, response, next) {
        if(request.decoded.Role == 'ROLE_SADMIN'){
            try {
                const result = await getAllDesignationNames();
                response.status(200).json(result);
            } catch (error) {
                next(error);
            }
        } else {
            let error = new Error();
            error.code = 'UNAUTHORIZEDACCESS';
            next(error);    
        }
    }
}
module.exports = Designation;