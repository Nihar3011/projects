const validator = require('../utils/validation');
const {
    idSchema,
    commentSchema,
    commentIdListschema
} = require('../utils/schemas');

const {
    getCommentsList,
    storeComment,
    updateComment
} = require('../models/comment.model');
const {
    getAdminList
} = require('../models/userInfo.model');
const {
    storeNotificationData
} = require('../models/notification.model');
const user = require('./user.controller');
const sessionTemplateMapping = require('./sessionTemplateMapping.controller');

"use strict";

class Comment {
    constructor() { }

    static async sendNotification(userId, mappingId) {
        let userName = await user.getUserName(userId);
        let userRole = await user.getUserRole(userId);
        let redirectionLink;
        let message;
        let commentList = [];
        if (userRole != 'ROLE_SADMIN') {
            commentList = await getAdminList(userId);
            redirectionLink = `${mappingId}`;
            message = `${userName} has commented on a review`;
        } else {
            commentList = [await sessionTemplateMapping.getReviewerIdByMappingId(mappingId)];
            redirectionLink = `${mappingId}`;
            message = `${userName} has commented on a review submitted by you`;
        }

        commentList = commentList.map(userId => {
            return {
                "nd_type": 9,
                "created_at": new Date(),
                "nd_for": userId,
                "nd_ref": redirectionLink,
                "nd_message": message,
                "nd_header": 'Comment on review'
            }
        });
        storeNotificationData(commentList);
    }

    static storeComment(request, response, next) {
        validator(request.body, commentSchema, async function(error, value) {
            if (error) {
                next(error);
            } else {
                try {
                    request.body["systemGenerated"] = 1;
                    let sendResult = await storeComment(request.body);
                    if (request.body.parentId == 0) {
                        let id = sendResult.dataValues.c_id;
                        let updateResult = await updateComment({ c_parent: id }, id);
                    }
                    response.status(200).json({ "message": "comment sent successfully" });
                    Comment.sendNotification(request.body.userId, request.body.mappingId);
                } catch (error) {
                    next(error);
                }
            }
        });
    }

    static updateComment(request, response, next) {
        validator(request.body, commentIdListschema, async function(error, value) {
            if (error) {
                next(error);
            } else {
                if(request.decoded.Role == 'ROLE_SADMIN'){
                    try {
                        let updateData = {
                            ...(request.body.systemGenerated == undefined ? {
                                c_visible: request.body.visibility
                            } : {
                                c_system_generated: request.body.systemGenerated
                            })
                        };               
                        let updateResult = await updateComment( updateData, request.body.commentId);
                        response.status(200).json({ "message": "comments updated successfully" });
                    } catch (error) {
                        next(error);
                    }
                } else {
                    let error = new Error();
                    error.code = 'UNAUTHORIZEDACCESS';
                    next(error);    
                }
            }
        })
    }

    static getComments(request, response, next) {
        validator(request.params, idSchema, async function(error, value) {
            if (error) {
                next(error);
            } else {
                try {
                    let result = await getCommentsList(request.params.id);
                    if (!result) {
                        let error = new Error();
                        error.code = 'NORECORD';
                        next(error);
                    } else {
                        result = result.map(element => {
                            return {
                                "commentId": element.dataValues.c_id,
                                "parentId": element.dataValues.c_parent,
                                "comment": element.dataValues.c_data,
                                "visibility": element.dataValues.c_visible,
                                "creationTime": element.dataValues.created_at,
                                "sender": element.createdBy.dataValues.user,
                                "senderId": element.createdBy.dataValues.userId,
                                "systemGeneratedFlag": element.dataValues.c_system_generated != 1,
                                "reevaluationFlag": element.dataValues.c_system_generated == 3
                            }
                        });
                        response.status(200).json(result);
                    }
                } catch (error) {
                    next(error);
                }
            }
        })
    }
}

module.exports = Comment;
