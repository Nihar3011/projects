const diff = require('deep-diff');
const validator = require('../utils/validation');
const {
    idSchema,
    deleteSchema,
    reviewResponseSchema,
    reviewResponseSchemaUpdate,
    reevaluationConformationSchema
} = require('../utils/schemas');

const {
    getResponseData,
    setResponseData,
    updateResponseData
} = require('../models/review.model');
const {
    getSessionsById
} = require('../models/session.model');
const {
    updateMapping,
    mappingIdValidation,
    getUserReviewScore,
    getMappingById
} = require('../models/sessionTemplateMapping.model');
const {
    storeComment,
    updateComment
} = require('../models/comment.model');
const {
    getAdminList
} = require('../models/userInfo.model');
const {
    getTemplateById
} = require('../models/template.model');
const {
    getSecondaryReviewersList
} = require('../models/secondaryReviewer.model')
const {
    storeNotificationData
} = require('../models/notification.model');
const user = require('./user.controller');
const email = require('../utils/email');
const sendMappingEmail = require('../utils/sendMappingMail');
const getFormattedDate = require('../utils/getFormattedDate');
const {
    getAdminMailList
} = require('../models/userInfo.model');
const fs = require('fs');
const path = require('path');

class Review {
    constructor() {}

    static async sendNotification(mappingId, reviewerId, revieweeId, notificationType) {
        let notificationList = [];
        let reviewerName = await user.getUserName(reviewerId);
        let revieweeName = await user.getUserName(revieweeId);
        if (notificationType == 8) {
            let adminList = await getAdminList(reviewerId);
            notificationList = adminList.map(adminId => {
                return {
                    "nd_type": 8,
                    "created_at": new Date(),
                    "nd_for": adminId,
                    "nd_ref": `${mappingId}`,
                    "nd_message": `${reviewerName} has submitted a review of ${revieweeName}`,
                    "nd_header": `Review submitted`
                };
            });
        } else {
            notificationList.push({
                "nd_type": 5,
                "created_at": new Date(),
                "nd_for": reviewerId,
                "nd_ref": `${mappingId}`,
                "nd_message": `Your Review for ${revieweeName} has been approved`,
                "nd_header": `Review approved`
            });
            notificationList.push({
                "nd_type": 7,
                "created_at": new Date(),
                "nd_for": revieweeId,
                "nd_ref": `${mappingId}`,
                "nd_message": `Your Review given by ${reviewerName} has been published`,
                "nd_header": `Review published`
            });
        }
        storeNotificationData(notificationList);
    }

    static publishReview(request, response, next) {
        validator(request.body, deleteSchema, async function (error, value) {
            if (error) {
                next(error);
            } else {
                try {
                    let validationResult = await mappingIdValidation(request.body.id);
                    if (!validationResult) {
                        let error = new Error();
                        error.code = 'STMIDNOTFOUND';
                        next(error);
                    } else if (request.decoded.Role != 'ROLE_SADMIN' || validationResult.stm_status != 3) {
                        let error = new Error();
                        error.code = 'UNAUTHORIZEDACCESS';
                        next(error);
                    }
                    let result = await updateMapping(2, request.body.userId, request.body.id);
                    response.status(200).json({
                        "message": "review publish succesfully !!"
                    });
                    let revieweeId = validationResult.dataValues.stm_reviewee_id;
                    let reviewerId = validationResult.dataValues.stm_reviewer_id;
                    Review.sendNotification(request.body.id, reviewerId, revieweeId, 7);
                } catch (error) {
                    next(error);
                }
            }
        })
    }

    static getResponseDataByMappingId(request, response, next) {
        validator(request.query, deleteSchema, async function (error, value) {
            if (error) {
                next(error);
            } else {
                try {
                    const userRole = request.decoded.Role;
                    let validationResult = await mappingIdValidation(request.query.id);
                    validationResult = validationResult.dataValues;
                    let secondaryReviewers = await getSecondaryReviewersList(request.query.id);
                    const userId = request.query.userId;
                    const validationFlag = ((userRole == 'ROLE_SADMIN' || validationResult.stm_reviewer_id == userId) && validationResult.stm_status != 1) ||
                        (validationResult.stm_reviewee_id == userId && validationResult.stm_status == 2);
                    
                    if (!validationFlag) {
                        let error = new Error();
                        error.code = 'UNAUTHORIZEDACCESS';
                        next(error);
                    } else {
                        let result = await getResponseData(request.query.id);
                        if (!result) {
                            let error = new Error();
                            error.code = 'NORECORD';
                            next(error);
                        } else {
                            let sessionResult = await getSessionsById(validationResult.stm_session_id);
                            let endDate = new Date(sessionResult.dataValues.s_ending_date);
                            endDate.setDate(endDate.getDate() + 15);
                            let today = new Date();
                            let showComment = today < endDate;
                            result.dataValues.showComment = showComment;
                            response.status(200).json(result);
                        }
                    }
                } catch (error) {
                    next(error);
                }
            }
        });
    }

    static storeResponseData(request, response, next) {
        validator(request.body, reviewResponseSchema, async function (error, value) {
            if (error) {
                next(error);
            } else {
                try {
                    let result = await mappingIdValidation(request.body.sessionTemplateMappingId);
                    if (!result) {
                        let error = new Error();
                        error.code = 'STMIDNOTFOUND';
                        next(error);
                    } else if (result.dataValues.stm_status != 1 || result.dataValues.stm_reviewer_id != request.body.userId) {
                        let error = new Error();
                        error.code = 'UNAUTHORIZEDACCESS';
                        next(error);
                    }
                    if (result.dataValues.stm_status === 1) {
                        const storeResult = await setResponseData(request.body);
                        const updateResult = await updateMapping(3, request.body.userId, request.body.sessionTemplateMappingId);
                        response.status(200).json({
                            message: "successfully stored the response of the review and updated the status of the mapping table"
                        });
                        const revieweeId = result.dataValues.stm_reviewee_id;
                        const reviewerId = result.dataValues.stm_reviewer_id;
                        Review.sendNotification(request.body.sessionTemplateMappingId, reviewerId, revieweeId, 8);
                    } else {
                        let error = new Error();
                        error.code = 'STMSTATUSNOTPENDING';
                        next(error);
                    }
                } catch (error) {
                    next(error);
                }
            }
        })
    }

    static updateResponse(request, response, next) {
        validator(request.body, reviewResponseSchemaUpdate, async function (error, value) {
            if (error) {
                next(error);
            } else {
                try {
                    let idValidationResult = await mappingIdValidation(request.body.sessionTemplateMappingId);
                    if (!idValidationResult) {
                        let error = new Error();
                        error.code = 'STMIDNOTFOUND';
                        next(error);
                    } else if (idValidationResult.dataValues.stm_status != 3 || idValidationResult.dataValues.stm_reviewer_id != request.body.userId) {
                        let error = new Error();
                        error.code = 'UNAUTHORIZEDACCESS';
                        next(error);
                    }
                    let result = await updateResponseData(request.body);
                    let differences = diff(request.body.oldData, request.body.answerResponse);
                    if (typeof differences !== 'undefined') {
                        let commentList = [];
                        diff.observableDiff(request.body.oldData, request.body.answerResponse, function (d) {
                            const questionElement = d.path[1];
                            const questionNumber = questionElement[questionElement.length - 1];
                            const question = request.body.questionResponse[Number(questionNumber) - 1];
                            let comment = {
                                "mappingId": request.body.sessionTemplateMappingId,
                                "parentId": 0,
                                "userId": request.body.userId,
                                "commentVisibility": false,
                                "systemGenerated": 2
                            };
                            if (d.path[2] === 'response') {
                                if (d.path[3]) {
                                    if (d.rhs == true) {
                                        comment["comment"] = `${request.body.userName} has selected ${d.path[3]} in ${question}`;
                                    }
                                } else {
                                    comment["comment"] = `${request.body.userName} has changed ${d.lhs} to ${d.rhs} in ${question}`;
                                }
                            }
                            if (comment.comment) {
                                commentList.push(comment);
                            }
                        });
                        commentList.forEach(async (element) => {
                            result = await storeComment(element);
                            const id = result.dataValues.c_id;
                            result = await updateComment({
                                c_parent: id
                            }, id);
                        });
                    }
                    response.status(200).json({
                        message: "successfully updated the response of the review"
                    });
                    let notificationList = [];
                    let adminList = await getAdminList(request.body.userId);
                    let reviewerName = await user.getUserName(request.body.userId);
                    notificationList = adminList.map(adminId => {
                        return {
                            "nd_type": 15,
                            "created_at": new Date(),
                            "nd_for": adminId,
                            "nd_ref": `${request.body.sessionTemplateMappingId}`,
                            "nd_message": `${reviewerName} has updated a response`,
                            "nd_header": `Response updated`
                        };
                    });
                    storeNotificationData(notificationList);
                } catch (error) {
                    next(error);
                }
            }
        })
    }

    static ReEvaluationRequest(request, response, next) {
        validator(request.body, deleteSchema, async function (error, value) {
            if (error) {
                next(error);
            } else {
                try {
                    const {
                        id,
                        userId,
                        message
                    } = request.body;
                    const validationResult = await mappingIdValidation(id);
                    if (!validationResult) {
                        let error = new Error();
                        error.code = 'STMIDNOTFOUND';
                        next(error);
                    } else if (validationResult.dataValues.stm_reviewee_id != userId ||
                        !validationResult.dataValues.stm_reevaluation_status ||
                        validationResult.dataValues.stm_status != 2) {
                        let error = new Error();
                        error.code = 'UNAUTHORIZEDACCESS';
                        next(error);
                    } else {
                        const updateResult = await updateMapping(2, userId, id, true);
                        const commentResult = await storeComment({
                            "comment": message,
                            "mappingId": id,
                            "parentId": 0,
                            "userId": userId,
                            "commentVisibility": true,
                            "systemGenerated": 3
                        });
                        const commentUpdateResult = await updateComment({
                            c_parent: commentResult.dataValues.c_id
                        }, commentResult.dataValues.c_id);
                        response.status(200).json({
                            message: "Re-Evalution request for review has been sent successfully."
                        });
                        let notificationList = [];
                        let revieweeName = await user.getUserName(userId);
                        let adminList = await getAdminList(userId);
                        notificationList = adminList.map(adminId => {
                            return {
                                "nd_type": 13,
                                "created_at": new Date(),
                                "nd_for": adminId,
                                "nd_ref": `${id}`,
                                "nd_message": `${revieweeName} has requested for a re-evaluation`,
                                "nd_header": `Re-evaluation request`
                            };
                        });
                        storeNotificationData(notificationList);
                        let recipients = await getAdminMailList();
                        let mapping = await getMappingById(id);
                        recipients = recipients.map(row => {
                            row['referenceLink'] = `${process.env.REDIRECT_PATH}/response/${id}`;
                            return row;
                        })
                        let endDate = new Date(mapping.dataValues.sessions.dataValues.session_ending_date);
                        endDate.setDate(endDate.getDate() + 15);

                        const filePath = path.join(__dirname, '../', 'templates', 'emailTemplate.html');
                        const createHTML = fs.readFileSync(filePath, 'utf8').toString();
                        const subject = `[Review] Re-evaluation request`;
                        const emailBody = `<table style='width:100%;'><tr><td style='width: 140px; vertical-align: top;'>Session Name :</td><td><span style='font-weight: 600;'>${mapping.dataValues.sessions.dataValues.session_name}</span></td></tr><tr><td style='width: 170px; vertical-align: top;'>Deadline for consent:</td><td><span style='font-weight: 600;'>${getFormattedDate(endDate)}</span></td></tr><tr><td style='width: 140px; vertical-align: top;'>Reviewers :</td><td><span style='font-weight: 600;'>${mapping.dataValues.reviewer.dataValues.reviewer_name}</span></td></tr><tr><td style='width: 140px; vertical-align: top;'>Reviewees :</td><td><span style='font-weight: 600;'>${revieweeName}</span></td></tr></table>`;
                        const data = {
                            emailTag: `${revieweeName} has requested for a re-evaluation`,
                            bodyTitle: 'Re-evaluation request',
                            emailBody: emailBody
                        };
                        const emailData = {
                            data: data,
                            recipients: recipients,
                            subject: subject,
                            html: createHTML
                        };
                        email(emailData);
                    }
                } catch (error) {
                    next(error);
                }
            }
        });
    }

    static ReEvaluationConformation(request, response, next) {
        validator(request.body, reevaluationConformationSchema, async function (error, value) {
            if (error) {
                next(error);
            } else {
                try {
                    const {
                        mappingId,
                        userId,
                        commentId,
                        approval
                    } = request.body;
                    const validationResult = await mappingIdValidation(mappingId);
                    let error = new Error();
                    if (!validationResult) {
                        error.code = 'STMIDNOTFOUND';
                        next(error);
                    } else if (request.decoded.Role != 'ROLE_SADMIN' || validationResult.dataValues.stm_status != 2) {
                        error.code = 'UNAUTHORIZEDACCESS';
                        next(error);
                    } else {
                        const updateResult = await updateComment({
                            c_system_generated: 2
                        }, commentId);
                        let message = "Request for reevaluation is declined.";
                        if (approval) {
                            const mappingUpdateResult = await updateMapping(3, userId, mappingId);
                            message = "Request for reevaluation is Accepted.";
                        }
                        const commentResult = await storeComment({
                            "comment": message,
                            "mappingId": mappingId,
                            "parentId": 0,
                            "userId": userId,
                            "commentVisibility": true,
                            "systemGenerated": 2
                        });
                        const commentUpdateResult = await updateComment({
                            c_parent: commentResult.dataValues.c_id
                        }, commentResult.dataValues.c_id);
                        response.status(200).json({
                            message: message
                        });
                        let notificationList = [];
                        let mapping = await getMappingById(mappingId);

                        if (approval === true) {
                            notificationList.push({
                                "nd_type": 14,
                                "created_at": new Date(),
                                "nd_for": mapping.dataValues.stm_reviewee_id,
                                "nd_ref": `${mappingId}`,
                                "nd_message": `Your Re-evaluation request has been approved.`,
                                "nd_header": `Re-evaluation request approved.`
                            });
                            notificationList.push({
                                "nd_type": 14,
                                "created_at": new Date(),
                                "nd_for": mapping.dataValues.stm_reviewer_id,
                                "nd_ref": `${mappingId}`,
                                "nd_message": `You have been assigned to Re-review ${mapping.dataValues.reviewee.dataValues.reviewee_name}.`,
                                "nd_header": `Re-review assigned`
                            });

                            let endDate = new Date(mapping.dataValues.sessions.dataValues.session_ending_date);
                            endDate.setDate(endDate.getDate() + 15);

                            let templateResult = await getTemplateById(mapping.dataValues.stm_template_id);
                            let mappingMessage = 'Without one to one meeting.';
                            if (templateResult.dataValues.canInterview) {
                                mappingMessage = 'Along with one to one meeting.';
                            }

                            let mailObject = {
                                stmId: mappingId,
                                mappingMessage: mappingMessage,
                                sessionName: mapping.dataValues.sessions.dataValues.session_name,
                                sessionEndingDate: endDate,
                                reviewerId: [mapping.dataValues.stm_reviewee_id],
                                revieweeId: [mapping.dataValues.stm_reviewer_id],
                                reEvaluation: true
                            }
                            let mail = await sendMappingEmail(mailObject);
                            storeNotificationData(notificationList);
                        } else {
                            notificationList.push({
                                "nd_type": 14,
                                "created_at": new Date(),
                                "nd_for": mapping.dataValues.stm_reviewee_id,
                                "nd_ref": `${mappingId}`,
                                "nd_message": `Your Re-evaluation request has been declined.`,
                                "nd_header": `Re-evaluation request declined.`
                            });
                            storeNotificationData(notificationList);
                        }
                    }
                } catch (error) {
                    next(error);
                }
            }
        });
    }

    //get average review score and last review score for the given user
    static async getReviewScore(request, response, next) {
        validator(request.params, idSchema, async (error, value) => {
            if (error) {
                next(error);
            } else {
                try {
                    let resultAverage = await getUserReviewScore(request.params.id);

                    if (resultAverage.length === 0) {
                        response.status(200).json({
                            'normalizedScoreAverage': 0,
                            'normalizedScore': 0
                        });
                    } else {
                        let revieweeTotalScoreAverage = 0;
                        let templateTotalScoreAverage = 0;
                        let revieweeTotalScore = 0;
                        let templateTotalScore = 0;
                        revieweeTotalScore = resultAverage[0].dataValues.reviews[0].dataValues.reviewScore;
                        templateTotalScore = resultAverage[0].dataValues.templates.dataValues.templateScore;
                        resultAverage.forEach(review => {
                            revieweeTotalScoreAverage += review.dataValues.reviews[0].dataValues.reviewScore;
                            templateTotalScoreAverage += review.dataValues.templates.dataValues.templateScore;
                        });
                        const normalizedScoreAverage = revieweeTotalScoreAverage / templateTotalScoreAverage * 100;
                        const normalizedScore = revieweeTotalScore / templateTotalScore * 100;

                        response.status(200).json({
                            'normalizedScoreAverage': normalizedScoreAverage,
                            'normalizedScore': normalizedScore
                        });
                    }
                } catch (error) {
                    next(error);
                }
            }
        })
    }
}

module.exports = Review;