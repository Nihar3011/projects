const _ = require('lodash');

const validator = require('../utils/validation');
const {
    listSchema,
    idSchema,
    sessionMappingdetailsSchema
} = require('../utils/schemas');
const {
    getMappingList,
    getMappingById,
    mappingIdValidation,
    getStmIdByMappingData,
    addToStm,
    getRevieweeMappingAnalysisBySessionId,
    getMappingBySessionId,
    deleteMapping
} = require('../models/sessionTemplateMapping.model');
const {
    updateTemplate,
    getTemplateById
} = require('../models/template.model');
const {
    getSecondaryReviewersList,
    insertIntoSecondaryReviewerList,
    getObjects
} = require('../models/secondaryReviewer.model');
const {
    getSessionsById
} = require('../models/session.model');
const {
    storeNotificationData
} = require('../models/notification.model');
const {
    getUserById
} = require('../models/userInfo.model');
const user = require('./user.controller');
const sendMappingEmail = require('../utils/sendMappingMail');

"use strict";

class SessionTemplateMapping {
    constructor() {}

    static async sendNotification(notificationData) {
        let notificationList = [];
        let revieweeList = await getUserById(notificationData.revieweeId);
        let revieweeName = `${revieweeList[0].dataValues.first_name} ${revieweeList[0].dataValues.last_name}`;

        let reviewerNames = '';
        let reviewerList = await getUserById(notificationData.reviewerId);
        reviewerList.map(row => {
            reviewerNames = `${reviewerNames}, ${row.dataValues.first_name} ${row.dataValues.last_name}`;
        });
        reviewerNames = reviewerNames.substr(1);

        let ndMessage = '';
        if (notificationData.reviewerId.length > 1) {
            ndMessage = `You have been assigned as Reviewer to review ${revieweeName} in group (${reviewerNames}) - ${notificationData.mappingMessage}`;
        } else {
            ndMessage = `You have been assigned as Reviewer to review ${revieweeName} - ${notificationData.mappingMessage}`;
        }
        reviewerList.map(row => {
            notificationList.push({
                "nd_type": 4,
                "created_at": new Date(),
                "nd_for": row.dataValues.user_id,
                "nd_ref": null,
                "nd_message": ndMessage,
                "nd_header": `Review Scheduled`
            });
        });
        notificationList.push({
            "nd_type": 6,
            "created_at": new Date(),
            "nd_for": notificationData.revieweeId[0],
            "nd_ref": null,
            "nd_message": `Your review will be given by ${reviewerNames} - ${notificationData.mappingMessage}`,
            "nd_header": `Review Initiated`
        });
        storeNotificationData(notificationList);
    }

    static getMappingData(request, response, next) {
        validator(request.params, idSchema, async function (error, value) {
            if (error) {
                next(error);
            } else {
                try {
                    let result = await getMappingById(request.params.id);
                    let secondaryReviewers = await getSecondaryReviewersList(request.params.id);

                    response.status(200).json({
                        "status": result.dataValues.status,
                        "revieweeId": result.dataValues.stm_reviewee_id,
                        "reviewerId": result.dataValues.stm_reviewer_id,
                        "templateId": result.dataValues.stm_template_id,
                        "reviewee": result.dataValues.reviewee.dataValues.reviewee_name,
                        "reviewer": result.dataValues.reviewer.dataValues.reviewer_name,
                        "templateName": result.dataValues.templates.dataValues.template_name,
                        "sessionName": result.dataValues.sessions.dataValues.session_name,
                        "sessionEndingDate": result.dataValues.sessions.dataValues.session_ending_date,
                        "reevalutionPossible": result.dataValues.stm_reevaluation_status,
                        "secondaryReviewers": secondaryReviewers
                    });
                } catch (error) {
                    next(error);
                }
            }
        })
    }

    static getMappingList(request, response, next) {
        validator(request.body, listSchema, async function (error, value) {
            if (error) {
                next(error);
            } else {
                if(request.decoded.Role == 'ROLE_SADMIN'){
                    let {
                        pageSize,
                        pageIndex,
                        search,
                        status,
                        sort,
                        order,
                        sessionStatus
                    } = request.body;
                    pageIndex = pageIndex || process.env.PAGE_INDEX;
                    pageSize = pageSize || process.env.PAGE_SIZE;
                    let offset = (pageIndex - 1) * pageSize;
    
                    if ((search || '').includes("%")) {
                        response.status(200).json(Object.assign({}, [0, []]));
                    } else {
                        try {
                            let result = await getMappingList(status, sort, order, search, sessionStatus);
                            let length = result.length;
                            let data = result.slice(offset, (pageIndex * pageSize));
                            let newData = data.map(element => {
                                return {
                                    "session_template_mapping_id": element.stm_id,
                                    "session": element.sessions.dataValues.session_name,
                                    "reviewee": element.reviewee.dataValues.reviewee_name,
                                    "reviewer": element.reviewer.dataValues.reviewer_name,
                                    "status": element.stm_status
                                }
                            });
                            response.status(200).json(Object.assign({}, [length, newData]));
                        } catch (error) {
                            next(error);
                        }
                    }
                } else {
                  let error = new Error();
                  error.code = 'UNAUTHORIZEDACCESS';
                  next(error);    
                }
            }
        })
    }

    static async addMappingData(mapObject) {
        let templateId = [];
        let mailObject;
        let dataOfSecondaryReviewer = [];
        let message = "Candidate mapping saved successfully !!";

        mapObject.mappingBody.forEach(async element => {
            element.reviewees.forEach(async function (list) {
                let mappingObject = {
                    stm_session_id: Number(mapObject.sessionId),
                    stm_template_id: element.template.template_id,
                    stm_reviewer_id: element.primaryReviewer.reviewer_id,
                    stm_reviewee_id: list.reviewee_id,
                    stm_status: 1,
                    stm_version: mapObject.sessionVersion,
                    created_by: Number(mapObject.userId),
                    created_at: '' + new Date() + ''
                }

                templateId.push(element.template.template_id);
                let templateResult = await getTemplateById(element.template.template_id);
                let mappingMessage = 'Without one to one meeting.';
                if (templateResult.dataValues.canInterview) {
                    mappingMessage = 'Along with one to one meeting.';
                }
                try {
                    let reviewerId = [];
                    let stmId = await addToStm(mappingObject);
                    dataOfSecondaryReviewer = [];
                    reviewerId.push(element.primaryReviewer.reviewer_id);
                    if (element.secondaryReviewers.length !== 0) {
                        dataOfSecondaryReviewer = [];
                        element.secondaryReviewers.forEach(reviewer => {
                            let secondary_reviewer_data = {
                                sr_stm_id: stmId,
                                sr_reviewer_id: reviewer.reviewer_id,
                            }
                            dataOfSecondaryReviewer.push(secondary_reviewer_data);
                        });
                        try {
                            let insertSecondaryReviewerResult = insertIntoSecondaryReviewerList(dataOfSecondaryReviewer);
                            dataOfSecondaryReviewer = [];
                            element.secondaryReviewers.forEach(reviewer => {
                                reviewerId.push(reviewer.reviewer_id);
                            });
                        } catch (error) {}
                    }
                    mailObject = {
                        stmId: stmId,
                        mappingMessage: mappingMessage,
                        sessionId: mapObject.sessionId,
                        reviewerId: reviewerId,
                        revieweeId: [list.reviewee_id],
                        reEvaluation: false
                    }

                    SessionTemplateMapping.sendNotification(mailObject);
                    let mail = await sendMappingEmail(mailObject);
                    reviewerId = [];
                    mailObject = null;
                } catch (error) {
                    if (error.parent && (error.parent.constraint == "group_key_unique")) {
                        if (element.secondaryReviewers.length !== 0) {
                            message = "Candidate mapping saved successfully with updation of existing record !!"
                            let dataOfSecondaryReviewer = [];

                            try {
                                let reviewerId = [];
                                reviewerId.push(error.fields.stm_reviewer_id);
                                let mappingId = await getStmIdByMappingData(error.fields);
                                let secondaryReviewersList = await getSecondaryReviewersList(mappingId);
                                
                                element.secondaryReviewers.forEach(reviewer => {
                                    if (!secondaryReviewersList.includes(reviewer.reviewer_id)) {
                                        let secondary_reviewer_data = {
                                            sr_stm_id: mappingId,
                                            sr_reviewer_id: reviewer.reviewer_id,
                                        }
                                        dataOfSecondaryReviewer.push(secondary_reviewer_data);
                                    }
                                    reviewerId.push(reviewer.reviewer_id);
                                });

                                if (dataOfSecondaryReviewer.length != 0) {
                                    let insertSecondaryReviewerResult = insertIntoSecondaryReviewerList(dataOfSecondaryReviewer);
                                    dataOfSecondaryReviewer = [];
                                    mailObject = {
                                        stmId: mappingId,
                                        mappingMessage: mappingMessage,
                                        sessionId: mapObject.sessionId,
                                        reviewerId: reviewerId,
                                        revieweeId: [error.fields.stm_reviewee_id],
                                        reEvaluation: false
                                    }
                                    SessionTemplateMapping.sendNotification(mailObject);
                                    let mail = await sendMappingEmail(mailObject);
                                    reviewerId = [];
                                    mailObject = null;
                                }
                            } catch (error) {}
                        } else {
                            message = "Candidate mapping successfully with updation of existing record !!"
                        }
                    }
                }
            });
        });
        let templateUpdateResult = await updateTemplate({
            t_status: 2
        }, templateId);
        return message;
    }

    static postMappingArray(request, response, next) {
        validator(request.params, idSchema, async function (error, values) {
            if (error) {
                next(error);
            } else {
                validator(request.body, sessionMappingdetailsSchema, async function (error, values) {
                    if (error) {
                        next(error);
                    } else {
                        if(request.decoded.Role == 'ROLE_SADMIN'){
                            try {
                                let result = await getSessionsById(request.params.id);
                                if (result == null) {
                                    let error = new Error();
                                    error.code = 'SIDNOTFOUND';
                                    return next(error);
                                } else if (result.dataValues.s_status != 1) {
                                    let error = new Error();
                                    error.code = 'SESSIONNOTACTIVE';
                                    return next(error);
                                }
    
                                let mapObject = {
                                    sessionId: request.params.id,
                                    sessionVersion: result.dataValues.s_version,
                                    mappingBody: request.body,
                                    userId: request.query.userId
                                }
                                let responseMessage = SessionTemplateMapping.addMappingData(mapObject);
                                response.status(200).json({
                                    "message": responseMessage
                                });
                            } catch (error) {
                                next(error);
                            }
                        } else {
                          let error = new Error();
                          error.code = 'UNAUTHORIZEDACCESS';
                          next(error);    
                        }
                    }
                });
            }
        });
    }

    static sessionTemplateMappingDetails(request, response, next) {
        const page_index = (request.body.pageIndex === undefined) ? process.env.PAGE_INDEX : request.body.pageIndex;
        const page_size = (request.body.pageSize === undefined) ? process.env.PAGE_SIZE : request.body.pageSize;
        const sortColumn = (request.body.sort === undefined) ? "template_name" : request.body.sort;
        let order = "asc";
        order = (request.body.order === undefined) ? order : (request.body.order == -1 ? "desc" : order);

        validator(request.params, idSchema, async (error, value) => {
            if (error) {
                next(error);
            } else {
                if(request.decoded.Role == 'ROLE_SADMIN'){
                    try {
                        const offset = page_size * (page_index - 1);
                        let validationResult = await getSessionsById(request.params.id);
                        if (validationResult == null) {
                            let error = new Error();
                            error.code = 'SIDNOTFOUND';
                            next(error);
                        } else {
                            let mappings = await getMappingBySessionId(request.params.id);
                            let resp = await getObjects(mappings);
    
                            let final = {};
                            resp.forEach((obj) => {
                                if (final.hasOwnProperty(obj.reviewer_name)) {
                                    let secreviewer_obj = final[obj.reviewer_name];
                                    if (secreviewer_obj.hasOwnProperty(obj.secondaryReviewers)) {
                                        let reviewee_obj = secreviewer_obj[obj.secondaryReviewers];
                                        if (reviewee_obj.hasOwnProperty(obj.template_name)) {
                                            let reviewer_list = reviewee_obj[obj.template_name];
                                            reviewer_list.push(obj.reviewee);
                                        } else {
                                            reviewee_obj[obj.template_name] = [obj.reviewee];
                                        }
                                    } else {
                                        let innerobj = {};
                                        innerobj[obj.template_name] = [obj.reviewee];
                                        secreviewer_obj[obj.secondaryReviewers] = innerobj;
                                    }
                                } else {
                                    let secondaryObj = {};
                                    let innerobj = {};
                                    innerobj[obj.template_name] = [obj.reviewee];
                                    secondaryObj[obj.secondaryReviewers] = innerobj;
                                    final[obj.reviewer_name] = secondaryObj;
                                }
                            });
    
                            let menu = [];
                            let length;
    
                            let val = Object.keys(final).map((reviewer) => {
                                let reviewerObj = final[reviewer];
                                return Object.keys(reviewerObj).map(secondaryreviewer => {
                                    let secondaryreviewerObj = reviewerObj[secondaryreviewer];
                                    return Object.keys(secondaryreviewerObj).map(template => {
                                        menu.push({
                                            'reviewer_name': reviewer,
                                            'secondaryreviewer_name': [secondaryreviewer],
                                            'template_name': template,
                                            'reviewees': secondaryreviewerObj[template]
                                        });
                                        return;
                                    });
                                });
                            });
                            if (sortColumn === "template_name") {
                                menu = _.orderBy(menu, [data => data[sortColumn].toLowerCase()], [order]);
                            } else {
                                menu = _.orderBy(menu, [data => data.reviewer_name.toLowerCase(), data => data.template_name.toLowerCase()], [order]);
                            }
                            length = menu.length;
                            menu = menu.slice(offset, (page_index * page_size));
                            let sessionData = {
                                sessionName: validationResult.dataValues.s_name,
                                sessionStatus: validationResult.dataValues.s_status
                            }
                            response.status(200).json(Object.assign({}, [menu, length, sessionData]));
                        }
                    } catch (error) {
                        next(error);
                    }
                } else {
                  let error = new Error();
                  error.code = 'UNAUTHORIZEDACCESS';
                  next(error);    
                }
            }
        });
    }

    static async getRevieweeIdByMappingId(mappingId) {
        let result = await mappingIdValidation(mappingId);
        return result.dataValues.stm_reviewee_id;
    }

    static async getReviewerIdByMappingId(mappingId) {
        let result = await mappingIdValidation(mappingId);
        return result.dataValues.stm_reviewer_id;
    }

    static async getSessionMappingReport(request, response, next) {
        validator(request.body, listSchema, async function (error, value) {
            if (error) {
                next(error);
            } else {
                if(request.decoded.Role == 'ROLE_SADMIN'){
                    let {
                        pageSize,
                        pageIndex,
                        search,
                        sort,
                        order,
                        id,
                        employee,
                        designation
                    } = request.body;
                    pageIndex = pageIndex || process.env.PAGE_INDEX;
                    pageSize = pageSize || process.env.PAGE_SIZE;
                    let offset = (pageIndex - 1) * pageSize;
                    let sessionDetails = await getSessionsById(id);
                    if ((search || '').includes("%")) {
                        response.status(200).json(Object.assign({}, [0, []]));
                    } else {
                        try {
                            let result = await getRevieweeMappingAnalysisBySessionId(sort, order, search, id, employee, designation);
                            let length = result.length;
                            let newData = result.map(element => {
                                return {
                                    'employeeName': element.dataValues.fullname,
                                    'designation': element.dataValues.designation != null ? element.dataValues.designation.dataValues.designation : '-',
                                    'mappingCount': element.dataValues.reviewee.length,
                                    'templates': [...new Set(element.dataValues.reviewee.map(element => {
                                        return element.dataValues.templates.dataValues.template
                                    }))]
                                }
                            });
                            if (sort == 'mappingCount' || !sort) {
                                let sortBy = function (field, reverse, primer) {
                                    let key = primer ?
                                        function (x) {
                                            return primer(x[field])
                                        } :
                                        function (x) {
                                            return x[field]
                                        };
                                    return function (a, b) {
                                        return a = key(a), b = key(b), reverse * ((a > b) - (b > a));
                                    }
                                }
                                newData.sort(sortBy('mappingCount', order, parseInt));
                            }
                            newData = newData.slice(offset, (pageIndex * pageSize));
                            response.status(200).json(Object.assign({}, [length, sessionDetails.dataValues.s_name, newData]));
                        } catch (error) {
                            next(error);
                        }
                    }
                } else {
                  let error = new Error();
                  error.code = 'UNAUTHORIZEDACCESS';
                  next(error);    
                }
            }
        })
    }

    static async deleteMapping(request, response, next) {
        validator(request.query, idSchema, async function (error) {
            if (error) {
                next(error);
            } else {
                if(request.decoded.Role == 'ROLE_SADMIN'){
                    try {
                        const result = await deleteMapping(request.query.id);
                        response.status(200).json({
                            message: "Mapping Deleted"
                        });
                    } catch (error) {
                        next(error);
                    }
                } else {
                  let error = new Error();
                  error.code = 'UNAUTHORIZEDACCESS';
                  next(error);    
                }
            }
        });
    }
}

module.exports = SessionTemplateMapping;