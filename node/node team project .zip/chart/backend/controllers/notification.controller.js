const validator = require('../utils/validation');
const {
    idSchema,
    notificationListSchema
} = require('../utils/schemas');

const {
    readNotification,
    readAllNotifications,
    deleteNotification,
    getAllNotifications,
    getNotificationCount,
} = require('../models/notification.model');

"use strict";

class Notification {
    constructor() {}

    static readNotification(request, response, next) {
        validator(request.query, idSchema, async function (error) {
            if (error) {
                next(error);
            } else {
                try {
                    const result = await readNotification(request.query.id);
                    let message = "marked notification as seen";
                    if (result[0] === 0) {
                        message = "notification not found";
                    }
                    response.status(200).json({ message: message });
                } catch (error) {
                    next(error);
                }
            }
        });
    }

    static readAllNotifications(request, response, next) {
        validator(request.query, idSchema, async function (error) {
            if (error) {
                next(error);
            } else {
                try {
                    const result = await readAllNotifications(request.query.id);
                    let message = "marked all notification as seen";
                    if (result[0] === 0) {
                        message = "Invalid user or no notification is there for this user";
                    }
                    response.status(200).json({ message: message });
                } catch (error) {
                    next(error);
                }
            }
        });
    }

    static deleteNotification(request, response, next) {
        validator(request.query, idSchema, async function (error) {
            if (error) {
                next(error);
            } else {
                try {
                    const result = await deleteNotification(request.query.id);
                    response.status(200).json({ message: "Notification Deleted" });
                } catch (error) {
                    next(error);
                }
            }
        });
    }

    static getNotificationList(request, response, next) {
        validator(request.query, notificationListSchema, async function (error) {
            if (error) {
                next(error);
            } else {
                try {   
                    const unreadNotificationcount = await getNotificationCount(request.query.userId,'unread');
                    const allNotificationcount = await getNotificationCount(request.query.userId,'all');
                    const result = await getAllNotifications(request.query.userId,request.query.scrollSize);
                    const limitNumber = (request.query.flag === 'new') ? 10 : ((request.query.scrollSize < allNotificationcount) ? request.query.scrollSize : allNotificationcount);
                    let data = result.slice(0,limitNumber);
                   
                    data = data.map(element => {
                        return {
                            'notificationId': element.dataValues.nd_id,
                            'isSeen': element.dataValues.nd_is_seen,
                            'timeStamp': element.dataValues.created_at,
                            'notificationType': element.dataValues.nd_type,
                            'notificationMessage': element.dataValues.nd_message,
                            'notificationHeader': element.dataValues.nd_header,
                            'notificationReference': element.dataValues.nd_ref
                        };
                    });
                    response.status(200).json(Object.assign({}, [allNotificationcount, unreadNotificationcount, data]));
                
                } catch (error) {
                    next(error);
                }
            }
        });
    }
}

module.exports = Notification;
