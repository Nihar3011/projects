const validator = require('../utils/validation');
const {
    idSchema,
    deleteSchema,
    listSchema,
    templateInsertUpdateSchema
} = require('../utils/schemas');

const {
    getTemplateById,
    deleteTemplateById,
    createTemplate,
    updateTemplate,
    getTemplateList,
    getTemplatesName
} = require('../models/template.model');
const {
    storeNotificationData
} = require('../models/notification.model');
const {
    getAdminList
} = require('../models/userInfo.model');

const user = require('./user.controller');

"use strict";

class Template {
    constructor() { }

    static async sendNotification(userId, templateName, notificationType, headerType) {
        let userName = await user.getUserName(userId);
        let adminList = await getAdminList(userId);
        adminList = adminList.map(adminId => {
            return {
                "nd_type": notificationType,
                "created_at": new Date(),
                "nd_for": adminId,
                "nd_ref": null,
                "nd_message": `${userName} ${headerType} Template ${templateName}`,
                "nd_header": `Template ${headerType}`
            }
        });
        storeNotificationData(adminList);
    }

    static getTemplateById(request, response, next) {
        validator(request.params, idSchema, async function (error, value) {
            if (error) {
                next(error);
            } else {
                try {
                    let result = await getTemplateById(request.params.id);
                    if (result) {
                        response.status(200).json({
                            'templateId': result.dataValues.templateId,
                            'templateStatus': result.dataValues.templateStatus,
                            'templateDescription': result.dataValues.templateDescription,
                            'templateName': result.dataValues.templateName,
                            'templateStructure': result.dataValues.templateStructure,
                            'isScorable': result.dataValues.isScorable,
                            'canInterview': result.dataValues.canInterview,
                            'templateScore': result.dataValues.templateScore
                        });
                    } else {
                        let error = new Error();
                        error.code = 'INVALIDID';
                        next(error);
                    }
                } catch (error) {
                    next(error);
                }
            }
        })
    }

    static deleteTemplateById(request, response, next) {
        validator(request.query, deleteSchema, async function (error, value) {
            if (error) {
                next(error);
            } else {
                if(request.decoded.Role == 'ROLE_SADMIN'){
                    try {
                        let templateData = await getTemplateById(request.query.id);
                        let result = await deleteTemplateById(request.query.id, request.query.userId);
    
                        response.status(200).json({
                            message: "successfully deleted"
                        });
                        Template.sendNotification(request.query.userId, templateData.dataValues.templateName, 12, 'Deleted');
                    } catch (error) {
                        next(error);
                    }
                } else {
                  let error = new Error();
                  error.code = 'UNAUTHORIZEDACCESS';
                  next(error);    
                }
            }
        })
    }

    static getTemplateList(request, response, next) {
        validator(request.body, listSchema, async function (error, value) {
            if (error) {

                next(error)
            } else {
                if(request.decoded.Role == 'ROLE_SADMIN'){
                    let { pageSize, pageIndex, search, status, sort, order, userId } = request.body;
                    pageIndex = pageIndex || process.env.PAGE_INDEX;
                    pageSize = pageSize || process.env.PAGE_SIZE;
                    let offset = (pageIndex - 1) * pageSize;
    
                    if ((search || '').includes("%")) {
                        response.status(200).json(Object.assign({}, [0, []]));
                    } else {
                        try {
                            let result = await getTemplateList(status, sort, order, search, userId);
                            let length = result.length;
                            let data = result.slice(offset, (pageIndex * pageSize));
                            let newData = data.map(element => {
                                return {
                                    'template_id': element.dataValues.template_id,
                                    'template_status': element.dataValues.template_status,
                                    'template_description': element.dataValues.template_description,
                                    'template_name': element.dataValues.template_name,
                                    'creation_date': element.dataValues.creation_date,
                                };
                            });
                            response.status(200).json(Object.assign({}, [length, newData]));
                        } catch (error) {
                            next(error);
                        }
                    }
                } else {
                  let error = new Error();
                  error.code = 'UNAUTHORIZEDACCESS';
                  next(error);    
                }
            }
        })
    }

    static templateInsertUpdate(request, response, next) {
        validator(request.body, templateInsertUpdateSchema, async function (error, value) {
            if (error) {
                next(error);
            } else {
                if(request.decoded.Role == 'ROLE_SADMIN'){
                    try {
                        let { templateName, templateStructure, templateDescription, userId, saveAsDraft, isScorable, canInterview } =
                            request.body;
                        let templateFormat = [];
                        let totalTemplateScore = 0;
                        templateStructure.forEach(async (question, index) => {
                            let qno = `${templateName}_${index + 1}`;
                            let quesformated = {};
                            if (question.type !== 'text' && isScorable === true) {
                                totalTemplateScore += question.questionScore;
                            }
                            quesformated[qno] = question;
                            await templateFormat.push(quesformated);
                        });
                        let templateScore = (isScorable === true) ? totalTemplateScore : 0;
                        let templateStatus = (saveAsDraft === true) ? 4 : 1;
                        let result;
                        let responseMessage = {};
                        if (Object.keys(request.query).length === 0) {
                            result = await createTemplate({
                                t_name: templateName,
                                t_structure: templateFormat,
                                t_description: templateDescription,
                                t_status: templateStatus,
                                t_scorable: isScorable,
                                canInterview: canInterview,
                                t_score: templateScore,
                                created_by: userId,
                                created_at: new Date()
                            });
                            responseMessage = { value: result.dataValues.t_id, label: result.dataValues.t_name };
                            response.status(200).json(responseMessage);
                            if (saveAsDraft !== true) {
                                Template.sendNotification(userId, templateName, 10, 'Created');
                            }
                        } else {
                            validator(request.query, idSchema, async function (error, value) {
                                if (error) {
                                    next(error);
                                } else {
                                    let validationResult = await getTemplateById(request.query.id);
                                    if (validationResult) {
                                        result = await updateTemplate({
                                            t_name: templateName,
                                            t_structure: templateFormat,
                                            t_status: templateStatus,
                                            t_scorable: isScorable,
                                            canInterview: canInterview,
                                            t_score: templateScore,
                                            t_description: templateDescription,
                                            modified_by: userId,
                                            modified_at: new Date()
                                        }, [request.query.id])
                                    }
                                    responseMessage = { 'message': 'template updated successfully.' };
                                    response.status(200).json(responseMessage);
                                    if (saveAsDraft !== true) {
                                        Template.sendNotification(userId, templateName, 11, 'Updated');
                                    }
                                }
                            });
                        }
                    } catch (error) {
                        next(error);
                    }
                } else {
                  let error = new Error();
                  error.code = 'UNAUTHORIZEDACCESS';
                  next(error);    
                }
            }
        })
    }

    static async getTemplatesName(request, response, next) {
        try {
            const result = await getTemplatesName();
            response.status(200).json(result);
        }
        catch (error) {
            next(error);
        }
    }
}

module.exports = Template;
