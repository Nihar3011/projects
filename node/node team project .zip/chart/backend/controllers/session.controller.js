const validator = require('../utils/validation');
const {
    sessionCreateUpdateSchema,
    idSchema,
    listSchema,
    deleteSchema
} = require('../utils/schemas');

const {
    createSession,
    updateSession,
    getSessionsName,
    getSessionsById,
    getSessionList,
    softDeleteSession
} = require('../models/session.model');
const {
    getNoOfMappingBySessionId
} = require('../models/sessionTemplateMapping.model');
const {
    storeNotificationData
} = require('../models/notification.model');
const {
    getAdminList
} = require('../models/userInfo.model');

const sendSessionMail = require('../utils/sendSessionMail');
const user = require('./user.controller');
let createdDate = new Date();
let modifiedDate = new Date();

const getFormattedDate = require('../utils/getFormattedDate');
require('dotenv').config();
"use strict";

class Session {
    constructor() { }

    static async sendNotification(userId, sessionName, notificationType, headerType) {
        let userName = await user.getUserName(userId);
        let adminList = await getAdminList(userId);
        adminList = adminList.map(adminId => {
            return {
                "nd_type": notificationType,
                "created_at": new Date(),
                "nd_for": adminId,
                "nd_ref": null,
                "nd_message": `${userName} ${headerType} Session ${sessionName}`,
                "nd_header": `Session ${headerType}`
            }
        });
        storeNotificationData(adminList);
    }

    static createSession(request, response, next) {
        validator(request.body, sessionCreateUpdateSchema, async function (error, value) {
            if (error) {
                next(error);
            } else {
                if(request.decoded.Role == 'ROLE_SADMIN'){
                    try {
                        let sessionData = {
                            s_name: request.body.session_name,
                            s_frequency: request.body.review_cycle_frequency,
                            s_description: request.body.session_description,
                            s_version: request.body.session_version,
                            s_status: request.body.session_version != 0 ? 1 : 2,
                            s_no_of_days: request.body.session_no_of_days,
                            s_ending_date: new Date(request.body.session_ending_date),
                            s_starting_date: new Date(request.body.session_starting_date),
                            created_by: request.body.created_by,
                            created_at: createdDate.toISOString()
                        }
                        let result = await createSession(sessionData);
    
                        if (result) {
                            response.status(200).json({ "message": "Session created succesfully !!" });
                            Session.sendNotification(request.body.created_by, request.body.session_name, 1, 'Created');
                            sendSessionMail({
                                subject: 'New session is created',
                                session: result.dataValues,
                                emailTag: 'New session has been created',
                                bodyTitle: 'Created session'
                            });
                        } else {
                            error.code = "SEQFALSEINSERT";
                            next(error);
                        }
                    }
                    catch (error) {
                        error.code = "SEQFALSEINSERT";
                        next(error);
                    };
                } else {
                  let error = new Error();
                  error.code = 'UNAUTHORIZEDACCESS';
                  next(error);    
                }
            }
        });

    }

    static updateSession(request, response, next) {
        validator(request.params, idSchema, function (error, value) {
            if (error) {
                return next(error);
            } else {
                validator(request.body, sessionCreateUpdateSchema, async function (error, value) {
                    if (error) {
                        return next(error);
                    } else {
                        if(request.decoded.Role == 'ROLE_SADMIN'){
                            try {
                                const sessionData = {
                                    s_name: request.body.session_name,
                                    s_frequency: request.body.review_cycle_frequency,
                                    s_description: request.body.session_description,
                                    s_no_of_days: request.body.session_no_of_days,
                                    s_ending_date: new Date(request.body.session_ending_date),
                                    s_starting_date: new Date(request.body.session_starting_date),
                                    modified_by: request.body.modified_by,
                                    modified_at: modifiedDate.toISOString()
                                };
    
                                let result = await updateSession(sessionData, [request.params.id]);
                                if (result) {
                                    response.status(200).json({ "message": "Session updated succesfully !!" });
                                    Session.sendNotification(request.body.modified_by, request.body.session_name, 2, 'Updated');
                                    sendSessionMail({
                                        subject: 'Session is updated',
                                        session: sessionData,
                                        emailTag: 'Session has been updated',
                                        bodyTitle: 'Updated session'
                                    });
                                } else {
                                    next(error);
                                }
                            }
                            catch (error) {
                                error.code = 'SEQFALSEINSERT';
                                next(error);
                            }
                        } else {
                          let error = new Error();
                          error.code = 'UNAUTHORIZEDACCESS';
                          next(error);    
                        }
                    }
                });
            }
        });
    }

    static async getSessionsNames(request, response, next) {
        try {
            let result = await getSessionsName();
            response.status(200).json(result);
        }
        catch (error) {
            next(error);
        }
    }

    static getSessionById(request, response, next) {
        validator(request.params, idSchema, async function (error, value) {
            if (error) {
                next(error);
            } else {
                try {
                    let result = await getSessionsById(request.params.id);
                    if (result) {
                        response.status(200).json({
                            "session_id": result.dataValues.s_id,
                            "session_name": result.dataValues.s_name,
                            "review_cycle_frequency": result.dataValues.s_frequency,
                            "session_starting_date": result.dataValues.s_starting_date,
                            "session_ending_date": result.dataValues.s_ending_date,
                            "session_status": result.dataValues.session_status,
                            "session_description": result.dataValues.s_description,
                            "version": result.dataValues.s_version,
                        });
                    } else {
                        let error = new Error();
                        error.code = 'INVALIDID';
                        next(error);
                    }
                } catch (error) {
                    next(error);
                }
            }
        })
    }

    static getSessionList(request, response, next) {
        validator(request.body, listSchema, async function (error, value) {
            if (error) {
                next(error)
            } else {
                if(request.decoded.Role == 'ROLE_SADMIN'){
                    let { pageSize, pageIndex, search, status, sort, order } = request.body;
    
                    pageIndex = pageIndex || process.env.PAGE_INDEX;
                    pageSize = pageSize || process.env.PAGE_SIZE;
    
                    let offset = (pageIndex - 1) * pageSize;
    
                    if ((search || '').includes("%")) {
                        response.status(200).json(Object.assign({}, [0, []]));
                    } else {
                        try {
                            let result = await getSessionList(status, sort, order, search);
                            let length = result.length;
                            let data = result.slice(offset, (pageIndex * pageSize));
                            let newData = data.map(element => {
                                return {
                                    'session_id': element.dataValues.s_id,
                                    'session_name': element.dataValues.s_name,
                                    'review_cycle_frequency': `every ${element.dataValues.s_frequency} months`,
                                    'session_starting_date': element.dataValues.s_starting_date,
                                    'session_ending_date': element.dataValues.s_ending_date,
                                    'session_description': element.dataValues.s_description,
                                    'sessionVersion': element.dataValues.s_version,
                                    'session_status': element.dataValues.s_status,
                                    'session_created_at': element.dataValues.created_at,
                                };
                            });
                            response.status(200).json(Object.assign({}, [length, newData]));
                        } catch (error) {
                            next(error);
                        }
                    }
                } else {
                  let error = new Error();
                  error.code = 'UNAUTHORIZEDACCESS';
                  next(error);    
                }
            }
        })
    }

    static deleteSession(request, response, next) {
        validator(request.query, deleteSchema, async function (error, value) {
            if (error) {
                next(error);
            } else {
                if(request.decoded.Role == 'ROLE_SADMIN'){
                    let date = new Date();
                    const sessionId = Number(request.query.id);
                    const userId = Number(request.query.userId);
                    try {
                        let sessionData = await getSessionsById(sessionId);
                        if (sessionData === null) {
                            let error = new Error();
                            error.code = 'SIDNOTFOUND';
                            next(error);
                        }
                        else if (sessionData.dataValues.s_status === 1) {
                            let error = new Error();
                            error.code = 'SIDACTIVE';
                            next(error);
                        }
    
                        let noOfMappingBySessionId = await getNoOfMappingBySessionId(sessionId);
                        if (noOfMappingBySessionId > 0) {
                            let error = new Error();
                            error.code = 'SIDINSTM';
                            next(error);
                        }
                        else {
                            let result = await softDeleteSession(sessionId, userId, date);
                            if (result) {
                                response.status(200).json({ message: "deletion successful" })
                                Session.sendNotification(userId, sessionData.dataValues.s_name, 3, 'Deleted');
                                sendSessionMail({
                                    subject: 'Session is deleted',
                                    session: sessionData.dataValues,
                                    emailTag: 'Session has been deleted',
                                    bodyTitle: 'Deleted session'
                                });
                            }
                        }
                    } catch (error) {
                        next(error);
                    }
                } else {
                  let error = new Error();
                  error.code = 'UNAUTHORIZEDACCESS';
                  next(error);    
                }
            }
        });
    }
}

module.exports = Session;