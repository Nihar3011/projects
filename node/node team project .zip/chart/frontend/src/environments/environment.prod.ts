export const environment = {
  production: true,
  backendEndpoint: "http://intranet.argusoft.com/review-api",
  googleClientId: "461047377975-ia3ciuhpc67skqcv3vr0p9dealp3lglp.apps.googleusercontent.com"
};
