export const environment = {
  production: false,
  backendEndpoint: "http://localhost:3000/review-api",
  googleClientId: "461047377975-ia3ciuhpc67skqcv3vr0p9dealp3lglp.apps.googleusercontent.com"
};
