import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { BaseService } from './services/base.service';
import { HeaderBaseComponent } from './components/header-base/header-base.component';
import { SideNavBarComponent } from './components/side-nav-bar/side-nav-bar.component';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NotificationsComponent } from './components/notifications/notifications.component';
import { NotificationsService } from './services/notifications.service';
import { TooltipModule } from 'primeng/tooltip';
import { customDateTime } from './custom-date-time';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { ProgressBarModule } from 'primeng/progressbar';

@NgModule({
  declarations: [
    HeaderBaseComponent,
    SideNavBarComponent,
    NotificationsComponent,
    customDateTime
  ],
  imports: [
    BrowserModule,
    CommonModule,
    AngularFontAwesomeModule,
    FormsModule,
    ReactiveFormsModule,
    TooltipModule,
    ProgressBarModule,
    InfiniteScrollModule
  ],
  exports: [
    HeaderBaseComponent,
    SideNavBarComponent,
    customDateTime,
    InfiniteScrollModule
  ],

  providers: [BaseService, NotificationsService],

  bootstrap: []
})

export class BaseModule { }
