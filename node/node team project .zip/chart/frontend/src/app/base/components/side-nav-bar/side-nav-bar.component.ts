import { BaseService } from './../../services/base.service';
import { Component, OnInit, Input, HostListener, Renderer2 } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { constant } from '../../../app.const';
import { EncryptionService } from 'src/app/shared/services/encryption.service';
@Component({
  selector: 'app-side-nav-bar',
  templateUrl: './side-nav-bar.component.html',
  styleUrls: ['./side-nav-bar.component.scss']
})
export class SideNavBarComponent implements OnInit {
  @Input() sidebar;

  public show = true;
  public selectedItem: Number = 1;
  public role;
  public wrapper = true;
  sidebarOpened = false;
  subscription: Subscription;
  userData;
  image: string;
  imageIcon: any;
  userId: number;

  constructor(private router: Router,
    private baseService: BaseService,
    private renderer: Renderer2,
    private encryptionService: EncryptionService) {
  }

  ngOnInit() {
    this.userData = JSON.parse(localStorage.getItem('userdata'));
    this.userData.full_name = this.encryptionService.get(constant.ENCRYPTIONKEY, this.userData.full_name);
    this.userId = this.encryptionService.get(constant.ENCRYPTIONKEY, this.userData.user_id);
    this.imageIcon = this.userData.full_name.charAt(0);
    this.image = localStorage.getItem('image');

    if (JSON.parse(localStorage.getItem('userdata'))) {
      this.userData.role = this.encryptionService.get(constant.ENCRYPTIONKEY, this.userData.role);
      if (this.userData.role === 'ROLE_SADMIN') {
        this.show = true;
      } else if (this.userData.role === 'ROLE_MEMBER') {
        this.show = false;
      }
    } else {
      this.router.navigate(['/']);
    }

    this.setSidebar();
    this.selectSidebar();
    this.getScreenSize();
  }

  @HostListener('window:resize', ['$event'])
  getScreenSize() {
    if (window.innerWidth < 1024 && this.sidebarOpened === false) {
      this.renderer.addClass(document.body, 'overflow-filter');
    } else {
      this.renderer.removeClass(document.body, 'overflow-filter');
    }
  }

  setSidebar() {
    this.subscription = this.baseService.clickBehaviourSubject.subscribe(data => {
      this.sidebarOpened = data;
      this.getScreenSize();
    });
  }

  toggleactiveMenu(i) {
    this.selectedItem = i;
  }

  selectSidebar() {
    this.baseService.changeOfRoutesBehaviourSubject.subscribe(currentUrl => {
      if (this.show) {
        if (currentUrl === '/admindashboard' || currentUrl.includes('/response')) {
          this.selectedItem = 1;
        } else if (currentUrl === '/list-sessions' || currentUrl.includes('/session-details') ||
          currentUrl.includes('/sessionReport') || currentUrl.includes('/session-mapping') || currentUrl.includes('/session-mapping-details')) {
          this.selectedItem = 2;
        } else if (currentUrl === '/list-templates' || currentUrl.includes('/editTemplate') ||
          currentUrl.includes('/cloneTemplate') || currentUrl.includes('/preview') || currentUrl === '/template') {
          this.selectedItem = 3;
        } else if (currentUrl === '/givereview' || currentUrl.includes('/myReview') ||
          currentUrl.includes('/fillReview')) {
          this.selectedItem = 4;
        } else if (currentUrl === "/report-analysis") {
          this.selectedItem = 5;
        }
      } else {
        if (currentUrl === '/dashboard' || currentUrl.includes('/myReview') ||
          currentUrl.includes('/fillReview')) {
          this.selectedItem = 1;
        }
      }
    });
  }

  navigateToAdminDashboard() {
    this.router.navigate(['/admindashboard']);
  }

  navigateToListSessions() {
    this.router.navigate(['/list-sessions']);
  }

  navigateToTemplate() {
    this.router.navigate(['/list-templates']);
  }

  navigateToUserDashboard() {
    this.router.navigate(['/dashboard']);
  }

  navigateToGiveReview() {
    this.router.navigate(['/givereview']);
  }

  navigateToReportAnalysis() {
    this.router.navigate(['/report-analysis']);
  }
}
