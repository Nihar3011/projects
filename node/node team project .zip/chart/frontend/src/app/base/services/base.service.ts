import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/enviroment.dev';

@Injectable()
export class BaseService {
  isOpened: boolean = true;
  clickBehaviourSubject = new BehaviorSubject<any>(true);
  notificationCountSubject = new BehaviorSubject<number>(-2);
  changeOfRoutesBehaviourSubject = new BehaviorSubject<any>('/');
  reloadNotificationSubject = new BehaviorSubject<any>('reload');

  url = `${environment.backendEndpoint}/review`;

  constructor(private http: HttpClient) { }

  collapse() {
    this.isOpened = !this.isOpened;
    this.clickBehaviourSubject.next(this.isOpened);
  }

  changeNotificationCount(count: number) {
    this.notificationCountSubject.next(count);
  }

  setRoutes(routes: String) {
    this.changeOfRoutesBehaviourSubject.next(routes);
  }

  getReviewScore(userId){
    return this.http.get(`${this.url}/${userId}`);
  }
}
