import { Injectable } from '@angular/core';
import * as io from 'socket.io-client';
import { Observable } from 'rxjs';
import { environment } from './../../../environments/enviroment.dev';

@Injectable({
  providedIn: 'root'
})
export class LivenotificationService {

  private url = environment.backendEndpoint.split('/review-api')[0];
  private socket;

  constructor() {
    this.socket = io(this.url, { path: '/review-api/socket.io/' }, { transports: ['websocket'] }, { source: true });
  }

  public sendMessage() {
    this.socket.emit('new-message', 'reload');
  }


  public callNotificationApi = () => {
    return Observable.create((observer) => {
      this.socket.on('new-message', (message) => {
        observer.next(message);
      });
    });
  }
}
