import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from './../../../environments/enviroment.dev';
import { AuthorizationService } from '../../shared/services/authorization.service';

@Injectable({
  providedIn: 'root'
})
export class NotificationsService {
  private url = `${environment.backendEndpoint}/notification`;

  constructor(private http: HttpClient, private auth: AuthorizationService) { }

  getAllNotifications(userId: number, scrollSize: number) {
    return this.http.get<any[]>(`${this.url}/list?userId=${userId}&scrollSize=${scrollSize}&flag=all`);
  }

  getLatestTenNotifications(userId: number) {
    return this.http.get<any>(`${this.url}/list?userId=${userId}&flag=new`);
  }

  markOneAsRead(notificationId: number) {
    return this.http.get<any>(`${this.url}/read?id=${notificationId}`);
  }

  markAllAsRead(userId: number) {
    return this.http.get<any>(`${this.url}/readall?id=${userId}`);
  }

  deleteOneNotification(notificationId: number) {
    return this.http.get<any>(`${this.url}/delete?id=${notificationId}`)
  }

  getNotificationLink = (type: number, id: number = null) => {
    if (type === 1 || type === 2 || type === 3) {
      return 'list-sessions';
    } else if (type === 4 || type === 6) {
      if (this.auth.getRole() === 'ROLE_SADMIN') {
        return 'givereview';
      } else {
        return 'dashboard';
      }
    } else if (type === 5 || type === 7 || type === 9) {
      return `myReview/${id}`;
    } else if (type === 8) {
      return `response/${id}`;
    } else if (type === 10 || type === 11 || type === 12) {
      return 'list-templates';
    } else if (type === 13) {
      return `response/${id}`;
    } else if (type === 14) {
      if (this.auth.getRole() === 'ROLE_SADMIN') {
        return 'givereview';
      } else {
        return 'dashboard';
      }
    }
    else if (type === 15) {
      return `response/${id}`;
    }
  }
}
