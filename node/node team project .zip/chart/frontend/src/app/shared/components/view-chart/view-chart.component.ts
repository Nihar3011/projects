import { Component, OnInit, Input, ViewChild, ElementRef } from '@angular/core';
import { CreateChartsService } from '../../../admin/services/create-charts.service';

@Component({
  selector: 'app-view-chart',
  templateUrl: './view-chart.component.html',
  styleUrls: ['./view-chart.component.scss']
})
export class ViewChartComponent implements OnInit {
  @Input() series: [];
  @Input() category: [];
  @Input() chartMetaData: any;

  @ViewChild('columnchart')
  columnChartRef!: ElementRef<any>;

  columnChart!: Highcharts.Chart;
  constructor(private chartsService: CreateChartsService) { }

  ngOnInit() {
    this.columnChart = this.chartsService.createChart(this.columnChartRef, this.chartMetaData.selectedChartType);
    this.chartsService.setXAxisTitles(this.columnChart, this.chartMetaData.xAxisTitle);
    this.chartsService.addXAxisCategories(this.columnChart, this.category);
    this.chartsService.updateSeries(this.columnChart, this.series);
  }
  
}
