import { Component, OnInit, Input, Output, EventEmitter, ElementRef, ViewChild } from '@angular/core';
import { FormBuilder, Validators, FormGroup, FormArray, FormControl } from '@angular/forms';
import { constant } from 'src/app/app.const';
import { CustomValidatorsService } from 'src/app/shared/services/custom-validators.service';
import { RxwebValidators } from '@rxweb/reactive-form-validators';
import { TemplateService } from 'src/app/shared/services/template.service';
@Component({
  selector: 'app-get-checkbox',
  templateUrl: './get-checkbox.component.html',
  styleUrls: ['./get-checkbox.component.scss']
})

export class GetCheckboxComponent implements OnInit {
  @Output() display: EventEmitter<any> = new EventEmitter<any>();
  @Output() remove: EventEmitter<any> = new EventEmitter<any>();
  @Output() changeType: EventEmitter<any> = new EventEmitter<any>();

  @Input() mainFormSubmit: boolean;
  @Input('data') data: any;
  @Input('change') change: boolean;
  @Input('scoreToggle') scoreToggle: FormControl;
  @Input() previewFlag: boolean;
  @Output() stop: EventEmitter<any> = new EventEmitter<any>();

  public errorElement: ElementRef;
  @ViewChild('error') set content(content: ElementRef) {
    this.errorElement = content;
  }
  public questionElement: ElementRef;
  @ViewChild('questionElement') set assetInput(elRef: ElementRef) {
    this.questionElement = elRef;
  }

  checkboxFieldForm: FormGroup;
  submitted = false;
  labels: FormArray;
  labelFlag = false;     // for add label button to change the style
  maxLength: number;
  warningMessage = [];
  warningMessageFlag = false;

  constructor(private formBuilder: FormBuilder,
    private customValidatorsService: CustomValidatorsService,
    private templateService: TemplateService) {
    this.labels = new FormArray([]);
    this.maxLength = constant.MAXLENGTH;
    this.checkboxFieldForm = this.formBuilder.group({
      question: ['', [Validators.required, this.customValidatorsService.textboxValidators(), Validators.maxLength(this.maxLength)]],
      totalScore: [{ value: '', disabled: true }],
      labels: this.formBuilder.array([]),
      selectedType: ['checkbox']

    });
  }

  ngOnInit() {
    this.customValidatorsService.markFormGroupUntouched(this.checkboxFieldForm);
    if (this.data !== null) {
      this.checkboxFieldForm.patchValue({ question: this.data.question, totalScore: this.data.questionScore });
      this.labels = (this.checkboxFieldForm.get('labels') as FormArray);
      this.data.labels.forEach((element, index) => {
        let formGroup: FormGroup = this.formBuilder.group({
          option: [`${element}`, [Validators.required,
          RxwebValidators.unique(),
          this.customValidatorsService.textboxValidators(),
          Validators.maxLength(this.maxLength)
          ]]
          , score: [this.data.scores[index]]
        });

        if (this.scoreToggle.value) {
          formGroup.get('score').setValidators(Validators.required);
        }
        this.labels.push(formGroup);
      });
      if (this.labels.controls.length < 1) {
        this.showWarning("Warning !", "at least one label Required.");
      } else {
        this.closeWarning();
      }

      this.templateService.getQuestionScoreCheckbox(this.checkboxFieldForm, this.labels);
    } else {
      this.addLabel();
    }
    this.checkboxFieldForm.valueChanges.subscribe(
      value => {
        this.labelFlag = this.checkboxFieldForm.invalid;
        if (this.labels.controls.length > 0) {
          this.closeWarning();
        } else {
          this.showWarning("Warning !", "at least one label Required.");
        }
      }
    );
    this.scoreToggle.valueChanges.subscribe(x => {
      this.customValidatorsService.scoreValidation(x, this.checkboxFieldForm.get('labels') as FormArray);
    });
    this.checkboxFieldForm.get('selectedType').valueChanges.subscribe(type => {
      this.changeTo(type);
    });
  }

  ngOnChanges() {
    this.onSubmit();
  }

  getLabel(): FormGroup {
    let formGroup: FormGroup = this.formBuilder.group({
      option: [``,
        [Validators.required,
        RxwebValidators.unique(),
        this.customValidatorsService.textboxValidators(),
        Validators.maxLength(this.maxLength)
        ]],
      score: ['']
    });

    if (this.scoreToggle.value) {
      formGroup.get('score').setValidators(Validators.required);
    }

    return formGroup;
  }

  addLabel() {
    if (this.submitted) {
      this.labelFlag = true;
    }
    this.labels = (this.checkboxFieldForm.get('labels') as FormArray);
    this.labels.push(this.getLabel());
  }

  setLabelValue(i: number) {
    const val = this.checkboxFieldForm.get('labels').get(i.toString()).get('option').value.trim();
    this.checkboxFieldForm.get('labels').get(i.toString()).get('option').setValue(val);
  }

  onRemove() {
    this.remove.emit();
  }

  removeLabel(index) {
    if (this.labels.controls.length > 1) {
      this.labels.removeAt(index);
      this.labelFlag = false;
      this.templateService.getQuestionScoreCheckbox(this.checkboxFieldForm, this.labels);
    } else {
      this.showWarning("Warning !", "at least one label Required.");
    }

  }

  onSubmit() {
    if (this.checkboxFieldForm.invalid) {
      this.customValidatorsService.markFormGroupTouched(this.checkboxFieldForm);
      if (this.errorElement) {
        this.questionElement.nativeElement.focus();
      }
      this.stop.emit(false);

    } else if (this.checkboxFieldForm.valid && this.labels.value.length < 1) {
      this.customValidatorsService.markFormGroupTouched(this.checkboxFieldForm);
      if (this.errorElement) {
        this.questionElement.nativeElement.focus();
      }
      this.stop.emit(false);
    } else {
      this.onSave();
      this.display.emit(this.checkboxFieldForm.getRawValue());
    }
  }

  onSave() {
    this.templateService.getQuestionScoreCheckbox(this.checkboxFieldForm, this.labels);
    this.labelFlag = true;
    this.submitted = true;
  }

  trimValue(event, controlName) {
    event.target.value = event.target.value.trim();
    this.checkboxFieldForm.controls[controlName].setValue(event.target.value);
  }

  showWarning(header: string, message: string) {
    this.warningMessageFlag = true;
    this.warningMessage[0] = header;
    this.warningMessage[1] = message;
  }

  closeWarning() {
    this.warningMessageFlag = false;
    this.warningMessage[0] = "";
    this.warningMessage[1] = "";
  }
  changeTo(type) {
    this.changeType.emit({ "value": this.checkboxFieldForm.getRawValue(), "type": type });
  }
}
