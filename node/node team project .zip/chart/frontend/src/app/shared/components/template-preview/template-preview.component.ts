import { TemplateService } from 'src/app/shared/services/template.service';
import { Component, OnInit, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { ToasterService } from 'src/app/shared/services/toaster.service';

@Component({
    selector: 'app-template-preview',
    templateUrl: './template-preview.component.html',
    styleUrls: ['./template-preview.component.scss']
})
export class TemplatePreviewComponent implements OnInit {
    public templateId;
    public canCall = false;
    form: FormGroup;
    public origin: string;
    public backPath: string;
    public templateData: any;
    constructor(private route: Router,
        private activatedRoute: ActivatedRoute,
        private templateService: TemplateService,
        public toast: ToasterService) {
    }
    ngOnInit() {
        this.templateId = this.activatedRoute.snapshot.paramMap.get('templateId');
        this.origin = this.activatedRoute.snapshot.queryParamMap.get('origin');
        if (!this.templateId) {
            this.route.navigate(['list-templates']);
        }
        else {
            this.templateService.getTemplate(this.templateId).subscribe((data) => {
                this.templateData = data;
                this.canCall = true;
            },error=>{
                this.route.navigate(['list-templates']);
                this.toast.showError('Error', "Invalid template id");
            }
            )
        }
        if (this.origin === 'create') {
            this.backPath = `editTemplate/${this.templateId}`;
        }
        else { this.backPath = 'list-templates'; }
    }
    closetab() {
        this.route.navigate([this.backPath]);
    }
    @Output() onSubmit($event) {

    }
}
