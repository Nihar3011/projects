import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ToasterService } from '../../services/toaster.service';
import { ResponseService } from '../../services/response.service';
import { constant } from 'src/app/app.const';
import { EncryptionService } from 'src/app/shared/services/encryption.service';
import { ReviewsService } from "src/app/user/services/reviews.service";
import { NgxSpinnerService } from 'ngx-spinner';
import { LivenotificationService } from 'src/app/base/services/livenotification.service';
import { TemplateService } from '../../services/template.service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomValidatorsService } from '../../services/custom-validators.service';
import { ReviewResponseComponent } from './review-response/review-response.component';


@Component({
  selector: 'app-response',
  templateUrl: './response.component.html',
  styleUrls: ['./response.component.scss']
})
export class ResponseComponent implements OnInit {


  role: string;
  mappingId: number;
  record: any = {};
  commentData: any = {};
  flag = 3;
  imageIcon: any;
  canCallDynamicForm: boolean = false;
  canCallComment: boolean = false;
  user: any;
  userName: any;
  editable: boolean = false;
  disabledButton = false;
  public revieweeData: any;
  public templateData: any;
  canCallReviewResponse: boolean = false;
  modalRef: BsModalRef;
  modalRefconfig = {
    ignoreBackdropClick: true
  };
  reevaluationForm: FormGroup;
  invalidReason: boolean = false;
  gracPeriod: boolean;
  constructor(private router: Router,
    private activatedRoute: ActivatedRoute,
    private reponseSesvice: ResponseService,
    private encryptionService: EncryptionService,
    private toster: ToasterService,
    public reviewservice: ReviewsService,
    private spinner: NgxSpinnerService,
    private liveNotification: LivenotificationService,
    private templateService: TemplateService,
    private modalService: BsModalService,
    private formBuilder: FormBuilder,
    private customValidatorService: CustomValidatorsService) {

    this.mappingId = this.activatedRoute.snapshot.params.mappingId;

    let userData = JSON.parse(localStorage.getItem('userdata'));
    this.role = this.encryptionService.get(constant.ENCRYPTIONKEY, userData.role);
    this.user = Number(this.encryptionService.get(constant.ENCRYPTIONKEY, userData.user_id));
    this.userName = this.encryptionService.get(constant.ENCRYPTIONKEY, userData.full_name);
    this.reevaluationForm = this.formBuilder.group({
      reason: ['', [Validators.required, Validators.maxLength(500), this.customValidatorService.textboxValidators()]]
    });
  }

  private newMethod(): any {
    return 'showComment';
  }
  getComment(value) {

    this.gracPeriod = value

  }
  ngOnInit() {
    this.loadRecord();
    this.loadComments();
    this.reviewservice.getRecords(this.mappingId).subscribe(
      data => {
        this.revieweeData = data;
        this.templateService.getTemplate(this.revieweeData.templateId).subscribe(template => {
          this.templateData = template;
          this.canCallReviewResponse = true;
        })
        this.spinner.hide();
      },
      error => { this.spinner.hide(); }
    );
  }
  edit() {
    this.editable = true;
  }
  loadRecord() {
    this.reponseSesvice.getRecords(this.mappingId).subscribe(
      data => {
        this.record = data;
        if (this.record.status === 1) {
          this.toster.showWarn("Access Denied", "Review has not been yet filled");
          if (this.role === "ROLE_SADMIN") {
            if (this.router.url.includes("response")) {
              this.router.navigate(["admindashboard"]);
            } else {
              this.router.navigate(["givereview"]);
            }
          } else {
            this.router.navigate(["dashboard"]);
          }
        } else if (this.role !== "ROLE_SADMIN") {
          let reviewerFlag = this.record.secondaryReviewers.some((item) => item == this.user) || this.record.reviewerId === this.user;
          if (this.record.status === 3 && reviewerFlag) {
            this.canCallDynamicForm = true;
          } else if (this.record.status === 2 && (reviewerFlag || this.record.revieweeId === this.user)) {
            this.canCallDynamicForm = true;
          } else {
            this.toster.showError(
              "Error",
              "Restricted url, you can't see the response"
            );
            this.router.navigate(["dashboard"]);
          }
        } else {
          this.canCallDynamicForm = true;
        }
      },
      error => {
        if (error.error.code === "NORECORD") {
          this.toster.showError("Error", "No record found for this candidate");
        } else {
          this.toster.showError("Access Denied", "Invalid access request");
        }
        if (this.role === "ROLE_SADMIN") {
          if (this.router.url.includes("response")) {
            this.router.navigate(["admindashboard"]);
          } else {
            this.router.navigate(["givereview"]);
          }
        } else {
          this.router.navigate(["dashboard"]);
        }
      }
    );
  }

  onSubmit(flag) {
    this.editable = flag;
    this.loadComments();
  }
  loadComments() {
    this.reponseSesvice.getComments(this.mappingId).subscribe(
      data => {
        this.commentData = {
          "comments": data,
          "commentIndex": -1
        };
        this.canCallComment = true;

      },
      error => {
        if (error.error.code === 'NORECORD') {
          this.commentData = {
            "comments": [],
            "commentIndex": -1
          };
          this.canCallComment = true;
        }
      }
    );
  }

  modifiedCommentsData(commentData: any) {
    this.reponseSesvice.updateComment(commentData).subscribe(() => {
      this.spinner.hide();
      this.loadComments();
    });
  }

  Back() {
    if (this.role === 'ROLE_SADMIN') {
      if (this.router.url.includes("response")) {
        this.router.navigate(['admindashboard']);
      }
      else {
        this.router.navigate(['givereview']);
      }
    }
    else {
      this.router.navigate(['dashboard']);
    }
  }

  reEvaluationPopup(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, this.modalRefconfig);
  }

  reEvaluationAction() {
    if (this.reevaluationForm.valid) {

      let data = {
        "message": `<b>${this.userName}</b> has applied for <b>Re-evaluation</b> for this review with the reason: <b>${this.reevaluationForm.value.reason.trim()}</b>`,
        "mappingId": this.mappingId,
        "userId": this.user
      }
      this.modalRef.hide();
      this.invalidReason = false;
      this.reevaluationForm.reset();
      this.reponseSesvice.reEvaluationRequest(data).subscribe(
        result => {
          this.spinner.hide();
          this.liveNotification.sendMessage();
          this.ngOnInit();
          this.toster.showSuccess('Success', 'Re-evaluation request sent successfully');

        }, error => {
          this.spinner.hide();
          this.toster.showError("Error", "Could not submit the request");
        }
      );

    }
    else {
      if (this.reevaluationForm.controls.reason.errors) {
        if (!!this.reevaluationForm.controls.reason.errors.required || !!this.reevaluationForm.controls.reason.errors.dataAbsents) {
          this.invalidReason = true;
        }
        else {
          this.invalidReason = false;
        }
      }
    }
  }

  decline(): void {
    this.modalRef.hide();
    this.invalidReason = false;
    this.reevaluationForm.reset();
  }

  get formControls() {
    return this.reevaluationForm.controls.reason;
  }

  publish() {
    this.disabledButton = true;
    this.reponseSesvice.publishreview(this.mappingId, this.user).subscribe(
      () => {
        this.toster.showSuccess('Success', 'Review published Successfully.');
        if (this.router.url.includes("response")) {
          this.spinner.hide();
          this.liveNotification.sendMessage();
          this.router.navigate(['admindashboard']);
        }
        else {
          this.router.navigate(['givereview']);
        }
      },
      (error) => {
        if (error.error.code === 'UNAUTHORIZEDACCESS') {
          this.toster.showWarn('Error', 'Unauthorized access for given request');
        }
        else {
          this.toster.showError('Error', 'Error in review publish');
        }
      }
    );
  }
}
