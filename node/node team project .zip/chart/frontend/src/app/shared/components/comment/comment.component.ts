import { Component, OnInit, Input, Output, EventEmitter, TemplateRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ResponseService } from '../../services/response.service';
import { constant } from 'src/app/app.const';
import { EncryptionService } from 'src/app/shared/services/encryption.service';
import { CustomValidatorsService } from '../../services/custom-validators.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { LivenotificationService } from 'src/app/base/services/livenotification.service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-comment',
  templateUrl: './comment.component.html',
  styleUrls: ['./comment.component.scss']
})
export class CommentComponent implements OnInit {

  @Input() mappingId: number;
  @Input() commentData;
  @Input() status: any;
  @Input() reviewee: number;
  @Input() gracPeriod: boolean;

  @Output() modifiedCommentsData: EventEmitter<any> = new EventEmitter<any>();
  @Output() reloadCommentsData: EventEmitter<any> = new EventEmitter<any>();

  userData: any;
  commentIndex: number = -1;
  commentForm: FormGroup;
  image: string;
  imageIcon: any;
  flag = 3;
  submittedComment: boolean = false;
  submittedReply: boolean = false;
  enableButton = true;
  disableRequestButton = false;
  modalRef: BsModalRef;
  modalRefconfig = {
    ignoreBackdropClick: true
  };

  constructor(private formBuilder: FormBuilder,
    private encryptionService: EncryptionService,
    private reponseSesvice: ResponseService,
    private customValidatorService: CustomValidatorsService,
    private spinner: NgxSpinnerService,
    private liveNotification: LivenotificationService,
    private modalService: BsModalService) {

    this.userData = JSON.parse(localStorage.getItem('userdata'));
    this.commentForm = this.formBuilder.group({
      comment: ['', [Validators.required, this.customValidatorService.textboxValidators(), Validators.maxLength(1000)]]
    });
  }

  ngOnInit() {
    this.userData.user_id = Number(this.encryptionService.get(constant.ENCRYPTIONKEY, this.userData.user_id));
    this.userData.role = this.encryptionService.get(constant.ENCRYPTIONKEY, this.userData.role);
    this.userData.full_name = this.encryptionService.get(constant.ENCRYPTIONKEY, this.userData.full_name);
    this.imageIcon = this.userData.full_name.charAt(0);
    this.image = localStorage.getItem('image');
    this.commentIndex = this.commentData.commentIndex;
  }

  commentBox(i = -1) {
    this.submittedComment = false;
    this.submittedReply = false;
    this.commentIndex = this.commentIndex === i ? i : -1;
  }

 

  get formControls() {
    return this.commentForm.controls.comment;
  }
  changeCommentIndex(i: number) {
    this.commentForm.reset();
    this.submittedComment = false;
    this.submittedReply = false;
    this.commentIndex = this.commentIndex == i ? -1 : i;
  }

  changeVisibility(event, i: number) {
    if (event.type == "change") {
      this.modifiedCommentsData.emit(this.commentData.comments[i]);
    }
  }

  sendComment(id: number = -1, commentId: number = 0, commentVisibility: boolean = true) {
    this.enableButton = false;
    if (id === -1) {
      this.commentIndex = -1;
      this.submittedComment = true;
      this.submittedReply = false;
    }
    else {
      this.submittedReply = true;
      this.submittedComment = false;
    }
    if (this.commentForm.valid) {
      let data = {
        "comment": this.commentForm.value.comment.trim(),
        "mappingId": this.mappingId,
        "userId": this.userData.user_id,
        "parentId": commentId,
        "commentVisibility": commentVisibility
      }

      this.reponseSesvice.sendComment(data).subscribe(
        data => {
          this.commentForm.reset();
          this.submittedReply = false;
          this.submittedComment = false;
          this.commentIndex = -1;
          this.reloadCommentsData.emit();
          this.spinner.hide();
          this.enableButton = true;
          this.liveNotification.sendMessage();
        }, error => {
          this.spinner.hide();
          this.enableButton = true;
        }
      );
      ;
    }
    else {
      this.spinner.hide();
      this.enableButton = true;
      return;
    }
  }


  declineRequest(commentData) {
    this.disableRequestButton = true;
    let data = {
      "mappingId": this.mappingId,
      "userId": this.userData.user_id,
      "commentId": commentData.commentId,
      "response": false
    }
    this.reponseSesvice.reEvaluationApproval(data).subscribe((result) => {
      this.spinner.hide();
      this.liveNotification.sendMessage();
      window.location.reload();

    }, error => {
      this.spinner.hide();
      window.location.reload();
    });
  }

  confirmationPopup(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, this.modalRefconfig);
  }

  reEvaluationConfirm(commentData) {
    let data = {
      "mappingId": this.mappingId,
      "userId": this.userData.user_id,
      "commentId": commentData.commentId,
      "response": true
    }
    this.reponseSesvice.reEvaluationApproval(data).subscribe((result) => {
      this.spinner.hide();
      this.liveNotification.sendMessage();
      window.location.reload();
    }, error => {
      this.spinner.hide();
      window.location.reload();
    });


    this.modalRef.hide();
  }

  decline(): void {
    this.modalRef.hide();
  }
}