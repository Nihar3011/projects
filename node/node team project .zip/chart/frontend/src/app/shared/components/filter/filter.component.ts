import { ChartsService } from './../../services/charts.service';
import { constant } from 'src/app/app.const';
import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Options } from 'ng5-slider';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { SessionMappingService } from '../../../admin/services/session-mapping.service';
import { SessionsService } from '../../../admin/services/sessions.service';
import { AnalysisService } from '../../../admin/services/analysis.service';

interface dropdownData {
  value: number;
  label: string;
}

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.scss']
})
export class FilterComponent implements OnInit {

  @Output() filterData: EventEmitter<any> = new EventEmitter<any>();
  @Output() filterizedDataForAnalysis: EventEmitter<any> = new EventEmitter<any>();
  @Output() closeFilter: EventEmitter<any> = new EventEmitter<any>();
  @Input() sortFieldLabel: any;
  @Input() editFilterData: any;

  sortField: string[];
  forChart: boolean;
  dateBefore: Date;
  maxDate: Date;
  options: Options;
  leaderboardForm: FormGroup;
  filterDataFields;
  users: dropdownData[];
  names: dropdownData[];
  reviewers: dropdownData[];
  templates: dropdownData[];
  designations: dropdownData[];

  showReviewer: boolean = false;
  
  constructor(private fb: FormBuilder,
    private spinner: NgxSpinnerService,
    private toast: ToasterService,
    private sessionMappingService: SessionMappingService,
    private sessionsService: SessionsService,
    private chartsService: ChartsService,
    private analysisService: AnalysisService) {
    this.maxDate = new Date();
    this.dateBefore = new Date();
    this.dateBefore.setFullYear(this.dateBefore.getFullYear() - 1);
    this.options = {
      floor: 0,
      ceil: 100,
      step: 5
    };
    this.sortField = constant.SORTFIELDFORANALYSIS;
    this.initializeForm();

  }

  ngOnInit() {
    if (this.editFilterData) {
      this.setFilterForm(this.editFilterData);
    }
    this.loadData();
  }

  ngAfterViewInit() {
    this.spinner.hide();
  }

  setFilterForm(data) {
    let startDate = new Date(data.dateRange[0]);
    let endDate = new Date(data.dateRange[1]);
    this.leaderboardForm.patchValue({
      selectedDesignation: data.designation,
      selectedUser: data.user,
      selectedReviewer: data.reviewer,
      selectedSession: data.session,
      selectedTemplate: data.template,
      selectedYear: new Date(data.joiningYear),
      sliderControl: data.score,
    });
    this.leaderboardForm.get('range').setValue([startDate, endDate])
  }

  initializeForm() {
    this.leaderboardForm = this.fb.group({
      range: this.fb.control([this.dateBefore, this.maxDate]),
      selectedUser: [""],
      selectedReviewer: [""],
      selectedSession: [""],
      selectedTemplate: [""],
      selectedDesignation: [""],
      selectedYear: [""],
      sliderControl: this.fb.control([0, 100])
    });
  }

  getFilterObject() {    
    let data = {
      user: this.leaderboardForm.value.selectedUser || '',
      session: this.leaderboardForm.value.selectedSession || '',
      template: this.leaderboardForm.value.selectedTemplate || '',
      designation: this.leaderboardForm.value.selectedDesignation || '',
      reviewer: this.leaderboardForm.value.selectedReviewer || '',
      dateRange: this.leaderboardForm.value.range || '',
      joiningYear: this.leaderboardForm.value.selectedYear || '',
      score: this.leaderboardForm.value.sliderControl || '',
      filter: true
    }    
    return data;
  }

  loadData() {
    this.loadSessions();
    this.getDesignation();
    this.getTemplates();
    this.getUserNames();
    let data = this.getFilterObject();
    this.getAnalysisData(data);
  }

  designationSelected(designation) {
    if (designation.value.length > 0) {
      this.analysisService.getUserByDesignation(designation.value).subscribe(
        data => {
          this.users = data;
          this.spinner.hide();
        }, error => {
          this.onError();
          this.spinner.hide();
        })
      designation.value.length > 1 ? this.showReviewer = false : this.showReviewer;
    } else {
      this.getUserNames();
      designation.filterValue = null;
      this.showReviewer = false;
    }
    this.leaderboardForm.controls['selectedUser'].reset();
  }

  userSelected(user) {
    if (user.value.length === 1) {
      this.getUserDesignation(user.value);
      this.showReviewer = true;
      this.getReviewers(user.value);
    } else if (user.value.length > 1) {
      this.getUserDesignation(user.value);
      this.showReviewer = false;
      this.leaderboardForm.controls['selectedReviewer'].reset();
    } else {
      user.filterValue = null;
      this.showReviewer = false;
      this.leaderboardForm.controls['selectedReviewer'].reset();
    }
  }

  templateSelected(template) {
    template.filterValue = null;
  }

  // backend apis //

  onError() {
    this.toast.showError('Error', 'Error in Fetching records');
    this.spinner.hide();
  }

  getDesignation() {
    this.analysisService.getDesignationNames().subscribe(
      data => {
        this.designations = data;
        this.spinner.hide();
      }, error => {
        this.onError();
      })
  }

  getReviewers(userId: number) {
    this.analysisService.getReviewers(userId).subscribe(
      data => {
        this.reviewers = data;
        this.spinner.hide();
      }, error => {
        this.onError();
      })
  }

  getUserDesignation(userId: number) {
    this.analysisService.getUserDesignation(userId).subscribe(
      data => {
        let value = [];
        data.filter((item) => {
          value.push(item.value);
        });
        this.leaderboardForm.get('selectedDesignation').reset();
        this.leaderboardForm.patchValue({ selectedDesignation: value });
        this.spinner.hide();
      }, error => {
        this.onError();
      })
  }

  getTemplates() {
    this.sessionMappingService.getTemplates().subscribe(data => {
      this.templates = data;
      this.spinner.hide();
    }, error => {
      this.onError();
    });
  }

  getUserNames() {
    this.users = [];
    this.sessionMappingService.getUsers().subscribe(data => {
      let userData = data['member'];
      userData.map((userName) => {
        this.users.push({ value: userName.user_id, label: userName.fullname });
      });
      this.spinner.hide();
    }, error => {
      this.onError();
    });
  }

  loadSessions() {
    this.names = [];
    this.sessionsService.getAllSessions().subscribe(
      data => {
        data.map((session) => {
          this.names.push({ value: session.s_id, label: session.s_name });
        })
        this.spinner.hide();
      },
      error => {
        this.onError();
      });
  }

  async getAnalysisData(data) {    
    this.chartsService.setSubmittedFlag(false);
    let sortFieldForChart;
    this.filterDataFields = data;
    this.spinner.hide();
    if (this.forChart) {      
      this.filterizedDataForAnalysis.emit(data);
      sortFieldForChart = this.sortFieldLabel;
    } else {
      sortFieldForChart = this.sortField.indexOf('reviewee');
    }
    
    await this.analysisService.getAnalysisData({ "data": data, "sortField": sortFieldForChart }).subscribe(
      async (data) => {
        await this.filterData.emit(data);
        this.spinner.hide();
      },
      error => {
        this.onError();
      });
  }

  resetFilter() {
    this.leaderboardForm.reset();
    this.leaderboardForm.patchValue({ sliderControl: [0, 100] });
    this.getAnalysisData({ filter: false });
    this.closeFilter.emit(true);
  }

  async applyFilter() {    
    let data = await this.getFilterObject();    
    await this.getAnalysisData(data);
    this.closeFilter.emit(true);
  }
}
