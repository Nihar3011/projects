export { TemplateCreateComponent } from './template-create/template-create.component';
export { GetRadioComponent } from './template-create/get-radio/get-radio.component';
export { GetTextComponent } from './template-create/get-text/get-text.component';
export { TemplatePreviewComponent } from './template-preview/template-preview.component';
export { GetCheckboxComponent } from './template-create/get-checkbox/get-checkbox.component';
export { GetRatingComponent } from './template-create/get-rating/get-rating.component';

export {ErrorpageComponent} from './errorpage/errorpage.component';
