import { Component, OnInit, Input, Output, EventEmitter, OnChanges, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, Validators, FormGroup, FormArray, FormControl } from '@angular/forms';
import { TemplateService } from 'src/app/shared/services/template.service';
import { constant } from 'src/app/app.const';
import { CustomValidatorsService } from 'src/app/shared/services/custom-validators.service';
import { RxwebValidators } from '@rxweb/reactive-form-validators';

@Component({
  selector: 'app-get-radio',
  templateUrl: './get-radio.component.html',
  styleUrls: ['./get-radio.component.scss']
})
export class GetRadioComponent implements OnInit, OnChanges {

  @Output() display: EventEmitter<any> = new EventEmitter<any>();
  @Output() remove: EventEmitter<any> = new EventEmitter<any>();
  @Output() changeType: EventEmitter<any> = new EventEmitter<any>();


  @Input() mainFormSubmit: boolean;
  @Input() previewFlag: boolean;
  @Input() change: boolean;
  @Input('data') data: any;
  @Input('scoreToggle') scoreToggle: FormControl;
  @Output() stop: EventEmitter<any> = new EventEmitter<any>();
  public errorElement: ElementRef;
  @ViewChild('error') set content(content: ElementRef) {
    this.errorElement = content;
  }
  public questionElement: ElementRef;
  @ViewChild('questionElement') set assetInput(elRef: ElementRef) {
    this.questionElement = elRef;
  }
  radioFieldForm: FormGroup;
  submitted = false;
  labels: FormArray;
  labelFlag = false;     // for add label button to change the style
  maxLength: number;
  warningMessage = [];
  warningMessageFlag = false;

  constructor(private formBuilder: FormBuilder,
    private templateService: TemplateService,
    private customValidatorsService: CustomValidatorsService,
  ) {
    this.maxLength = constant.MAXLENGTH;
    this.labels = new FormArray([]);
    this.radioFieldForm = this.formBuilder.group({
      question: ['', [Validators.required, this.customValidatorsService.textboxValidators(), Validators.maxLength(this.maxLength)]],
      totalScore: [{ value: '', disabled: true }],
      labels: this.formBuilder.array([]),
      selectedType: ['radio']
    });

  }

  ngOnInit() {
    this.customValidatorsService.markFormGroupUntouched(this.radioFieldForm);
    if (this.data !== null) {
      this.radioFieldForm.patchValue({ question: this.data.question, totalScore: this.data.questionScore });
      this.labels = (this.radioFieldForm.get('labels') as FormArray);
      this.data.labels.forEach((element, index) => {
        let formGroup: FormGroup = this.formBuilder.group({
          option: [`${element}`, [Validators.required,
          RxwebValidators.unique(),
          this.customValidatorsService.textboxValidators(),
          Validators.maxLength(this.maxLength)
          ]],
          score: [this.data.scores[index]]
        });
        if (this.scoreToggle.value) {
          formGroup.get('score').setValidators(Validators.required);
        }        
        this.labels.push(formGroup);
      });
      if (this.labels.controls.length < 2) {
        this.showWarning("Warning !", "at least two labels Required.");
      }else{
        this.closeWarning();
      }

      this.templateService.getQuestionScoreRadio(this.radioFieldForm, this.labels);
    } else {
      this.addLabel();
      this.addLabel();
    }
    this.radioFieldForm.valueChanges.subscribe(value => {
      this.labelFlag = this.radioFieldForm.invalid;
      if (this.labels.controls.length > 1) {
        this.closeWarning();
      }
      else {
        this.showWarning("Warning !", "at least two labels Required.");
      }
    });
    this.scoreToggle.valueChanges.subscribe(x => {
      this.customValidatorsService.scoreValidation(x, this.radioFieldForm.get('labels') as FormArray);
    });
    this.radioFieldForm.get('selectedType').valueChanges.subscribe(type => {
      this.changeTo(type);
    });

  }

  ngOnChanges() {
    this.onSubmit();
  }

  getLabel(): FormGroup {
    let formGroup: FormGroup = this.formBuilder.group({
      option: [``,
        [Validators.required,
        RxwebValidators.unique(),
        this.customValidatorsService.textboxValidators(),
        Validators.maxLength(this.maxLength)
        ]],
      score: ['']
    });

    if (this.scoreToggle.value) {
      formGroup.get('score').setValidators(Validators.required);
    }

    return formGroup;
  }

  addLabel() {
    if (this.submitted) {
      this.labelFlag = true;
    }
    this.labels = (this.radioFieldForm.get('labels') as FormArray);
    this.labels.push(this.getLabel());
  }

  setLabelValue(i: number) {
    const val = this.radioFieldForm.get('labels').get(i.toString()).get('option').value.trim();
    this.radioFieldForm.get('labels').get(i.toString()).get('option').setValue(val);
  }
  onRemove() {
    this.remove.emit();
  }

  removeLabel(index) {
    if (this.labels.controls.length > 2) {
      this.labels.removeAt(index);
      this.labelFlag = false;
      this.templateService.getQuestionScoreRadio(this.radioFieldForm, this.labels);
    } else {
      this.showWarning("Warning !", "at least two labels Required.");
    }
  }

  onSubmit() {
    if (this.radioFieldForm.invalid) {
      this.customValidatorsService.markFormGroupTouched(this.radioFieldForm);
      if (this.errorElement) {
        this.questionElement.nativeElement.focus();
      }
      this.stop.emit(false);

    } else if (this.radioFieldForm.valid && this.labels.value.length < 2) {
      this.customValidatorsService.markFormGroupTouched(this.radioFieldForm);
      if (this.errorElement) {
        this.questionElement.nativeElement.focus();
      }
      this.stop.emit(false);
    } else {
      this.onSave();
      this.display.emit(this.radioFieldForm.getRawValue());
    }
  }

  onSave() {
    this.templateService.getQuestionScoreRadio(this.radioFieldForm, this.labels);
    this.labelFlag = true;
    this.submitted = true;
  }

  trimValue(event, controlName) {
    event.target.value = event.target.value.trim();
    this.radioFieldForm.controls[controlName].setValue(event.target.value);
  }

  showWarning(header: string, message: string) {
    this.warningMessageFlag = true;
    this.warningMessage[0] = header;
    this.warningMessage[1] = message;
  }

  closeWarning() {
    this.warningMessageFlag = false;
    this.warningMessage[0] = "";
    this.warningMessage[1] = "";
  }

  changeTo(type) {
    this.changeType.emit({ "value": this.radioFieldForm.getRawValue(), "type": type });
  }
}
