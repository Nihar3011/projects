import { Component, OnInit, TemplateRef, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ToasterService } from '../../services/toaster.service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { constant } from 'src/app/app.const';
import { FilterComponent } from '../filter/filter.component';
import { ChartsService } from '../../services/charts.service';
import { EncryptionService } from '../../services/encryption.service';
import { CustomValidatorsService } from '../../services/custom-validators.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-add-chart',
  templateUrl: './add-chart.component.html',
  styleUrls: ['./add-chart.component.scss']
})
export class AddChartComponent implements OnInit {

  @ViewChild('filterComponent') filterComponent: FilterComponent;
  @Input() formData: any;
  @Input() editFilterData: any;
  @Output() update: EventEmitter<any> = new EventEmitter<any>();

  chartForm: FormGroup;
  chartImage: string;
  totalRecords: number;
  modalRef: BsModalRef | null;
  modalRef2: BsModalRef;
  analysisData: any;
  rowGroupMetadata: any;
  finalSeries: any;
  category = [];
  xAxisVariables = [];
  sortField: string[];
  sortFieldLabel: number;
  chartObject: any;
  updateFlag: boolean;
  chartId: number;
  canRender: boolean;
  filterizedDataForAnalysis: any;
  constructor(private fb: FormBuilder,
    private modalService: BsModalService,
    private chartsService: ChartsService,
    private encryptedService: EncryptionService,
    private customValidatorsService: CustomValidatorsService,
    public toster: ToasterService,
    private spinner: NgxSpinnerService) {
    this.xAxisVariables = [
      { 'value': 'time' },
      { 'value': 'session' },
      { 'value': 'template' },
      { 'value': 'designation' }
    ];
    this.sortField = constant.SORTFIELDFORANALYSIS;
    this.sortFieldLabel = 0;
    this.chartImage = 'assets/images/column-chart.png';
    this.initializeForm();

  }

  ngOnInit() {
    if (this.formData && this.editFilterData) {
      this.updateFlag = true;

      this.chartForm.patchValue({
        selectedChartType: this.formData.chartType,
        chartTitle: this.formData.chartTitle,
        xAxisTitle: this.formData.xAxisTitle,
        selectedXAxisVariable: { 'value': this.formData.xAxisField },
        viewToggle: this.formData.viewToggle
      });
      this.chartId = this.formData.chartId;
    } else {
      this.updateFlag = false;
    }
    this.filterComponent.forChart = true;

    this.onFormFieldValueChange();
  }

  onFormFieldValueChange() {
    this.chartForm.get('selectedChartType').valueChanges.subscribe(value => {
      switch (value) {
        case 'column':
          this.chartForm.patchValue({ selectedXAxisVariable: { 'value': 'session' } });
          this.chartImage = 'assets/images/column-chart.png';
          break;
        case 'line':
          this.chartForm.patchValue({ selectedXAxisVariable: { 'value': 'time' } });
          this.chartImage = 'assets/images/line-chart.png';
          break;
      }
    });
    this.chartForm.get('selectedXAxisVariable').valueChanges.subscribe(value => {
      this.sortFieldLabel = (this.sortField.indexOf(value.value) === 4) ? 3 : this.sortField.indexOf(value.value);
    });
  }


  initializeForm() {
    this.chartForm = this.fb.group({
      selectedChartType: ["column", Validators.required],
      chartTitle: ['', Validators.required],
      xAxisTitle: [''],
      selectedXAxisVariable: [{ 'value': 'session' }, Validators.required],
      viewToggle: [false, [Validators.required]],
    });
  }
  resolveAfter2Seconds(x) {
    return new Promise(resolve => {
      setTimeout(() => {
        resolve(x);
      }, 500);
    });
  }
  async  openModalWithClass(template: TemplateRef<any>) {
    await this.filterComponent.applyFilter();
    const value = <number>await this.resolveAfter2Seconds(20);
    this.modalRef = this.modalService.show(
      template,
      Object.assign({}, { class: 'gray modal-lg' })
    );
  }

  async saveChart() {
    if (this.chartForm.valid) {
      await this.filterComponent.applyFilter();
      const value = <number>await this.resolveAfter2Seconds(50);
      if (this.filterizedDataForAnalysis) {
        let userData = JSON.parse(localStorage.getItem('userdata'));
        userData.user_id = this.encryptedService.get(
          constant.ENCRYPTIONKEY,
          userData.user_id
        );
        this.chartObject = {
          "viewToggle": this.chartForm.get('viewToggle').value,
          "chartType": this.chartForm.get('selectedChartType').value,
          "chartTitle": this.chartForm.get('chartTitle').value,
          "xAxisTitle": this.chartForm.get('xAxisTitle').value,
          "xAxisField": this.chartForm.get('selectedXAxisVariable').value.value,
          "yAxisField": "score",
          "userId": userData.user_id,
          "filterData": [this.filterizedDataForAnalysis]
        };
        if (this.updateFlag) {
          this.chartObject["chartId"] = this.chartId;
          this.chartsService.editChart(this.chartObject).subscribe(result => {
            this.toster.showSuccess('Success', 'Chart Updated !');
            this.chartsService.setSubmittedFlag(true);
            this.update.emit(true);
          }, error => {
            this.toster.showError('Error', "Error in update chart");
          }
          );
        } else {
          this.chartsService.saveChart(this.chartObject).subscribe(result => {
            this.toster.showSuccess('Success', 'Chart Saved !');
            this.chartsService.setSubmittedFlag(true);

          }, error => {
            this.toster.showError('Error', "Error in save chart");
          }
          );
        }
      }
    } else {
      this.customValidatorsService.markFormGroupTouched(this.chartForm);
    }
  }

  getFilterData(data) {
    this.filterizedDataForAnalysis = data;
  }

  async loadData(data) {
    this.analysisData = data;
    let chartData = await this.chartsService.generateChartData(
      this.chartForm.get('selectedChartType').value,
      data,
      this.chartForm.get('selectedXAxisVariable').value.value,
    );
    this.finalSeries = chartData.seriesData;
    this.category = chartData.category;
    this.canRender = true;
  }

  ngOnDestroy() {
    this.filterComponent.forChart = false;
    this.editFilterData = null;
    this.formData = null;
  }
}
