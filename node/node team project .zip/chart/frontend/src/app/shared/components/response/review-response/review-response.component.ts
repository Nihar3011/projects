import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { TemplateService } from '../../../services/template.service';
import { ResponseService } from '../../../services/response.service';
import { ToasterService } from '../../../services/toaster.service';
import { Router } from '@angular/router';
import { EncryptionService } from 'src/app/shared/services/encryption.service';
import { constant } from 'src/app/app.const';
import { NgxSpinnerService } from 'ngx-spinner';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-review-response',
  templateUrl: './review-response.component.html',
  styleUrls: ['./review-response.component.scss']
})
export class ReviewResponseComponent implements OnInit {

  @Input() mappingId;
  @Input() templateData;
  @Output() emitShowComment: EventEmitter<any> = new EventEmitter<any>();

  showComment: boolean;
  responseData: any;
  revieweeScore: number;
  templateScore: number = 0;
  templateScorableFlag: boolean;
  response: any[] = [];
  role: any;
  user: any;
  form = null;
  canRender = false;

  constructor(
    private router: Router,
    private toster: ToasterService,
    private encryptionService: EncryptionService,
    private responseService: ResponseService,
    private spinner: NgxSpinnerService) {

    let userData = JSON.parse(localStorage.getItem('userdata'));
    this.role = this.encryptionService.get(constant.ENCRYPTIONKEY, userData.role);
    this.user = Number(this.encryptionService.get(constant.ENCRYPTIONKEY, userData.user_id));
    this.role = this.encryptionService.get(constant.ENCRYPTIONKEY, JSON.parse(localStorage.getItem('userdata')).role);;
  }

  ngOnInit() {
    this.loadresponseData(this.mappingId);
    this.templateScore = this.templateData.templateScore;
    this.templateScorableFlag = this.templateData.isScorable;
  }

  loadresponseData(mappingId) {
    this.responseService.getResponse(mappingId, this.user).subscribe(
      data => {
        this.responseData = data.response;
        this.revieweeScore = data.revieweeScore;
        this.showComment = data.showComment;
        this.emitShowComment.emit(this.showComment);
        this.loadData();
      },
      error => {
        this.spinner.hide();
        if (error.error.code === 'NORECORD') {
          this.toster.showError('Error', "No response data found for this record");
          if (this.role === 'ROLE_SADMIN') {
            if (this.router.url.includes("response")) {
              this.router.navigate(['admindashboard']);
            }
            else {
              this.router.navigate(['givereview']);
            }
          }
          else {
            this.router.navigate(['dashboard']);
          }
        }
      }
    );
  }

  loadData() {
    let fieldsCtrls = {};
    this.templateData.templateStructure.map((e, index) => {
      let questionKey = Object.keys(e)[0];
      switch (e[questionKey].type) {
        case 'checkbox':
          let ans = this.responseData[index][questionKey].response;
          let anskey = Object.keys(this.responseData[index][questionKey].response);
          let data = [];
          anskey.forEach(x => {
            if (ans[x] === true) {
              data.push(x);
            }
          })
          this.response.push({
            "type": e[questionKey].type,
            "question": e[questionKey].question,
            "answer": data.toString()
          });
          break;
        case 'rating':
          fieldsCtrls[e[questionKey].type + index] = new FormControl(`${this.responseData[index][questionKey].response}`, [Validators.required]);
          this.response.push({
            "name": e[questionKey].type + index,
            "labels": (e[questionKey].labels),
            "type": e[questionKey].type,
            "question": e[questionKey].question,
            "answer": this.responseData[index][questionKey].response
          });
          break;
        case 'radio':
          this.response.push({
            "type": e[questionKey].type,
            "question": e[questionKey].question,
            "answer": this.responseData[index][questionKey].response
          });
          break;
        case 'text':
          this.response.push({
            "type": e[questionKey].type,
            "question": e[questionKey].question,
            "answer": this.responseData[index][questionKey].response
          });
          break;
      }
    });
    this.form = new FormGroup(fieldsCtrls);
    this.canRender = true;
    this.form.disable();
    this.spinner.hide();
  }
}
