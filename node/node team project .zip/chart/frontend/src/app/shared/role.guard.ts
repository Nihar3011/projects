import { Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot } from '@angular/router';
import { AuthorizationService } from './services/authorization.service';
import { ErrorpageService } from './services/errorpage.service';
import { AuthGuard } from './auth.guard';

@Injectable({
  providedIn: 'root'
})
export class RoleGuard implements CanActivate {
  constructor(private auth: AuthorizationService,
    private authGuard: AuthGuard,
    private router: Router, private errorpageservice: ErrorpageService) { }

  canActivate(activatedRouteSnapshot: ActivatedRouteSnapshot): boolean {
    if (this.authGuard.canActivate()) {
      if (this.auth.getRole() === activatedRouteSnapshot.data.role) {
        return true;
      } else {
        this.errorpageservice.seterrormessage('Unauthorized Access Request');
        this.router.navigate(['errorpage']);
        return false;
      }
    }
    else {
      return false;
    }
  }
}
