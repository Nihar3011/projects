import { RouterModule } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule, DatePipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { InputSwitchModule } from 'primeng/inputswitch';
import { DragulaModule, DragulaService } from 'ng2-dragula';

//primeng imports
import {
  InputTextareaModule, TableModule, RatingModule, PaginatorModule, DropdownModule, MultiSelectModule
  , ListboxModule, CalendarModule, InputTextModule, ToastModule, RadioButtonModule
  , CheckboxModule, MessageService, MessagesModule, TabViewModule, TooltipModule, DragDropModule
} from './index-of-primeng-components';
//shared components imports
import {
  ErrorpageComponent, TemplateCreateComponent, GetRadioComponent,
  GetTextComponent,
  TemplatePreviewComponent, GetCheckboxComponent, GetRatingComponent
} from './components/index-of-shared-components';
import { SharedRoutingModule } from './shared-routing.module';
import { BaseModule } from './../base/base.module';
import { ModalModule } from 'ngx-bootstrap';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { ToastMessageComponent } from './components/toast-message/toast-message.component';
import { SessionexpirepageComponent } from './components/sessionexpirepage/sessionexpirepage.component';
import { ResponseComponent } from './components/response/response.component';
import { CardModule } from 'primeng/card';
import { CommentComponent } from './components/comment/comment.component';
import { ReviewResponseComponent } from './components/response/review-response/review-response.component';
import { DynamicFormBuilderModule } from './components/dynamic-form-builder/dynamic-form-builder.module'
import { UiSwitchModule } from 'ngx-toggle-switch';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { Ng5SliderModule } from 'ng5-slider';
import { FilterComponent } from './components/filter/filter.component';
import { AddChartComponent } from './components/add-chart/add-chart.component';
import { ViewChartComponent } from './components/view-chart/view-chart.component';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
  declarations: [
    ErrorpageComponent,
    TemplateCreateComponent,
    GetRadioComponent,
    GetTextComponent,
    TemplatePreviewComponent,
    ToastMessageComponent,
    GetCheckboxComponent,
    GetRatingComponent,
    SessionexpirepageComponent,
    ResponseComponent,
    CommentComponent,
    ReviewResponseComponent,
    SessionexpirepageComponent,
    FilterComponent,
    AddChartComponent,
    ViewChartComponent
  ],
  imports: [
    TableModule,
    CommonModule,
    ReactiveFormsModule,
    ModalModule.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    PaginatorModule,
    MessagesModule,
    DropdownModule,
    BrowserAnimationsModule,
    CalendarModule,
    InputTextModule,
    ToastModule,
    SharedRoutingModule,
    InputTextareaModule,
    RadioButtonModule,
    CheckboxModule,
    MultiSelectModule,
    RatingModule,
    BaseModule,
    BrowserModule,
    CardModule,
    MessagesModule,
    DragDropModule,
    DynamicFormBuilderModule,
    TabViewModule,
    TooltipModule,
    UiSwitchModule,
    InputSwitchModule,
    DragulaModule,
    BsDatepickerModule.forRoot(),
    Ng5SliderModule,
    NgxPaginationModule
  ],
  exports: [
    PaginatorModule,
    AngularFontAwesomeModule,
    BrowserAnimationsModule,
    ListboxModule,
    TableModule,
    DropdownModule,
    ListboxModule,
    CalendarModule,
    MessagesModule,
    InputTextModule,
    ToastModule,
    InputTextareaModule,
    MultiSelectModule,
    RatingModule,
    ErrorpageComponent,
    MessagesModule,
    DynamicFormBuilderModule,
    TabViewModule,
    TooltipModule,
    DragulaModule,
    DragDropModule,
    Ng5SliderModule,
    FilterComponent,
    AddChartComponent,
    ViewChartComponent,
    NgxPaginationModule
  ],
  providers: [DatePipe, MessageService, DragulaService],
  bootstrap: []
})
export class SharedModule { }

