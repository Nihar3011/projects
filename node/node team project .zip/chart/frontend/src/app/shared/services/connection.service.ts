import { Injectable } from '@angular/core';
import { HttpClient, HttpBackend } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from './../../../environments/enviroment.dev';
import { NgxSpinnerService } from 'ngx-spinner';

@Injectable({
  providedIn: 'root'
})
export class ConnectionService {
  private url: string = `${environment.backendEndpoint}/login`;
  private http: HttpClient;

  constructor( private handler: HttpBackend, private spinner:NgxSpinnerService) { 
    this.http = new HttpClient(handler);
  }

  getUser(tmail: string): Observable<any> {
    this.spinner.show();
    return this.http.get<any>(`${this.url}/${tmail}`);
  }
}