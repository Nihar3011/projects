export class userclass {
    user_id: number;
    full_name: string;
    role: string;
    active_status: boolean;
    designation: string;
}

