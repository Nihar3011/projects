import { Injectable } from '@angular/core';
import { environment } from 'src/environments/enviroment.dev';
import { HttpClient } from '@angular/common/http';
import { NgxSpinnerService } from 'ngx-spinner';
import { Observable, BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ChartsService {

  private url = `${environment.backendEndpoint}/chart`;
  private submitted = true;
  public submittedSubject = new BehaviorSubject<boolean>(this.submitted);

  setSubmittedFlag(value: boolean) {
    this.submittedSubject.next(value);
  }

  constructor(private http: HttpClient, private spinner: NgxSpinnerService) { }

  saveChart(data): Observable<any[]> {
    return this.http.post<any[]>(`${this.url}/add-chart`, data);
  }

  getChartsList(userId): Observable<any[]> {
    return this.http.get<any[]>(`${this.url}/get-chart`);
  }

  generateChartData(chartType, analysisData, selectedCategory) {
    let seriesData = {};
    let category = [];
    let categoryCode: string;
    switch (selectedCategory) {
      case 'template':
        length = analysisData.templateList.length;
        category = analysisData.templateList;
        categoryCode = "templateName"
        break;
      case 'session':
        length = analysisData.sessionList.length;
        category = analysisData.sessionList;
        categoryCode = "sessionName"

        break;
      case 'designation':
        length = analysisData.designationList.length;
        category = analysisData.designationList;
        categoryCode = "designation"
        break;
      case 'time':
        length = analysisData.monthYearList.length;
        category = analysisData.monthYearList;
        categoryCode = "month"
        break;
    }

    let userName = '';
    analysisData.returnResponse.forEach(rowData => {
      if (rowData.score !== 0) {
        userName = rowData.username;
        if (seriesData.hasOwnProperty(userName)) {
          seriesData[userName].data[category.indexOf(rowData[categoryCode])] = parseFloat(rowData.score);
        } else {
          seriesData[userName] = { name: userName, type: chartType, data: new Array(length).fill(null) };
          seriesData[userName].data[category.indexOf(rowData[categoryCode])] = parseFloat(rowData.score);
        }
      }
    });
    seriesData = Object.values(seriesData);
    return { 'category': category, 'seriesData': seriesData };
  }

  getChartsForTable(pageIndex: number, pageSize: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.url}/get-chart-list?pageIndex=${pageIndex}&pageSize=${pageSize}`);
  }
  deleteChart(id: number, userId: number): Observable<any> {
    return this.http.delete<any>(`${this.url}/delete-chart?id=${id}&userId=${userId}`);
  }
  editChart(chartData): Observable<any> {
    return this.http.put<any>(`${this.url}/update-chart`, chartData);
  }

  storeReorderCharts(chartData){
    return this.http.put<any>(`${this.url}/reorder-chart`, chartData);
  }

}
