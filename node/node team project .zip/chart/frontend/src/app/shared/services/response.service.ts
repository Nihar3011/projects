import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from './../../../environments/enviroment.dev';
import { NgxSpinnerService } from 'ngx-spinner';

@Injectable({
  providedIn: 'root'
})
export class ResponseService {

  private url = `${environment.backendEndpoint}/review`;

  constructor(private http: HttpClient, private spinner: NgxSpinnerService) { }

  getRecords(mappingId: number): Observable<any> {
    this.spinner.show();
    return this.http.get<any>(`${this.url}/review-data/${mappingId}`);
  }

  getResponse(mappingId: number, userId: number): Observable<any> {
    this.spinner.show();
    return this.http.get<any>(`${this.url}/response-data?id=${mappingId}&userId=${userId}`);
  }

  getComments(mappingId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.url}/comments-list/${mappingId}`);
  }

  sendComment(data: any): Observable<any> {
    this.spinner.show();
    return this.http.post<any>(`${this.url}/add-comment`, data);
  }

  updateComment(data: any): Observable<any> {
    this.spinner.show();
    return this.http.put<any>(`${this.url}/update-comment`, { "commentId": data.commentId, "visibility": !data.visibility });
  }

  publishreview(mappingId: number, userId: number): Observable<any> {
    this.spinner.show();
    return this.http.put<any>(`${this.url}/publish-review`, { "id": mappingId, "userId": userId });
  }

  reEvaluationRequest(data: any): Observable<any> {
    this.spinner.show();
    return this.http.put<any>(`${this.url}/reevaluation`, { "id": data.mappingId, "userId": data.userId, "message": data.message });
  }

  reEvaluationApproval(data: any): Observable<any> {
    this.spinner.show();
    return this.http.put<any>(`${this.url}/reevaluation-conformation`, { "mappingId": data.mappingId, "userId": data.userId, "commentId": data.commentId, "approval": data.response });
  }
}
