import { Injectable } from '@angular/core';
import { MessageService } from 'primeng/api';

@Injectable({
    providedIn: 'root'
})
export class ToasterService {
    public summaryValue;
    public detailValue;

    constructor(private messageService: MessageService) { }
    showSuccess(summaryValue, detailValue) {
        this.messageService.add({ severity: 'success', summary: summaryValue, detail: detailValue });
    }

    showInfo(summaryValue, detailValue) {
        this.messageService.add({ severity: 'info', summary: summaryValue, detail: detailValue });
    }

    showWarn(summaryValue, detailValue) {
        this.messageService.add({ severity: 'warn', summary: summaryValue, detail: detailValue });
    }

    showError(summaryValue, detailValue) {
        this.messageService.add({ severity: 'error', summary: summaryValue, detail: detailValue });
    }

}
