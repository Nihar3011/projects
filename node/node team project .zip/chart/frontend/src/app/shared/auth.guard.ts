import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import { AuthorizationService } from './services/authorization.service';
import { EncryptionService } from 'src/app/shared/services/encryption.service';
import { constant } from '../../app/app.const';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(private auth: AuthorizationService, private encryptionService: EncryptionService) { }

  canActivate(): boolean {
    if (this.auth.getToken()) {
      return true;
    } else {
      let origin = window.location.href.split('review/');
      sessionStorage.setItem('origin', this.encryptionService.set(constant.ENCRYPTIONKEY, origin[1]));
      window.location.href = '';
      return false;
    }
  }
}
