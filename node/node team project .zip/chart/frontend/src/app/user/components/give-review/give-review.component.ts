import { TemplateService } from 'src/app/shared/services/template.service';
import { Component, OnInit, Output } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { EncryptionService } from '../../../shared/services/encryption.service';
import { constant } from '../../../app.const';
import { ReviewsService } from '../../services/reviews.service';
import { ToasterService } from '../../../shared/services/toaster.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { LivenotificationService } from 'src/app/base/services/livenotification.service';

@Component({
  selector: 'app-give-review',
  templateUrl: './give-review.component.html',
  styleUrls: ['./give-review.component.scss']
})
export class GiveReviewComponent implements OnInit {

  public userId;
  public role;
  public revieweeData: any;
  public form: FormGroup;
  public data: any;
  public mappingId;
  public canCall = false;
  public fields: any[] = [];
  public templateData: any;
  public revieweeScore = 0;
  public responceObjectArray = [];
  constructor(public route: ActivatedRoute,
    private router: Router,
    public toast: ToasterService,
    private encryptionService: EncryptionService,
    public reviewservice: ReviewsService,
    private spinner: NgxSpinnerService,
    private liveNotification: LivenotificationService,
    private templateService: TemplateService) {
  }
  ngOnInit() {
    let userData = JSON.parse(localStorage.getItem('userdata'));
    this.role = this.encryptionService.get(constant.ENCRYPTIONKEY, userData.role);
    if (this.role === 'ROLE_SADMIN') {
      this.role = "/givereview"
    }
    else {
      this.role = "/dashboard"
    }
    this.userId = Number(this.encryptionService.get(constant.ENCRYPTIONKEY, userData.user_id));
    this.mappingId = Number(this.route.snapshot.paramMap.get('mappingId'));
    this.reviewservice.getRecords(this.mappingId).subscribe(data => {
      this.revieweeData = data;
      if (this.revieweeData.reviewerId !== this.userId) {
        this.toast.showError('Access Denied', 'you can not review this candidate');
        this.router.navigate([this.role]);
      }
      else {
        if (this.revieweeData.status !== 1) {
          this.toast.showWarn('Warning', 'review has been submitted');
          this.router.navigate([this.role]);
        }
      }
      this.templateService.getTemplate(this.revieweeData.templateId).subscribe(data => {
        this.templateData = data;
        this.canCall = true;
      });

      this.spinner.hide();
    },
      error => {
        this.spinner.hide();
        if (error.error.code === 'NORECORD') {
          this.toast.showError('Error', 'Record for this mapping does not exist')
          this.router.navigate([this.role])
        }
        if (error.error.code === 'JOIFALSE') {
          this.toast.showError('Error', 'Please enter valid mapping id')
          this.router.navigate([this.role])
        } 
        else {
          this.toast.showError('Error', 'Record not found !')
          this.router.navigate([this.role])
        }
      })
  }

  @Output() onSubmit(response) {
    this.reviewservice.submitReview(response).subscribe(data => {
      this.toast.showSuccess(
        'Success',
        'review submitted successfully'
      );
      this.router.navigate([this.role]);
      this.spinner.hide();
      this.liveNotification.sendMessage();
    }, error => {      
      this.spinner.hide();
      this.toast.showError('Error', 'review could not be submitted');
    });
  }
}
