import { Injectable } from '@angular/core';
import { environment } from '../../../environments/enviroment.dev';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Injectable({
  providedIn: 'root'
})
export class SessionReportService {

  private _url: string = `${environment.backendEndpoint}/session`;

  constructor(private http: HttpClient, private router: Router,
    public toast: ToasterService, private spinner: NgxSpinnerService) { }

  //to get report data:
  getSessionReportData(sessionId: number, pagesize: number, pageindex: number, search: string, sortAttribute: string, order: any, employee: any, designation: any): Observable<any[]> {
    this.spinner.show();
    let sessionData = {
      "id":sessionId,
      "pageSize": pagesize,
      "pageIndex": pageindex,
      "sort": sortAttribute,
      "order": order,
      "search": search,
      "employee": employee,
      "designation": designation
    }
    //change the address as per back-end API
    return this.http.post<any[]>(`${this._url}/mapping-report`, sessionData);
  }
}

