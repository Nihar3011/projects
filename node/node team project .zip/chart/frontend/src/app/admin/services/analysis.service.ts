import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/enviroment.dev';
import { Observable } from 'rxjs';
import { NgxSpinnerService } from 'ngx-spinner';

@Injectable({
  providedIn: 'root'
})
export class AnalysisService {

  private _url: string = environment.backendEndpoint;

  constructor(private http: HttpClient, private spinner: NgxSpinnerService) { }

  getAnalysisData(data): Observable<any[]> {    
    this.spinner.show();
    return this.http.post<any[]>(`${this._url}/analysis/analysisDashboard`, data);
  }
  
  getDesignationNames(): Observable<any[]> {
    this.spinner.show();
    return this.http.get<any[]>(`${this._url}/designation/designation-names`);
  }

  getUserByDesignation(designationId: number[]): Observable<any[]> {
    this.spinner.show();
    return this.http.get<any[]>(`${this._url}/designation/users?designationId=${designationId}`);
  }

  getUserDesignation(userId: number): Observable<any[]> {
    this.spinner.show();
    return this.http.get<any[]>(`${this._url}/user/designation?userId=${userId}`);
  }

  getReviewers(userId: number): Observable<any[]> {
    this.spinner.show();    
    return this.http.get<any[]>(`${this._url}/user/reviewer-of-reviewee/${userId}`);
  }
}
