import { TestBed } from '@angular/core/testing';

import { SessionReportService } from './session-report.service';

describe('SessionReportService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SessionReportService = TestBed.get(SessionReportService);
    expect(service).toBeTruthy();
  });
});
