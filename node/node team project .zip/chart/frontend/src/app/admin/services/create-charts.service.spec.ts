import { TestBed } from '@angular/core/testing';

import { CreateChartsService } from './create-charts.service';

describe('CreateChartsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CreateChartsService = TestBed.get(CreateChartsService);
    expect(service).toBeTruthy();
  });
});
