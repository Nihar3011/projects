import { Injectable, ElementRef } from '@angular/core';
import * as Highcharts from 'highcharts';

@Injectable({
  providedIn: 'root'
})
export class CreateChartsService {
  defaultOptions: Highcharts.Options;

  constructor() {
      this.defaultOptions = {
          chart : {
            zoomType: 'x'
          },
          yAxis: {
              showFirstLabel: false,
              labels: {
                  align: 'right',
                  x: 0,
                  y: 16,
                  format: '{value:.,0f}'
                }
            },
            scrollbar: {
                enabled: true
            },        
            xAxis: {
                crosshair: true
          },
          legend: {
                align: 'left',
                verticalAlign: 'top',
                maxHeight: 60
          },
          tooltip: {
              headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
              pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                  '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
              footerFormat: '</table>',
              shared: true,
              useHTML: true,
              crosshairs: true
          },
          responsive: {
            rules: [{
                condition: {
                    maxWidth: 460,
                    maxHeight:260
                },
                chartOptions: {
                    legend: {
                        align: 'center',
                        verticalAlign: 'bottom',
                        layout: 'horizontal'
                    },
                    yAxis: {
                        labels: {
                            align: 'left',
                            x: 0,
                            y: -5
                        },
                        title: {
                            text: null
                        }
                    },
                    subtitle: {
                        text: null
                    },
                    credits: {
                        enabled: false
                    }
                }
            }]
        }
      };
  }

  createChart(elementReference: ElementRef, chartType: string) {
      const chartObject = new Highcharts.Chart(elementReference.nativeElement, { chart: { type: chartType } });
      chartObject.update(this.defaultOptions);

      if (chartType === 'line') {
          chartObject.update({
              plotOptions: {
                  series: {
                      cursor: 'pointer',
                      marker: {
                          lineWidth: 1,
                          height: 5,
                          width: 5
                      }
                  }
              }
          });
      } else if (chartType === 'column') {
          chartObject.update({
              plotOptions: {
                  column: {
                      pointPadding: 0.2,
                      borderWidth: 0
                  }
              }
          });
      }

      return chartObject;
  }

  setChartTitles(chartObject: Highcharts.Chart, chartTitle: string, chartSubTitle: string) {
      chartObject.update({ title: { text: chartTitle }, subtitle: { text: chartSubTitle } });
  }

  setYAxisTitles(chartObject: Highcharts.Chart, axisTitle: string) {
      chartObject.yAxis.forEach(yAxisLabel => {
          yAxisLabel.update({ title: { text: axisTitle } });
      });
  }

  setXAxisTitles(chartObject: Highcharts.Chart, axisTitle: string) {
      chartObject.xAxis.forEach(xAxisLabel => {
          xAxisLabel.update({ title: { text: axisTitle } });
      });
  }

  updateChartOptions(chartObject: Highcharts.Chart, options: Highcharts.Options) {
      chartObject.update(options, true, true);
  }

  updateSeries(chartObject: Highcharts.Chart, seriesData: any) {
      chartObject.update({ series: seriesData }, true, true);
  }

  addXAxisCategories(chartObject: Highcharts.Chart, categoryValues: string[]) {
      chartObject.update({
          xAxis: {
              categories: categoryValues
          }
      });
  }
}
