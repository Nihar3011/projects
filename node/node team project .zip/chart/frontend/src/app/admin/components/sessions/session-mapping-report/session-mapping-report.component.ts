import { FormBuilder, FormGroup } from '@angular/forms';
import { constant } from './../../../../app.const';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription, pipe } from 'rxjs';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { LazyLoadEvent } from 'primeng/api';
import { debounceTime } from 'rxjs/operators';
import { NgxSpinnerService } from 'ngx-spinner';
import { SessionReportService } from 'src/app/admin/services/session-report.service';
import { AnalysisService } from '../../../services/analysis.service';
import { SessionMappingService } from '../../../services/session-mapping.service';

interface dropdownData {
  value: number;
  label: string;
}

@Component({
  selector: 'app-session-mapping-report',
  templateUrl: './session-mapping-report.component.html',
  styleUrls: ['./session-mapping-report.component.scss']
})
export class SessionMappingReportComponent implements OnInit {

  first = 0;
  rowPerPage = constant.ROWS[0].value;                                    // maximum number of rows to be displayed every time
  firstTimeTotalRecords: number = 0;
  sessionId = -1;                            // to store the session data
  reportDataSubscription: Subscription;  // dataSubscription for session data
  pageIndex = 0;
  totalRecords: number;                         // for paginator to display the page links
  mappingReportForm: FormGroup;
  public rows = constant.ROWS;
  reportData: any = [];
  order = -1;
  sortAttribute = 'mappingCount';
  page: boolean;
  sessionName = 'Sample';

  users: dropdownData[];
  designations: dropdownData[];
  
  columns = [
    { field: 'employeeName', header: 'Name' },
    { field: 'designation', header: 'Designation' },
    { field: 'mappingCount', header: 'Mapping Count', order: -1 }
  ];

  constructor(private sessionReportService: SessionReportService,
    private router: Router, public toast: ToasterService,
    private formBuilder: FormBuilder,
    private spinner: NgxSpinnerService,
    private activatedRoute: ActivatedRoute,
    private sessionMappingService: SessionMappingService,
    private analysisService: AnalysisService) {

    // form group
    
    this.mappingReportForm = this.formBuilder.group({
      recordsPerPage: constant.ROWS[0].value,
      selectedUser: [[]],
      selectedDesignation: [[]],
      searchString: [''],
    });
  }

  ngOnInit() {
    this.sessionId = Number(this.activatedRoute.snapshot.paramMap.get('sessionId'));
    if (!this.sessionId) {
      this.router.navigate(['list-sessions']);
    }
    this.onFormFieldValueChange();
    this.loadUsers();
    this.loadDesignation();
  }
  get searchStringValue() {
    return this.mappingReportForm.get('searchString').value;
  }

  get getRowValue() {
    return parseInt(this.mappingReportForm.get('recordsPerPage').value.value);
  }

  get getEmployee() {
    return this.mappingReportForm.get('selectedUser').value;
  }
  
  get getDesignation() {
    return this.mappingReportForm.get('selectedDesignation').value;
  }

  onFormFieldValueChange() {
    this.mappingReportForm.get('recordsPerPage').valueChanges.subscribe(val => {
      this.rowPerPage = val.value;
      this.paginate(0);
    });

    this.mappingReportForm.get('selectedUser').valueChanges.subscribe(val => {
      this.paginate(0);
    });

    this.mappingReportForm.get('selectedDesignation').valueChanges.subscribe(val => {
      this.paginate(0);
    });

    this.mappingReportForm.get('searchString').valueChanges.pipe(debounceTime(constant.DEBOUNCETIME),
    ).
      subscribe(val => {
        if (this.mappingReportForm.get('searchString').valid) {
          this.getSearchString();
        }
      });
  }


  //retrive rows according to the page number and offset  
  loadReportData(pagesize: number, pageindex: number, search: string, sort_attribute: string, order: any) {
    this.reportDataSubscription = this.sessionReportService.getSessionReportData(this.sessionId, pagesize, pageindex, search, sort_attribute, order, this.getEmployee, this.getDesignation).subscribe(
      data => {
        this.firstTimeTotalRecords = this.firstTimeTotalRecords === 0 ? data[0] : this.firstTimeTotalRecords;
        this.totalRecords = data[0];
        this.sessionName = data[1];
        this.reportData = data[2];
        this.spinner.hide();
      },
      error => {
        this.spinner.hide();
        let errorMessage;
        if (error.error.code === 'SEARCHFALSE') {
          errorMessage = error.error.error;
        }
        else {
          errorMessage = 'Error in records!'
        }
        this.toast.showError('Error', errorMessage);
        setTimeout(() => {
          window.close();
        },2000)
      });
  }

  templateCSV(templates) {
    if (templates.length == 0 || templates[0] == "") {
      return "-";
    }
    let templateNames = '';
    for (const template of templates) {
      templateNames = templateNames + ', ' + template;
    }
    templateNames = templateNames.substr(1);
    return templateNames;
  }

  tooltipText(templateNames) {
    if (templateNames.length > 50) {
      templateNames = templateNames.substr(0, 100);
      return templateNames.concat(' ...');
    } else {
      return templateNames;
    }
  }

  // get search string value and pass it to the service
  getSearchString() {
    this.paginate(0);
  }

  // called every time when admin navigates to new page
  paginate(event) {
    this.pageIndex = event;
    this.loadReportData(this.rowPerPage,
      this.pageIndex,
      this.searchStringValue,
      this.sortAttribute,
      this.order);
  }

  //lazy loading method
  customSort(event: LazyLoadEvent) {
    this.order = event.sortOrder ? event.sortOrder : this.order;
    this.sortAttribute = event.sortField ? event.sortField : this.sortAttribute;
    this.loadReportData(this.rowPerPage,
      this.pageIndex + constant.STARTINGINDEX,
      this.searchStringValue,
      this.sortAttribute,
      this.order);
  }
  
  onError() {
    this.spinner.hide();
    this.toast.showError('Error', 'Error in Fetching records');
  }

  loadDesignation() {
    this.analysisService.getDesignationNames().subscribe(
      data => {
        this.designations = data;
        this.spinner.hide();
      }, error => {
        this.onError();
        this.spinner.hide();
      })
  }

  loadUsers() {
    this.users = [];
    this.sessionMappingService.getUsers().subscribe(data => {
      let userData = data['member'];
      userData.map((userName) => {
        this.users.push({ value: userName.user_id, label: userName.fullname });
      })
    }, error => {
      this.onError();
    });
  }
}
