import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SessionMappingReportComponent } from './session-mapping-report.component';

describe('SessionMappingReportComponent', () => {
  let component: SessionMappingReportComponent;
  let fixture: ComponentFixture<SessionMappingReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SessionMappingReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SessionMappingReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
