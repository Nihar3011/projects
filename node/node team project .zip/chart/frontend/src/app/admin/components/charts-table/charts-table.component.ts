import { Component, OnInit, TemplateRef } from '@angular/core';
import { constant } from 'src/app/app.const';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { Router } from '@angular/router';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { EncryptionService } from 'src/app/shared/services/encryption.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Subscription } from 'rxjs';
import { ChartsService } from 'src/app/shared/services/charts.service';
import { AnalysisService } from '../../services/analysis.service';
@Component({
  selector: 'app-charts-table',
  templateUrl: './charts-table.component.html',
  styleUrls: ['./charts-table.component.scss']
})
export class ChartsTableComponent implements OnInit {


  first = 0;
  rowPerPageForChart: number;                                    // maximum number of rows to be displayed every time
  firstTimeTotalRecords: number = 0;
  charts: any = [];                              // to store the session data
  totalChartsDatadataSubscription: Subscription;  // dataSubscription for session data
  pageIndexForChart = 0;
  totalRecordsForChart: number;                         // for paginator to display the page links
  chartTableForm: FormGroup;
  public rows: any;
  order: any = -1;
  sortAttribute: string;
  page: boolean;
  chartId: number;
  cols = [
    { field: 'chartTitle', header: 'Name' },
    { field: 'chartType', header: 'Chart Type' },
    { field: 'xAxisField', header: 'X-Axis' },
    { field: 'yAxisField', header: 'Y-Axis' },
    { field: 'viewToggle', header: 'View In Dashboard' },
    { field: 'chartMaker', header: 'Charts Maker' },
    { field: 'creationTime', header: 'Created At', order: -1 }
  ];
  userId: number;
  modalRefForAddChart: BsModalRef;
  modalRefForPreveiw: BsModalRef;
  modalRefForDeleteChart: BsModalRef;
  deleteChartName: string;
  chartMetaData: any;
  finalSeries: any;
  category: any;
  sortField: any;
  formData: any;
  editFilterData: any;
  constructor(
    private router: Router,
    public toast: ToasterService,
    private encryptionService: EncryptionService,
    private formBuilder: FormBuilder,
    private spinner: NgxSpinnerService,
    private modalService: BsModalService,
    private chartsService: ChartsService,
    private analysisService: AnalysisService,
  ) {
    this.first = 0;
    this.rowPerPageForChart = constant.ROWS[0].value;
    let userData = JSON.parse(localStorage.getItem('userdata'));
    this.userId = Number(this.encryptionService.get(constant.ENCRYPTIONKEY, userData.user_id));

    // form group
    this.chartTableForm = this.formBuilder.group({
      recordsPerPage: constant.ROWS[0]
    });
    this.rows = constant.ROWS;
    this.sortField = constant.SORTFIELDFORANALYSIS;

  }

  ngOnInit() {
    this.onFormFieldValueChange();
    this.loadChart(this.getRowValue, 1);
  }

  get getRowValue() {
    return parseInt(this.chartTableForm.get('recordsPerPage').value.value);
  }


  onFormFieldValueChange() {
    this.chartTableForm.get('recordsPerPage').valueChanges.subscribe(val => {
      this.rowPerPageForChart = val.value;
      this.paginateForChart(1);
    });
  }

  //retrive rows according to the page number and offset  
  loadChart(pageSize: number, pageIndex: number) {
    this.chartsService.getChartsForTable(pageIndex, pageSize).subscribe(data => {
      this.firstTimeTotalRecords = this.firstTimeTotalRecords === 0 ? data[0] : this.firstTimeTotalRecords;
      this.totalRecordsForChart = data[0];
      this.charts = data[1];
    });
  }


  // called every time when admin navigates to new page
  paginateForChart(event) {
    this.pageIndexForChart = event;
    this.loadChart(this.getRowValue,
      this.pageIndexForChart
    );
  }

  openDeleteChartModal(event, chartData: any, template: TemplateRef<any>) {
    this.chartId = chartData.chartId;
    this.deleteChartName = chartData.chartTitle
    this.modalRefForDeleteChart = this.modalService.show(template);
  }

  deleteChart() {
    this.chartsService.deleteChart(this.chartId, this.userId).subscribe(data => {
      this.toast.showSuccess('Success', 'Chart deleted successfully');
      this.paginateForChart(1);
    }, error => {
      this.toast.showError('Error', 'Error in delete');
    });
  }

  async editChart(event, data, template) {
    this.formData = data;
    this.editFilterData = data.filterData[0];
    this.modalRefForAddChart = await this.modalService.show(
      template,
      Object.assign({}, { class: 'gray modal-lg' })
    );
  }
  async previewChartClick(event, rowData, template: TemplateRef<any>) {
    let sortFieldForChart = await this.sortField.indexOf(rowData.xAxisField);
    sortFieldForChart = (sortFieldForChart === 4) ? 3 : sortFieldForChart;
    this.analysisService.getAnalysisData({ "data": rowData.filterData[0], "sortField": sortFieldForChart }).subscribe(
      async data => {
        this.spinner.hide();
        let chartData = await this.chartsService.generateChartData(rowData.chartType, data, rowData.xAxisField);
        this.finalSeries = chartData.seriesData;
        this.category = chartData.category;
        this.chartMetaData = await {
          "selectedChartType": rowData.chartType,
          "chartTitle": rowData.chartTitle,
          "xAxisTitle": rowData.xAxisTitle
        }
        this.modalRefForPreveiw = await this.modalService.show(
          template,
          Object.assign({}, { class: 'gray modal-lg' })
        );
      },
      error => {
        this.spinner.hide();
        this.toast.showError('Error', "Error in analysis data");
      });
  }

  // unsubscribe the observables
  ngOnDestroy() {
    if (this.totalChartsDatadataSubscription)
      this.totalChartsDatadataSubscription.unsubscribe();
  }

  openModalWithClassForAddChart(template: TemplateRef<any>) {
    this.modalRefForAddChart = this.modalService.show(
      template,
      Object.assign({}, { class: 'gray modal-lg' })
    );
  }

  applyReorder() {
    let chartData = {
      "rowPerPage": this.rowPerPageForChart,
      "charts": this.charts,
      "pageIndex": this.pageIndexForChart
    }
    this.chartsService.storeReorderCharts(chartData).subscribe(result => {
      this.toast.showSuccess('Success', 'Chart deleted successfully');
    }, error => {
      this.toast.showError('Error', 'Error in reorder');
    });
  }

  hide() {
    this.modalRefForAddChart.hide();
    this.editFilterData = null;
    this.formData = null;
  }


}
