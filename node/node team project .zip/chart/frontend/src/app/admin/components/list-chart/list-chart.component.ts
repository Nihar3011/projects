import { Component, OnInit } from '@angular/core';
import { ChartsService } from 'src/app/shared/services/charts.service';
import { constant } from 'src/app/app.const';
import { EncryptionService } from 'src/app/shared/services/encryption.service';
import { AnalysisService } from '../../services/analysis.service';
import { async } from '@angular/core/testing';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToasterService } from 'src/app/shared/services/toaster.service';
@Component({
  selector: 'app-list-chart',
  templateUrl: './list-chart.component.html',
  styleUrls: ['./list-chart.component.scss']
})
export class ListChartComponent implements OnInit {
  userData: any;
  chartData = [];
  finalSeries = [];
  category = [];
  chartMetaData = [];
  sortField = [];
  canRender = [];
  constructor(private chartsService: ChartsService,
    private encryptedService: EncryptionService,
    private analysisService: AnalysisService,
    public toster: ToasterService,
    private spinner: NgxSpinnerService
  ) {
    this.sortField = constant.SORTFIELDFORANALYSIS;
  }

  ngOnInit() {
    this.userData = JSON.parse(localStorage.getItem('userdata'));
    this.userData.user_id = this.encryptedService.get(
      constant.ENCRYPTIONKEY,
      this.userData.user_id);
    this.chartsService.getChartsList(this.userData.user_id).subscribe(data => {
      data.map(async (chart, index) => {
        this.spinner.hide();
        if (chart.viewToggle) {
          let sortFieldForChart = await this.sortField.indexOf(chart.xAxisField);
          sortFieldForChart = (sortFieldForChart === 4) ? 3 : sortFieldForChart;
          let analysisData;
          this.analysisService.getAnalysisData({ "data": chart.filterData[0], "sortField": sortFieldForChart }).subscribe(
            async data => {
              this.spinner.hide();
              analysisData = data;
              this.chartData[index] = await this.chartsService.generateChartData(chart.chartType, analysisData, chart.xAxisField);
              this.finalSeries[index] = await this.chartData[index].seriesData;
              this.category[index] = await this.chartData[index].category;
              this.chartMetaData[index] = await {
                chartTitle: chart.chartTitle,
                selectedChartType: chart.chartType,
                selectedXAxisVariable: { value: chart.xAxisField },
                xAxisTitle: chart.xAxisTitle
              }
              this.canRender[index] = true;
            },
            error => {
              this.spinner.hide();
              this.toster.showError('Error', "Error in analysis data");
            });
        }else{
          this.canRender[index] = false;
        }
      });
    });
  }
}