import { Component, OnInit, ViewChild, ElementRef, Input } from '@angular/core';
import * as Highcharts from 'highcharts';
import HighchartsMore from 'highcharts/highcharts-more';
import HighchartsSolidGauge from 'highcharts/modules/solid-gauge';

HighchartsMore(Highcharts);
HighchartsSolidGauge(Highcharts);

@Component({
  selector: 'app-chart',
  templateUrl: './chart.component.html',
  styleUrls: ['./chart.component.scss']
})
export class ChartComponent implements OnInit {

  @Input('score') score;
  @ViewChild('charts') chartElem: ElementRef;
  chart: Highcharts.Chart;

  constructor() { }

  ngOnInit() {
    this.loadChart();
  }

  loadChart() {
    let gaugeOptions = {
      chart: {
        type: 'solidgauge',
        height: '70',
        width: '65'
      },
      title: 'null',
      pane: {
        center: ['50%', '50%'],
        size: '45px',
        startAngle: -90,
        endAngle: 90,
        background: {
          backgroundColor: '#EEE',
          innerRadius: '60%',
          outerRadius: '100%',
          shape: 'arc'
        }
      },
      tooltip: {
        enabled: false
      },
      yAxis: {
        stops: [
          [0.1, '#DF5353'],
          [0.5, '#DDDF0D'],
          [0.9, '#55BF3B']
        ],
        minorTickInterval: null
      },
      plotOptions: {
        solidgauge: {
          dataLabels: {
            borderWidth: 0,
            useHTML: true
          }
        }
      }
    };

    this.chart = Highcharts.chart(this.chartElem.nativeElement, Highcharts.merge(gaugeOptions, {
      yAxis: {
        min: 0,
        max: 100
      },
      credits: {
        enabled: false
      },
      title: 'charts',
      series: [{
        name: 'Speed',
        data: [Math.ceil(this.score)]
      }]
    }));
  }
}
