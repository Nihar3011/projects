import { Component, OnInit, Renderer2 } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-report-component',
  templateUrl: './report-component.component.html',
  styleUrls: ['./report-component.component.scss']
})
export class ReportComponentComponent implements OnInit {

  columns = [];
  analysisData = [];
  rowGroupMetadata: any;
  filterOpened: boolean = false;
  totalRecords: number;

  constructor(private spinner: NgxSpinnerService,
    private toast: ToasterService,
    private renderer: Renderer2,
    private router: Router) {
    this.columns = [
      { field: 'username', header: 'Name' },
      { field: 'averageScore', header: 'Average' },
      { field: 'designation', header: 'Designation' },
      { field: 'reviewer', header: 'Reviewer' },
      { field: 'sessionName', header: 'Session Name' },
      { field: 'templateName', header: 'Template' },
      { field: 'score', header: 'Score' },
    ];
  }

  ngOnInit() {
  }

  loadData(data) {
    this.analysisData = data.returnResponse;
    this.totalRecords = data.returnResponse.length;
    this.mergeData();
  }

  filterClose(data) {
    if(data) {
      this.openFilter();    
    }
  }

  openFilter() {
    this.filterOpened = !this.filterOpened;
    if (this.filterOpened === true) {
      this.renderer.addClass(document.body, 'overflow-filter');
    } else {
      this.renderer.removeClass(document.body, 'overflow-filter');
    }
  }

  viewResponse(mapping) {
    window.open(`${window.location.href.split('/report-analysis')[0]}/response/${mapping.stmId}`, "_blank");
  }

  onError() {
    this.spinner.hide();
    this.toast.showError('Error', 'Error in Fetching records');
  }

  onSort() {
    this.mergeData();
  }

  mergeData() {
    let averageScore;
    let scoreCount: number = 0;
    this.rowGroupMetadata = {};
    for (let i = 0; i < this.analysisData.length; i++) {
      let rowData = this.analysisData[i];
      let username = rowData.username;

      if (i == 0) {
        averageScore = rowData.score ? rowData.score : 0;
        averageScore = parseFloat(averageScore).toFixed(2);
        this.rowGroupMetadata[username] = { index: 0, size: 1, avgScore: averageScore };
      }
      else {
        let previousRowData = this.analysisData[i - 1];
        let previousRowGroup = previousRowData.username;
        if (username === previousRowGroup) {
          this.rowGroupMetadata[username].size++;
          scoreCount = rowData.score ? ++scoreCount : scoreCount;
          averageScore = rowData.score ? (parseFloat(rowData.score) + averageScore * (scoreCount - 1)) / scoreCount : averageScore;
          averageScore = parseFloat(averageScore).toFixed(2);
          this.rowGroupMetadata[username].avgScore = averageScore;
        }
        else {
          averageScore = rowData.score ? rowData.score : 0;
          averageScore = parseFloat(averageScore).toFixed(2);
          scoreCount = rowData.score ? 1 : 0;
          this.rowGroupMetadata[username] = { index: i, size: 1, avgScore: averageScore };
        }
      }
    }
  }
}