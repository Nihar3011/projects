import { SessionsService } from './services/sessions.service';
import { BaseModule } from './../base/base.module';
import { SharedModule } from './../shared/shared.module';
import { NgModule } from '@angular/core';
import { AdmindashboardComponent, ListSessionsComponent, SessionDetailsComponent, } from './components/index';
import { AdminRoutingModule } from './admin-routing.module';
import { DialogModule } from 'primeng/dialog';
import { ButtonModule } from 'primeng/button';
import { CommonModule } from '@angular/common';
import { SessionTemplateMappingComponent } from './components/sessions/session-template-mapping/session-template-mapping.component';
import { ListTemplatesComponent } from './components/list-templates/list-templates.component';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PaginatorModule } from 'primeng/paginator';
import { TableModule } from 'primeng/table';
import { TabViewModule } from 'primeng/tabview';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TooltipModule } from 'primeng/tooltip';
import { TemplateService } from './services/template.service';
import { MappingComponentComponent } from './components/sessions/mapping-component/mapping-component.component';
import { ReportComponentComponent } from './components/report-component/report-component.component';
import { ChartComponent } from './components/report-component/chart/chart.component';
import { SessionMappingReportComponent } from './components/sessions/session-mapping-report/session-mapping-report.component';
import { PopoverModule } from 'ngx-bootstrap';
import { ListChartComponent } from './components/list-chart/list-chart.component';
import { ChartsTableComponent } from './components/charts-table/charts-table.component';

@NgModule({
  declarations: [
    ListSessionsComponent,
    SessionDetailsComponent,
    AdmindashboardComponent,
    SessionTemplateMappingComponent,
    ListTemplatesComponent,
    MappingComponentComponent,
    ReportComponentComponent,
    ChartComponent,
    SessionMappingReportComponent,
    ListChartComponent,
    ChartsTableComponent,
  ],

  imports: [
    AdminRoutingModule,
    FormsModule,
    CommonModule,
    BrowserModule,
    SharedModule,
    CommonModule,
    DialogModule,
    ButtonModule,
    BrowserModule,
    BrowserAnimationsModule,
    PaginatorModule,
    TableModule,
    TabViewModule,
    ReactiveFormsModule,
    FormsModule,
    TooltipModule,
    BaseModule,
    ReactiveFormsModule,
    PopoverModule.forRoot()
  ],
  providers: [SessionsService, TemplateService],
  bootstrap: []
})
export class AdminModule { }
