import { ListSessionsComponent, SessionDetailsComponent, ChartsTableComponent,ListTemplatesComponent, AdmindashboardComponent, ReportComponentComponent } from './components/index';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SessionTemplateMappingComponent } from './components/sessions/session-template-mapping/session-template-mapping.component';
import { MappingComponentComponent } from './components/sessions/mapping-component/mapping-component.component';
import { RoleGuard } from '../shared/role.guard';

export const routes: Routes = [
  { path: '', component: AdmindashboardComponent },
  { path: 'list-sessions', component: ListSessionsComponent, data: { role: 'ROLE_SADMIN' }, canActivate: [RoleGuard] },
  { path: 'session-details', component: SessionDetailsComponent, data: { role: 'ROLE_SADMIN' }, canActivate: [RoleGuard] },
  { path: 'session-details/:sessionId', component: SessionDetailsComponent, data: { role: 'ROLE_SADMIN' }, canActivate: [RoleGuard] },
  { path: 'session-mapping/:sessionId', component: MappingComponentComponent, data: { role: 'ROLE_SADMIN' }, canActivate: [RoleGuard] },
  { path: 'session-mapping-details/:sessionId', component: SessionTemplateMappingComponent, data: { role: 'ROLE_SADMIN' }, canActivate: [RoleGuard] },
  { path: 'list-templates', component: ListTemplatesComponent, canActivate: [RoleGuard] },
  { path: 'report-analysis', component: ReportComponentComponent, data: { role: 'ROLE_SADMIN' }, canActivate: [RoleGuard] },
  { path: 'charts-table', component: ChartsTableComponent, data: { role: 'ROLE_SADMIN' }, canActivate: [RoleGuard] },
  { path: '**', redirectTo: '/errorpage' }
];
// taken from angular.io
// Only call RouterModule.forRoot in the root AppRoutingModule (or the AppModule if
// that's where you register top level application routes). In any other module, you
// must call the RouterModule.forChild method to register additional routes.

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [
    RouterModule
  ]
})
export class AdminRoutingModule { }
