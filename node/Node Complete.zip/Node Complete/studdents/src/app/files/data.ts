export class Student {
  id: number;
  rollno: number;
  name: string;
  name1: string;
  gender: string;
  mobile: number;
}
