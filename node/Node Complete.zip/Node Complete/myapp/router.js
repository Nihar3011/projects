var homeRouter = require('./routes/home.routing');
var arrayRouter = require('./routes/arrays.routing');
var crudRouter = require('./routes/crud.routing');
var lodash = require('./routes/lodash.routing');
var moment = require('./routes/moment.routing');
var data = require('./routes/crudDatabase.routing');
var sequelize = require('./routes/sequelize.routing');
const passport = require('passport');


app.post('/auth/login', (req, res, next) => {
    passport.authenticate('local', (err, user, info) => {
        if (err) {
            info = err;
        }
        if (info) {
            if (!info.message) {
                info.message = "No error message";
            }
            res.json({
                status: 'FAILED',
                msg: info.message
            })
            // return info;
        }

        req.logIn(user, (err) => {


            if (err) {
                console.error("passport: authenticate - login failed. Error: ");
                return res.json({
                    status: 'FAILED',
                    msg: 'Login Failed'
                });
            }
            console.log(" user logged in");
            req.session.save(() => {
                res.json({
                    status: 'OK',
                    msg: 'Login Successful'
                });
            });
        });
    })(req, res, next);
});

app.post('/auth/logout', async (req, res) => {
    console.log(req.user);
    // await sessions.logout(req, res);
    res.json({
        status: 200,
        msg: "Logout successful"
    });
});

app.get('/auth/login-status', (req, res) => {

    return res.json({
        auth_status: req.isAuthenticated()
    })
});

app.all('*', (request, response, next) => {
    if (request.isAuthenticated()) {
        next();
    } else {
        response.status(404).json({ message: 'Unauthorized request' });
    }
});

app.use('/', homeRouter);
app.use('/crud', crudRouter);
app.use('/array', arrayRouter);
app.use('/lodash', lodash);
app.use('/moment', moment);
app.use('/data', data);
app.use('/seq', sequelize);

app.use((req, res, next) => {
    res.status(200).json(res.locals.data);
});
app.use((error, req, res, next) => {
    res.status(400).json(error.code);
});