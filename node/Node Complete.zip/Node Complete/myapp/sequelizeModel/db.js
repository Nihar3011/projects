var Student=require('./Student')
var User=require('./User')

const Sequelize = require('sequelize');
const sequelize = new Sequelize('node', 'postgres', 'root', {
  host: 'localhost',
  dialect: 'postgres',
    pool: {
        max: 5,
        min: 0,
        acquire: 30000,
        idle: 10000
      }
});

const StudentModel = Student(sequelize, Sequelize);
const UserModel = User(sequelize, Sequelize);

sequelize.sync({ force: false })
  .then(() => {
    console.log(`Database & tables created!`)
  })

module.exports = {
  StudentModel, UserModel,sequelize
}