'use strict';
const express = require('express');
const app = express();
const cookieSession = require('cookie-session');
const passport = require('passport');
const passportSetup = require('./setting/passport-setup');
const mongoose = require('mongoose');
const keys = require('./setting/keys');
const indexRouts = require('./routes/index');
const errorHandle = require('./utils/errorHandler');
const bodyParser = require('body-parser');

// support parsing of application/json type post data
app.use(bodyParser.json());

//support parsing of application/x-www-form-urlencoded post data
app.use(bodyParser.urlencoded({ extended: true }));



// set up session cookies
app.use(cookieSession({
    maxAge: 24 * 60 * 60 * 1000,
    keys: [keys.session.cookieKey]
}));

// initialize passport
app.use(passport.initialize());
app.use(passport.session());


app.use("/", indexRouts);

app.use(function (req, res) {
    res.status(404)
        .json({
            error: 'Oops!!! No routes found.',
            code: 404
        });
});
app.use(function (error, req, res, next) {
    res.status(error.status || 500)
        .json({
            error: errorHandle(error),
            code: error.code
        });
});

app.listen(3000);
console.log("server statred on port 3000");







      
      