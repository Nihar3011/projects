
const {
    studentClassModel,
    studentModel,
    classModel
} = require('../config/index');
const Sequelize = require('sequelize');

const addStudentModelVar = async (data) => {

    let result = await studentClassModel.bulkCreate(data);
    return result;
}

const getStudentsForClass = async (classId) => {

    let result = await studentClassModel.findAll({

        include: {
            model: studentModel,
            as: 'students',
            attributes: [
                ['s_firstname', 'student_name']
            ]
        },
        where: {
            c_id: classId
        }

    });

    return result;

}

const getClassesForStudent = async (studentId) => {

    let result = await studentClassModel.findAll({

        include: {
            model: classModel,
            as: 'classes',
            attributes: [
                ['c_name', 'class_name']
            ]
        },
        where: {
            s_id: studentId
        }

    });

    return result;

}

const getNoOfStudent = async () => {
    let result = await studentClassModel.findAll({
        include: {
            model: classModel,
            as: 'classes',
            attributes: [
                ['c_name', 'class_name']
            ]
        },
        attributes: [
            [Sequelize.fn('COUNT', Sequelize.col('s_id')), 'StudentCount']
        ],
        group: ['classes.c_id', 'c_name']
    });
    return result;
}

const getNoOfClasses = async () => {
    let result = await studentClassModel.findAll({
        include: {
            model: studentModel,
            as: 'students',
            attributes: [
                ['s_firstname', 'name']
            ]
        },
        attributes: [
            [Sequelize.fn('COUNT', Sequelize.col('c_id')), 'ClassesCount']
        ],
        group: ['students.s_id', 's_firstname']
    });
    return result;
}

module.exports = {
    addStudentModelVar,
    getStudentsForClass,
    getClassesForStudent,
    getNoOfStudent,
    getNoOfClasses
}