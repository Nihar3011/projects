
const {
    classModel
} = require('../config/index');

const addClass = async (classData) => {
    let result = await classModel.create(classData);
    return result;
}

const getClassById = async (classId) => {
    let result = await classModel.findOne({
        where: {
            c_id: classId
        }
    });
    return result;
}

const getClassByName = async (name) => {
    let result = await classModel.findOne({
        where: {
            c_name: name
        }
    });
    return result;
}

const getClasses = async () => {
    let result = await classModel.findAll({
    });
    return result;
}

module.exports = {
  getClassById,
  getClasses,
  addClass,
  getClassByName
}