
const {
    schoolModel
} = require('../config/index');

const addSchool = async (schoolData) => {
    let result = await schoolModel.create(schoolData);
    return result;
}

const getSchoolById = async (schoolId) => {
    let result = await schoolModel.findOne({
        where: {
            school_id: schoolId
        }
    });
    return result;
}

const getSchooles = async () => {
    let result = await schoolModel.findAll({
    });
    return result;
}

const getSchoolByName = async (schoolName) => {
    let result = await schoolModel.findOne({
        where: {
            name: schoolName
        }
    });
    return result;
}


module.exports = {
  getSchooles,
  getSchoolById,
  addSchool,
  getSchoolByName
}