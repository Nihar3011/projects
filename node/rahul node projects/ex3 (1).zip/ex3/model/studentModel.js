
const {
    studentModel
} = require('../config/index');

const addStudent = async (studentData) => {
    let result = await studentModel.create(studentData);
    return result;
}

const getStudentById = async (studentId) => {
    let result = await studentModel.findOne({
        where: {
            s_id: studentId
        }
    });
    return result;
}

const getStudentByName = async (name) => {
    let result = await studentModel.findOne({
        where: {
            s_firstname: name
        }
    });
    return result;
}

const getStudents = async () => {
    let result = await studentModel.findAll({
    });
    return result;
}

module.exports = {
   getStudents,
   addStudent,
   getStudentById,
   getStudentByName
}