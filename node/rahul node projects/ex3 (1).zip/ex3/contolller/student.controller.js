
const {
    getStudentById,
    addStudent,
    getStudents
} = require('../model/studentModel');

const {
    getSchoolByName,
} = require('../model/schoolModel');


"use strict";

class StudentController {

    static async addStudent(req, res, next) {
        // if (error) {
        //     next(error);
        // } else {
        try {
            let {
                name
            } = req.query;
            let school = await getSchoolByName(name);
            if (school.dataValues) {
                let studentData = {
                    ...
                    req.body,
                    school_id:school.dataValues.school_id
                }
                let responseMessage = "Student added successfuly";
                let result = await addStudent(studentData);
                if (result) {
                    res.status(200).json(responseMessage);
                } else {
                    let error = new Error();
                    error.code = 'UNAUTHORIZEDACCESS';
                    next(error);
                }
            }else{
                res.status(500).json("Invalid school");
            }
        } catch (error) {
            console.log(error);
            next(error);
        }
        // }
    }

    static async getStudents(req, res, next) {
        // if (error) {
        //     next(error);
        // } else {
        try {
            let result = await getStudents();
            if (result) {
                res.status(200).json(result);
            } else {
                let error = new Error();
                error.code = 'UNAUTHORIZEDACCESS';
                next(error);
            }
        } catch (error) {
            console.log(error);
            next(error);
        }
        // }
    }

    static async getStudentById(req, res, next) {
        // if (error) {
        //     next(error);
        // } else {
        try {
            let {
                id
            } = req.query;
            let result = await getStudentById(id);
            if (result) {
                res.status(200).json(result);
            } else {
                let error = new Error();
                error.code = 'UNAUTHORIZEDACCESS';
                next(error);
            }
        } catch (error) {
            console.log(error);
            next(error);
        }
        // }
    }

}
module.exports = StudentController;