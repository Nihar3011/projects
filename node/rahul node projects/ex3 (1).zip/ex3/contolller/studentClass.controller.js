
const {
    getClassByName
} = require('../model/classModel');

const {
    getStudentByName
} = require('../model/studentModel');


const {
    addStudentModelVar,
    getStudentsForClass,
    getClassesForStudent,
    getNoOfStudent,
    getNoOfClasses
} = require('../model/studentClassModel');

const resultData = [];
"use strict";

class StudentClassController {


    static async addStudentClass(req, res, next) {
        // if (error) {
        //     next(error);
        // } else {
        try {
            let responseMessage = "Mapping added successfuly";

            await Promise.all(req.body.mappings.map(async data => {
                let classId = await getClassByName(Object.keys(data)[0]);
                let studentId = await getStudentByName(Object.values(data)[0]);
                let row = {
                    c_id: classId.dataValues.c_id,
                    s_id: studentId.dataValues.s_id
                };
                resultData.push(row);
                console.log('resultData', resultData);
            }));

            let result = await addStudentModelVar(resultData);
            if (result) {
                res.status(200).json(responseMessage);
            } else {
                let error = new Error();
                error.code = 'UNAUTHORIZEDACCESS';
                next(error);
            }

        } catch (error) {
            console.log(error);
            next(error);
        }
        // }
    }


    static async getStudentForClassController(req, res, next) {
        let {
            className
        } = req.query
        let classId = await getClassByName(className);
        if (classId.dataValues) {
            let result = await getStudentsForClass(classId.dataValues.c_id);
            let students = [];
            await Promise.all(result.map(row => {
                students.push(row.dataValues.students.dataValues.student_name);
            }));
            if (students.length != 0) {
                res.status(200).json({ "students": students });
            } else {
                res.status(500).json("No student found for the class");
            }
        } else {
            res.status(500).json("class name not found");
        }
    }

    static async getClassesForStudentController(req, res, next) {
        let {
            studentName
        } = req.query
        let studentId = await getStudentByName(studentName);
        if (studentId.dataValues) {
            let result = await getClassesForStudent(studentId.dataValues.s_id);
            let classes = [];
            await Promise.all(result.map(row => {
                classes.push(row.dataValues.classes.dataValues.class_name);
            }));
            if (classes.length != 0) {
                res.status(200).json({ "classes": classes });
            } else {
                res.status(500).json("No class found for the student");
            }
        } else {
            res.status(500).json("student name not found");
        }
    }

    static async getNoOfStudentsForClass(req, res, next) {
        let result = await getNoOfStudent();
        let resultData = [];        
        result.map(data => {   
            let row = {};
            row["className"] = data.classes.dataValues.class_name;
            row["studentCount"] = data.dataValues.StudentCount;
            resultData.push(row)
        });
        if (resultData.length != 0) {
            res.status(200).json({ "studentPerClass": resultData });
        } else {
            res.status(500).json("No class found for the student");
        }
    }

    static async getNoOfClassesForStudent(req, res, next) {
        let result = await getNoOfClasses();
        let resultData = [];        
        result.map(data => {   
            let row = {};            
            row["studentName"] = data.students.dataValues.name;
            row["classCount"] = data.dataValues.ClassesCount;
            resultData.push(row)
        });
        if (resultData.length != 0) {
            res.status(200).json({ "ClassPerStudent": resultData });
        } else {
            res.status(500).json("No student found for the class");
        }
    }
}
module.exports = StudentClassController;