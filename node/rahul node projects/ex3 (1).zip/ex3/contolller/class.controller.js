
const {
    addClass,
    getClassById,
    getClasses
} = require('../model/classModel');

"use strict";

class ClassController {

    static async addClass(req, res, next) {
        // if (error) {
        //     next(error);
        // } else {
        try {
            let responseMessage = "Class added successfuly";
            let result = await addClass(req.body);
            if (result) {
                res.status(200).json(responseMessage);
            } else {
                let error = new Error();
                error.code = 'UNAUTHORIZEDACCESS';
                next(error);
            }
        } catch (error) {
            console.log(error);
            next(error);
        }
        // }
    }

    static async getClasses(req, res, next) {
        // if (error) {
        //     next(error);
        // } else {
        try {
            let result = await getClasses();
            if (result) {
                res.status(200).json(result);
            } else {
                let error = new Error();
                error.code = 'UNAUTHORIZEDACCESS';
                next(error);
            }
        } catch (error) {
            console.log(error);
            next(error);
        }
        // }
    }

    static async getClassById(req, res, next) {
        // if (error) {
        //     next(error);
        // } else {
        try {
            let {
                id
            } = req.query;
            let result = await getClassById(id);
            if (result) {
                res.status(200).json(result);
            } else {
                let error = new Error();
                error.code = 'UNAUTHORIZEDACCESS';
                next(error);
            }
        } catch (error) {
            console.log(error);
            next(error);
        }
        // }
    }

}
module.exports = ClassController;