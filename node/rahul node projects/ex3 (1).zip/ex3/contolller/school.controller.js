
const {
    addSchool,
    getSchoolById,
    getSchooles
} = require('../model/schoolModel');

"use strict";

class SchoolController {

    static async addSchool(req, res, next) {
        // if (error) {
        //     next(error);
        // } else {
        try {
            let responseMessage = "School added successfuly";
            let result = await addSchool(req.body);
            if (result) {
                res.status(200).json(responseMessage);
            } else {
                let error = new Error();
                error.code = 'UNAUTHORIZEDACCESS';
                next(error);
            }
        } catch (error) {
            console.log(error);
            next(error);
        }
        // }
    }

    static async getSchooles(req, res, next) {
        // if (error) {
        //     next(error);
        // } else {
        try {
            let result = await getSchooles();
            if (result) {
                res.status(200).json(result);
            } else {
                let error = new Error();
                error.code = 'UNAUTHORIZEDACCESS';
                next(error);
            }
        } catch (error) {
            console.log(error);
            next(error);
        }
        // }
    }

    static async getSchoolById(req, res, next) {
        // if (error) {
        //     next(error);
        // } else {
        try {
            let {
                id
            } = req.query;
            let result = await getSchoolById(id);
            if (result) {
                res.status(200).json(result);
            } else {
                let error = new Error();
                error.code = 'UNAUTHORIZEDACCESS';
                next(error);
            }
        } catch (error) {
            console.log(error);
            next(error);
        }
        // }
    }

    static async getSchoolByName(req, res, next) {
        // if (error) {
        //     next(error);
        // } else {
        try {
            let {
                name
            } = req.query;
            let result = await getSchoolByName(name);
            if (result) {
                res.status(200).json(result);
            } else {
                let error = new Error();
                error.code = 'UNAUTHORIZEDACCESS';
                next(error);
            }
        } catch (error) {
            console.log(error);
            next(error);
        }
        // }
    }

}
module.exports = SchoolController;