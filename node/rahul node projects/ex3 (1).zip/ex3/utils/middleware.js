module.exports = function (options) {
    return function (req, res, next) {
      // Implement the middleware function based on the options object
      req.requestTime = Date.now();
      next();
    }
  }