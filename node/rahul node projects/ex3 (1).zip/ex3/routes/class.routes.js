"use strict";
const express = require('express');
const router = express.Router();
const classController = require('../contolller/class.controller');


router
    .route('/')
    .get(classController.getClasses);

router
    .route('/get-class')
    .get(classController.getClassById);

router.route('/add')
    .post(classController.addClass);

module.exports = router;