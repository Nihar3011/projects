const express = require("express");
const studentRoutes = require('./student.routes');
const classRoutes = require('./class.routes');
const schoolRoutes = require('./school.routs');
const studentClassRoutes = require('./studentClass.routes');
const authClassRoutes = require('./auth.routes');
const profileRoutes = require('./profile.routes');

const router = express.Router();

router.use("/auth", authClassRoutes);
router.use("/profile", profileRoutes);
router.use("/student", studentRoutes);
router.use("/class", classRoutes);
router.use("/school", schoolRoutes);
router.use("/student-class", studentClassRoutes);

module.exports = router;