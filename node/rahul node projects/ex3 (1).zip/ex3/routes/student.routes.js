"use strict";
const express = require('express');
const router = express.Router();
const studentController = require('../contolller/student.controller');


router
    .route('/')
    .get(studentController.getStudents);

router
    .route('/get-student')
    .get(studentController.getStudentById);

router.route('/add')
    .post(studentController.addStudent);

module.exports = router;