"use strict";
const express = require('express');
const router = express.Router();
const studentClassController = require('../contolller/studentClass.controller');



router.route('/student')
    .get(studentClassController.getStudentForClassController);

router.route('/class')
    .get(studentClassController.getClassesForStudentController);

router.route('/no-student')
    .get(studentClassController.getNoOfStudentsForClass);

router.route('/no-class')
    .get(studentClassController.getNoOfClassesForStudent);


router.route('/add')
    .post(studentClassController.addStudentClass);

module.exports = router;