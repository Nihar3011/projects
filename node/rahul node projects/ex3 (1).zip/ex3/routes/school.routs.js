"use strict";
const express = require('express');
const router = express.Router();
const schoolController = require('../contolller/school.controller');


router
    .route('/')
    .get(schoolController.getSchooles);

router
    .route('/get-school')
    .get(schoolController.getSchoolById);

router.route('/add')
    .post(schoolController.addSchool);

module.exports = router;