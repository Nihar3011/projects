'use strict';
module.exports = (sequelize, DataTypes) => {
    const School = sequelize.define('School', {
        school_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true
        },
        name: DataTypes.STRING
    }, {
            tableName: 'school'
        });
    School.associate = function (models) {
        School.hasMany(models.User, { as: 'students' })
    };
    return School;
}
