module.exports = function (sequelize, DataTypes) {
	const classModel= sequelize.define('User', {
		u_id: {
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true,
			autoIncrement: true
		},
		u_name: {
			type: DataTypes.STRING,
			allowNull: false
		},
		created_by: {
			type: DataTypes.INTEGER,
			allowNull: true
		},
		created_at: {
			type: DataTypes.DATE,
			allowNull: true
		},
		modified_by: {
			type: DataTypes.INTEGER,
			allowNull: true
		},
		modified_at: {
			type: DataTypes.DATE,
			allowNull: true
		}
	}, {
		tableName: 'users'
    });
   
    return classModel;
};
