// All the required files and libraries.

const Sequelize = require('sequelize');
const student = require('./student');
const classes = require('./class');
const school = require('./school');
const studentClass = require('./studentClass');
const userClass = require('./users');

require('dotenv').config();


// Connection with the Database.

const sequelize = new Sequelize("node_demo", "postgres", "argusadmin", {
    host: "localhost",
    dialect: 'postgres',
    logging: false,
    pool: {
        max: 10,
        min: 0,
        acquire: 30000,
        idle: 10000
    },
    define: {
        timestamps: false
    },
    dialectOptions: {
        useUTC: false, // for reading from database
    },
    timezone: '+05:30'
});

sequelize.sync({ force: false })
    .then(() => {

});


//Initialization of serialize models.

const studentModel = student(sequelize, Sequelize);
const classModel = classes(sequelize, Sequelize);
const schoolModel = school(sequelize, Sequelize);
const studentClassModel = studentClass(sequelize, Sequelize);
const userModel = userClass(sequelize, Sequelize);


studentModel.belongsTo(schoolModel, { foreignKey: 'school_id', as: 'school' }),

studentModel.hasMany(studentClassModel, {
    foreignKey: 's_id',
    sourceKey: 's_id'
})

classModel.hasMany(studentClassModel, {
    foreignKey: 'c_id',
    sourceKey: 'c_id'
})

studentClassModel.belongsTo(studentModel, {
    foreignKey: 's_id',
    as: 'students'
});
studentClassModel.belongsTo(classModel, {
    foreignKey: 'c_id',
    as: 'classes'
});


module.exports = {
    studentModel,
    classModel,
    schoolModel,
    studentClassModel,
    userModel
};