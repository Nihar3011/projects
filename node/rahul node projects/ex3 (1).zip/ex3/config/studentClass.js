module.exports = function (sequelize, DataTypes) {
    const studentClassModel = sequelize.define('StudentClass', {
        sc_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true
        },
        s_id: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        c_id: {
            type: DataTypes.INTEGER,
            allowNull: false
        }
    }, {
            tableName: 'student_class'
        });
   
    return studentClassModel;
};
