module.exports = function (sequelize, DataTypes) {
	const classModel= sequelize.define('Class', {
		c_id: {
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true,
			autoIncrement: true
		},
		c_name: {
			type: DataTypes.STRING,
			allowNull: false
		},
		created_by: {
			type: DataTypes.INTEGER,
			allowNull: true
		},
		created_at: {
			type: DataTypes.DATE,
			allowNull: true
		},
		modified_by: {
			type: DataTypes.INTEGER,
			allowNull: true
		},
		modified_at: {
			type: DataTypes.DATE,
			allowNull: true
		}
	}, {
		tableName: 'class'
    });
   
    return classModel;
};
