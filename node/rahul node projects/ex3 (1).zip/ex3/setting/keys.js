module.exports = {
    google: {
        clientID: '336244413369-kev6pob3fst0vuad6jcr9mvk7g98i2ek.apps.googleusercontent.com',
        clientSecret: 'daNQbDzOEUVH5U-5fEW7FsfR'
    },
    mongodb: {
        dbURI: 'mongodb://yash:argusadmin@localhost:27017/node_demo'
    },
    session: {
        cookieKey: 'thenetninjaisawesomeiguess'
    }
};