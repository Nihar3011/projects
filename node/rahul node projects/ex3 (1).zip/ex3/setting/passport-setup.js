const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const keys = require('./keys');
const {
    userModel
} = require('./users');
passport.serializeUser((user, done) => {
    done(null, user.googleId);
});

passport.deserializeUser((id, done) => {
    userModel.findOne({
        where: {
            googleId: id
        }
    }).then((user) => {
        done(null, user);
    });
});

passport.use(
    new GoogleStrategy({
        
        clientID: keys.google.clientID,
        clientSecret: keys.google.clientSecret,
        callbackURL: 'http://localhost:3000/auth/google/redirect'
    }, (accessToken, refreshToken, profile, done) => {
        console.log(profile);
        // check if user already exists in our own db
        userModel.findOne({
            where: {
                googleId:  profile.id
            }
        }).then((currentUser) => {
            if (currentUser) {
                // already have this user
                console.log('user is: ', currentUser);
                done(null, currentUser);
            } else {
                // if not, create user in our db
                let user ={
                    googleId: profile.id,
                    u_name: profile.displayName,
                };
               userModel.create(user).then((newUser) => {
                    console.log('created new user: ', newUser);
                    done(null, newUser);
                });
            }
        });
    })
);
