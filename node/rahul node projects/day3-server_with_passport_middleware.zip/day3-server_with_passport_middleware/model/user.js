const Schema = mongoose.Schema;

const user = new Schema({
    firstname: String,
    lastname: String,
    contact: { type: String, length: 10 },
    pwd: String,
    email: {
        type: String,
        validate: {
            validator: function(value) {
                return /[a-z0-9]*@gmail.com/.test(value);
            }
        }
    }
});

const userModel = mongoose.model("userModel", user);

module.exports = { userModel };