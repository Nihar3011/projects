const router = express.Router();

const {get, getAll, create, update, remove } = require('../features/student.action');

router.route('/getAll').get(getAll);
router.route('/get/:studentId').get(get);
router.route('/create').post(create);
router.route('/update/:studentId').put(update);
router.route('/remove/:studentId').delete(remove);

module.exports = router;