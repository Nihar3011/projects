const userRepository = require('../features/user.action');

class Connection {
    constructor(username = null, password = null) {
        this.username = username;
        this.password = password;
    }

    async validateUser(request) {
        try {
            let data = await userRepository.getUserByUserId(this.username);
            if (data) {
                const match = (data.pwd === this.password);
                if (match) {
                    console.log('Valid user : ', this.username);
                    /**
                     *  remove password from user object
                     */
                    data.pwd = undefined;
                    return data;
                }
            }
            return false;
        } catch (error) {
            console.log('Error occured while login : ', error);
            throw error;
        }
    }
}

module.exports = Connection;