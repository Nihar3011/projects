global.express = require('express');
global.mongoose = require('mongoose');
const bodyParser = require('body-parser');
const passport = require('passport');
const session = require('express-session');
const pgSession = require('connect-pg-simple')(session);
const PORT = 3030;

global.app = express();

app.use(
    session({
        secret: 'passport-tutorial',
        cookie: { maxAge: 60000 },
        resave: false,
        saveUninitialized: false
    })
);

app.use(bodyParser.raw());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(passport.initialize());
app.use(passport.session());

// require('./model/user').userModel.create({
//     firstname: "rahul",
//     lastname: "rahul",
//     contact: "9865321245",
//     pwd: "rahul1234",
//     email: "rahul.patel@gmail.com"
// });
require('./config/dbConnection').dbConnection();
app.use((request, response, next) => {
    console.info("**************" + request.url);
    next();
})
require('./router');
require('./middlewares/passport').initialize();

app.listen(PORT, () => {
    console.log(`App listening on port ${PORT}!`)
});