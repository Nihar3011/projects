const { userModel } = require('./../model/user');

class User {

    static async getUserByUserId(userId) {
        try {
            let result = await userModel.findOne({ email: userId });
            return result;
        } catch (error) {
            console.error(error);
            throw error;
        }
    }

    static async createUser(user) {
        try {
            let result = await userModel.create(user);
            console.log("user created");
        } catch (error) {
            console.error(error);
            throw error;
        }
    }
}

module.exports = User;