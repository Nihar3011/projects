const axios = require('axios');

const getAll = async(request, response, next) => {
    try {
        const result = await axios.get('http://localhost:3000/student');
        response.status(200).json(result.data);
    } catch (error) {
        response.status(401).json({ message: error.error });
    }
}

const get = async(request, response, next) => {
    try {
        const result = await axios.get(`http://localhost:3000/student/${request.params.studentId}`);
        response.status(200).json(result.data);
    } catch (error) {
        response.status(401).json({ message: error.error });
    }
}

const create = async(request, response, next) => {
    try {
        // const student = {
        //     "firstname": "Nishta",
        //     "lastname": "Patel",
        //     "dob": "01-07-1998",
        //     "gender": "female"
        // };
        const student = request.body;
        const result = await axios.post('http://localhost:3000/student', student);
        response.status(200).json({ message: "successful" });
    } catch (error) {
        response.status(401).json({ message: error.error });
    }
}

const update = async(request, response, next) => {
    try {
        const student = request.body;
        const result = await axios.put(`http://localhost:3000/student/${request.params.studentId}`, student);
        response.status(200).json({ message: "successful" });
    } catch (error) {
        response.status(401).json({ message: error.error });
    }
}

const remove = async(request, response, next) => {
    try {
        const result = await axios.put(`http://localhost:3000/student/${request.params.studentId}`);
        response.status(200).json({ message: "successful" });
    } catch (error) {
        response.status(401).json({ message: error.error });
    }
}

module.exports = {
    get,
    getAll,
    create,
    update,
    remove
};