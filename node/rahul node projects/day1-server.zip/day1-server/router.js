const student = require('./routes/student.routing');

app.use('/student', student);