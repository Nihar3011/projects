const router = express.Router();

const {get, getAll, create, update, remove } = require('../features/student.action');

router.get('/getAll', getAll);
router.get('/get/:studentId', get);
router.post('/create', create);
router.put('/update/:studentId', update);
router.delete('/remove/:studentId', remove);

module.exports = router;