/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.exercise2.exceptionexample;

/**
 *
 * @author nihar
 */
public class UserDefineException extends Exception{

    public UserDefineException(String s) {
        super(s);
    }
    
}
