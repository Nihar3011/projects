/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.exercise2;

import com.exercise2.casting.CastingExample;
import com.exercise2.exceptionexample.UserDefineException;
import com.exercise2.stringdemo.StringDemo;

/**
 *
 * @author nihar
 */
public class Main {
    
    public static void main(String[] args) {
        StringDemo demo=new StringDemo();
        demo.stringFunction();
        demo.StringBufferFunction();
        
         try
        { 
            // Throw an object of user defined exception 
            throw new UserDefineException("Exception!!!!"); 
        } 
        catch (UserDefineException ex) 
        { 
            System.out.println("In Side catch"); 
  
            // Print the message from MyException object 
            System.out.println(ex.getMessage()); 
        } 
        finally{
             System.out.println("In Side finally"); 
         }

        CastingExample castingExample = new CastingExample();
        castingExample.print();
         
    }
}
