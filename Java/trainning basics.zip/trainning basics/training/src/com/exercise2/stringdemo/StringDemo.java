/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.exercise2.stringdemo;

import java.util.regex.Pattern;

/**
 *
 * @author nihar
 */
public class StringDemo {

    String str1 = "I am first String";
    String str2 = "I am second String";
    String ans;

    public void stringFunction() {

        ans = str1.concat("and " + str2);
        System.out.println("Concate String : " + ans);
        
        int index = ans.indexOf("am");
        System.out.println("Position : " + index);

        boolean compare = str1.equals(str2);
        System.out.println("String 1 and 2 are same?"+compare);

        System.out.println("------------------------------");
        System.out.println(Pattern.matches("[amn]", "amn"));//false (not a or m or n)  
        System.out.println(Pattern.matches("[amn]", "a"));//true (among a or m or n)  
        System.out.println(Pattern.matches("[a-zA-Z]+", "azas"));//false (m and a comes more than once)  
        System.out.println("------------------------------");
    }
    /**
     * String buffer 
     */
    public void StringBufferFunction() { 

        StringBuffer firstStringBuffer = new StringBuffer(str1);
        
       StringBuffer reverseStringBuffer= firstStringBuffer.reverse();
       
        System.out.println("Reverse String:"+reverseStringBuffer);
        System.out.println("------------------------------");

    }

}
