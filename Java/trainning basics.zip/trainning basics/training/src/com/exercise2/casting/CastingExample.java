/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.exercise2.casting;

/**
 *
 * @author nihar
 */
public class CastingExample {

    public void print() {
        int i = 100;

        //automatic type conversion 
        long l = i;

        //automatic type conversion 
        float f = l;
        System.out.println("------------------------------");
        System.out.println("automatic type conversio");
        System.out.println("Int value " + i);
        System.out.println("Long value " + l);
        System.out.println("Float value " + f);
        System.out.println("------------------------------");
        double d = 100.04;

        //explicit type casting 
        System.out.println("explicit type casting ");
        l = (long) d;
        System.out.println("Double value " + d);
        System.out.println("long value " + l);

        System.out.println("------------------------------");
        System.out.println("unboxing the Object  ");

        Integer num1 = 10;
        // unboxing the Object 
        int i1 = num1;

        System.out.println("Value of i: " + num1);
        System.out.println("Value of i1: " + i1);
        System.out.println("------------------------------");
        System.out.println("Autoboxing of char   ");
        //Autoboxing of char 
        Character gfg = 'a';

        // Auto-unboxing of Character 
        char ch = gfg;
        System.out.println("Value of ch: " + ch);
        System.out.println("Value of gfg: " + gfg);
        System.out.println("------------------------------");

    }
}
