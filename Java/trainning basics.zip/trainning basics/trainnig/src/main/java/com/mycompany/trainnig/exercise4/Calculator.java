/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.trainnig.exercise4;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author nihar
 */
public class Calculator {

    int number1;
    int number2;
    int choise;
    Scanner sc = new Scanner(System.in);

    /**
     * Get Number from User
     */
    public void getNumber() {

        try {
            System.out.println("Enter number 1");
            number1 = sc.nextInt();
            System.out.println("Enter number 2");
            number2 = sc.nextInt();
            this.calculate();
        } catch (InputMismatchException e) {
            sc.next();
            System.err.println("Only Number is Valid");
            getNumber();
        }

    }
    /**
     * Calculate with numbers
     */
    void calculate() {
        System.out.println("\nSelect Your Choise");
        System.out.println("--------------------------------");
        System.out.println(" (1)Addition \n (2)Subtraction \n (3)Multiplication \n (4)Divition ");
        System.out.println("--------------------------------");
        choise = sc.nextInt();

        switch (choise) {
            case 1:
                CalInterface pulsFunction = (int num1, int num2) -> num1 + num2;
                System.out.println(number1 + " + " + number2 + "="
                        + pulsFunction.getAnswer(number1, number2));
                break;
            case 2:
                CalInterface minusFunction = (int num1, int num2) -> num1 - num2;
                System.out.println(number1 + " - " + number2 + " ="
                        + minusFunction.getAnswer(number1, number2));
                break;
            case 3:
                CalInterface mulFunction = (int num1, int num2) -> num1 * num2;
                System.out.println(number1 + " * " + number2 + " ="
                        + mulFunction.getAnswer(number1, number2));
                break;
            case 4:
                try {
                    CalInterface divsFunction = (int num1, int num2) -> num1 / num2;
                    System.out.println(number1 + " / " + number2 + " ="
                            + divsFunction.getAnswer(number1, number2));
                } catch (Exception e) {
                    System.err.println("Divide By zero is Not Valid");
                    calculate();
                }
                break;
            default:
                System.out.println("Invalid Choise");
                calculate();
        }

    }

}
