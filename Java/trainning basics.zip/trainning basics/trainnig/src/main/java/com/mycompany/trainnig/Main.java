/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.trainnig;

import com.mycompany.trainnig.exercise1.AccessSpecifierDemoChild;
import com.mycompany.trainnig.exercise1.child.AccessSpecifierDemoOtherPackageChild;
import com.mycompany.trainnig.exercise2.KeyWordDemo;
import com.mycompany.trainnig.exercise3.Order;
import com.mycompany.trainnig.exercise4.Calculator;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author nihar
 */
public class Main {

    public static void main(String[] args) {

        int choice = 0;
        Scanner sc = new Scanner(System.in);
        System.out.println("Select number of Practical");
        try {
            choice = sc.nextInt();
        } catch (InputMismatchException e) {
           
        }

        switch (choice) {
            case 1: //Practical 1
                AccessSpecifierDemoChild child1 = new AccessSpecifierDemoChild();
                child1.print();
                AccessSpecifierDemoOtherPackageChild child2 = new AccessSpecifierDemoOtherPackageChild();
                child2.print();
                break;
            case 2://Practical 2
                KeyWordDemo.print(); // satic methode with class name
                KeyWordDemo keyWordDemo = new KeyWordDemo(10, 20);
                keyWordDemo.sum();
                keyWordDemo.test();
                break;
            case 3://Practical 3
                Order order = new Order();
                order.GetPaymentWay();
                break;
            case 4://Practical 4
                Calculator calculator = new Calculator();
                calculator.getNumber();
                break;
            default:
                System.out.println("Wrong Input");
        }

    }

}
