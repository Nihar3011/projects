/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.trainnig.exercise3;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author nihar
 */
public class Order {

    int pay;

    public Order() {
        System.out.println("Your Order is:\n 1) Milk Shake of 500 rs \n"
                + " 2) Ice-cream of 200  ");
    }

    /**
     * GetPayment way
     */
    public void GetPaymentWay() {
        System.out.println("\nSelect Payment Method");

        System.out.println("(1)Cash \n(2)Netbanking");
        try {
            Scanner sc = new Scanner(System.in);
            pay = sc.nextInt();
            this.payment();
        } catch (InputMismatchException e) {
            System.out.println("Enter Number Only");
            GetPaymentWay();
        }

    }

    public void payment() {
        switch (pay) {
            case 1:
                Payment cash = new CashPay();
                cash.pay();
                break;
            case 2:
                Payment netBanking = new NetBankingPay();
                netBanking.pay();
                break;
            default:
                System.out.println("Please pay your bill");
                GetPaymentWay();
        }
    }

}
