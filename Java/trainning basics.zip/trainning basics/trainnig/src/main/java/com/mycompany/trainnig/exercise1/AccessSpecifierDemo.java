/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.trainnig.exercise1;

/**
 *
 * @author nihar
 */
public class AccessSpecifierDemo {
    
    public int publicA;
    protected int protectedA;
    private static int privateA;
    int defaultA;
    
    /**
     * Static block
     */
    static{
        System.out.println("****Inside parent Class*****");
        System.out.println("Private A = "+ privateA);
    }
    
}
