/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.trainnig.exercise1.child;

import com.mycompany.trainnig.exercise1.AccessSpecifierDemo;

/**
 *
 * @author nihar
 */
public class AccessSpecifierDemoOtherPackageChild extends AccessSpecifierDemo{
    /**
     * Print parent class variables which accessible different package 
     */
    public void print(){ //  public methode is access in main class
        System.out.println("****Inside other package child Class*****");
        System.out.println("Public A =" + publicA);
        System.out.println("Protected A="+ protectedA);
    }
}
