/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.trainnig.exercise2;

/**
 *
 * @author nihar
 */
public class KeyWordDemo implements KeyWordDemoInterface{
    
    
    final int num1 = 10; // Work like constant and value never change
    static int num2 = 1; // static variable initilize only ones
    
    int num3;
    int num4;
    
   

    public KeyWordDemo(int num3,int num4) {
        this.num3=num3;
        this.num4=num4;
        System.out.println("Using this set values ="+ this.num3 + " or " + this.num4);
    }
    /**
     * Static method 
     */
    static public void print(){
        System.out.println("Static variable vlaue = "+ num2);
    }

    @Override
    public void sum() {
        System.out.println("Sum of  num1 and num2 is = "+ (num1+num2));
    }

    @Override
    public void test() {
        KeyWordDemoInterface.super.test(); //To change body of generated methods, choose Tools | Templates.
    }
    

}
