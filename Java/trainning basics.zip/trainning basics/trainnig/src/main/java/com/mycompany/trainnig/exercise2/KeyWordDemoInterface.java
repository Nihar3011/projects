/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.trainnig.exercise2;

/**
 *
 * @author nihar
 */
public interface KeyWordDemoInterface {
    
    /**
     * Sum of two numbers
     */
    public void sum(); // abstract methode
    /**
     * Default Method in interface
     */
    default void test(){
	System.out.println("hello");	
    }
}
