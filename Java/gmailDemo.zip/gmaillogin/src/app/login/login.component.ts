import { Component, OnInit } from '@angular/core';
import { SocialLoginModule, AuthServiceConfig, GoogleLoginProvider, SocialUser, AuthService} from 'angular-6-social-login';
import { AuthService1 } from '../service/auth.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public user: any = SocialUser;
  constructor(private socialAuthservice: AuthService, private authservices: AuthService1) {
    if (localStorage.getItem('usermail') === null) {
       console.log('Storage is null');
      // redirect to home page
      } else {
        console.log('Storage has entry: ' + localStorage.getItem('usermail'));
    }
   }

  googlelogin() {
    console.log('dsdsd');
    this.socialAuthservice.signIn(GoogleLoginProvider.PROVIDER_ID).then((userData) => {
    this.user = userData;
    localStorage.setItem('usermail', userData.email);
    console.log(this.user);
    });
  }
  googlelogout() {
    this.socialAuthservice.signOut().then(
      (userData) => {
      localStorage.removeItem('usermail');
      }
      );
  }

    sendEmail() {
        this.authservices.sendtoken(this.user).subscribe(data => {console.log(data);
     });
    }




  ngOnInit() {
  }

}
