import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { HttpClient, HttpClientModule, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AuthService1 {
  constructor(private http: HttpClient) { }

  sendtoken(user): Observable<void> {
    const httpOptions = {
      headers: new HttpHeaders(
      {
        'Content-Type': 'application/json'
      })
    };
    console.log(user.idToken);
    return this.http.post<void>('http://localhost:8080/list/email', user.idToken, httpOptions)
          .pipe(map( response => {
              return response;
          }));
  }

}
